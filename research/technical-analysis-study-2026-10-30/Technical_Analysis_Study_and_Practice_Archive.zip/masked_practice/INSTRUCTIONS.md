# Blind right-edge visual practice — four cases

Read only `masked/case_A.png` through `case_D.png`. Each is a newly rendered, real archived 4-hour OHLCV window, 96 visible bars; subsequent 24 bars are held out. Images show linear price, per-bar volume, and trailing SMA20. First 19 observations have no SMA; no forward-filled or centered indicators. Data windows and reveal horizons do not overlap. Case selection was deterministic by index, not outcomes.

Before reveal, record for each:
1. Five directly visible observations (structure, candle geometry, location, volume, MA).
2. Primary interpretation and a serious alternative.
3. Exact next-bar or later trigger, invalidation, target/management, and no-trade conditions. A flat decision is valid.
4. Confidence and what would change the reading.
5. Optional numeric price levels; distinguish close-confirmed from intrabar triggers.

Do not open `private/`, `superseded/`, raw bars, or renderer source until readings are saved: those can reveal identities, dates, or later bars. Future reveals and numeric audit are separate. A 24-bar horizon measures subsequent path, not certainty of an open-ended thesis. No fees, spread, slippage, or fills modeled; same-candle target/stop sequencing cannot be recovered from OHLC.

## Provenance caveat supplied before exercise
One archived instrument, four 4-hour windows—not independent markets or equity validation. Source response is Kraken-compatible OHLC schema; actual acquisition endpoint/feed identity is inferred, not independently verified. UTC spacing is exactly 14,400 seconds. Original values preserved without researcher adjustments; original adjustment metadata absent. Source pinned Git blob hash verified. Last source bar excluded because it may be incomplete. Full timestamps and source manifest held in `private/setup_metadata.json` until readings are recorded.

Renderer is our original plotting code, not repository-executed code. All four masked original-resolution images inspected for legibility. Scales use only visible data; chart title/axes contain no later prices, performance labels, or outcome-dependent selection. Full cutoff assertions passed. Code and images frozen by `frozen_manifest.json`.

Schema reference: https://docs.kraken.com/api-reference/market-data/get-ohlc-data — current Kraken documentation identifies the last OHLC entry as potentially uncommitted. Schema resemblance is not independent feed verification.
