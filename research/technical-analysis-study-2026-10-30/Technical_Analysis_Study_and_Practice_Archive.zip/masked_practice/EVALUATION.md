# Frozen right-edge practice: reveal evaluation

Original reading SHA256: `1d7fcf2c853fda8878831e7481c717b36fb6cc5d9395541a96a8ea3ab2bdf79f`. Copied and frozen before the evaluator opened later bars. See `READING_FREEZE.json`. No thresholds changed. All four reveal charts personally inspected after freeze. Symbol identity was previously disclosed; future paths and cutoffs were withheld. This is right-edge masking, not complete identity blinding.

Future bars are numbered 1–24. Touches use inclusive highs/lows; closes use the frozen strict inequalities. Twenty-four four-hour bars = 96 hours. Initial trigger/cancellation route expires after 12 bars = 48 hours. Same-bar dual touches would be ambiguous; neither-touch results would remain unresolved. Neither occurs for these four path comparisons, but case C's close-confirmation route remains unresolved/expired.

| Case | Frozen 24-bar path comparison | Observed first touches | Frozen 12-bar close route |
|---|---|---|---|
| A | .180 before .169 | .180 at bar2; .169 at bar24 | Confirmed bar2, close .190878 > .180; no earlier cancellation |
| B | .198 before .182 | .198 at bar1; .182 not touched | Confirmed bar1, close .194934 > .194; **timing invalidated next bar**, close .188843 < .189 |
| C | .225 before .209 | .225 at bar5; .209 at bar22 | Neither close > .226 nor close < .209 in first12; no activation within allowed window |
| D | .245 before .267 | .245 at bar2; .267 not touched | Confirmed bar1, close .249634 < .250; no prior close > .260; no subsequent close > .259 within24 |

## What the reveals teach

**A: correct near-term continuation need not persist.** The market resumed up with a large green bar2 and ultimately reached .199779, then retraced across the later window to a final .169218. The stated .184 reference was already passed within the candle that finally confirmed a close above .180. Thus that reference cannot be credited as a post-confirmation profit target at a hypothetical .180 fill. The pre-reveal distinction between trend direction and poor extended entry location was useful. A successful first-touch comparison does not mean the end-of-horizon return was positive.

**B: path agreement and timing-thesis failure coexist.** Bar1 high .198658 reached the first path objective before that candle closed at .194934. Bar2 then closed .188843, below the explicitly specified .189 timing invalidation. Price later recovered, with full reveal high .211474 and final .198480. That later recovery does not erase the failed timing thesis or authorize retrospectively ignoring its invalidation. No “winning trade” claim follows from the first-touch result; target was touched before the close-confirmed route could be known.

**C: wick penetration is not close acceptance.** Bar5 high .226335 satisfied the .225 path touch, but its .219499 close rejected the upper area rather than satisfying >.226. No eligible close confirmation appeared in the first12 bars. A later escape beyond the initial window cannot be silently admitted under the frozen rules. The chart eventually dipped through .209 at bar22. The correct output is primary reference first, but no qualifying initial route—not a fabricated execution or a failed close signal that never occurred.

**D: weakness followed through, then recovered.** Bar1 close .249634 confirmed the narrow bearish observation. Bar2 dropped through .245, closing .231425; the full-window low was .223147. Later price rebounded into the .250s, ending .253478. The specified post-activation close above .259 did not occur; full-window maximum high .259106 itself is insufficient because the rule required a close. This reinforces the distinction between candle extremes and closes, and between an initial move and perpetual directional ownership.

## Scope of result

All four selected first-touch statements agreed with the observed order. That is **four descriptive path checks**, not a calibrated success probability, executable strategy record, or proof of generalized mastery. References differed in distance; no symmetric null benchmark or transaction-cost model was specified. The cases are one archived instrument/feed and one timeframe, selected mechanically without outcome ranking. The reading process, conditional logic, and trigger specificity are the learning outcomes. All four initial actions were no-entry/wait observations, and no actual or simulated fills or P&L are claimed.

## Audit and reveal files

- `EVALUATION.json`: exact OHLCV for each future bar and test classifications.
- `private/case_A_reveal.png` through `case_D_reveal.png`: dashed line marks cutoff after observed index95; future starts index96. The inherited x-axis phrase “future withheld” describes the original exercise; these files deliberately reveal24bars, as their titles state. Renderer/images remain frozen, not cosmetically changed after reading.
- `private/setup_metadata.json`: dates, source commit/blob, source limitations, immutable cutoff metadata.
- `evaluate_frozen.py`: transparent original evaluator; reads data, executes no repository code.
- `ROOT_PRE_REVEAL_READINGS.md`: preserved original reading; its hash is recorded in `READING_FREEZE.json`.

No longer-term bars were consulted to improve these outcomes. The original source schema/feed and adjustment caveats still apply.
