# TheStrat: a practical grammar for reading changing ranges

## What was studied and what this chapter is

This chapter is original instructional synthesis from fourteen exact, commit-pinned files in the user's Silicon research archive: eight retained English automatic-caption transcripts, five captured Alex Sopa documentation pages, and one video catalog. All fourteen were read in full and their local bytes independently matched their Git blob SHA-1s. The eight captions cover six shorts and two longer lessons, not fourteen videos. The catalog additionally lists two streams whose contents were not in this assigned set. No video frames were watched in this pass. References such as “here” in captions therefore describe a speaker's chart explanation, not a chart independently inspected here.

The documentation attributes TheStrat's development to Rob Smith and these particular explanations to Alex Sopa (AlexsOptions). This is a reconstruction of that teaching, not a claim that every current practitioner or Rob Smith uses each execution detail identically. It is not a review of a trading engine or proof that a prototype faithfully implements the method. The full-read ledger provides exact source pins and provenance.

## 1. Begin with three independent questions

A chart read becomes much cleaner if three facts are kept separate:

1. **Which boundaries were crossed?** Compare the bar's high and low with the previous bar's high and low. This determines the scenario number.
2. **Where is price relative to this bar's own open?** This determines its current color, or its final color after closing.
3. **Where is this bar inside the larger range?** Compare with daily, weekly, monthly, and relevant enclosing mother-bar boundaries. This determines context and available room.

A green bar is not automatically a structural up bar. A bar can take the previous low, fail to take the previous high, and close above its own open: it is a green 2d. Likewise, a red 2u has broken upward relative to the previous range while finishing below its own open. Alex's short on candle color and the longer September lesson explicitly teach this conflict. The useful observation is not “green means buy,” but “the lower boundary was crossed, while current price has recovered above this period's open.” That is more information with less interpretive baggage.

## 2. The observable bar alphabet

Let H0 and L0 be the completed previous bar's high and low; H and L are the current bar's running extremes.

| Classification | Observable condition | What is known |
|---|---|---|
| 1, inside | Neither previous extreme has been exceeded | Current range remains contained |
| 2u | H > H0, while L has not fallen below L0 | Only the upper boundary has been exceeded |
| 2d | L < L0, while H has not risen above H0 | Only the lower boundary has been exceeded |
| 3, outside | H > H0 and L < L0 | Both boundaries have been exceeded |

For a reproducible exercise, adopt **strict exceedance** and treat exact touches as unbroken; that equality convention is an explicit practice specification, not a detail established by these fourteen sources. Tick size and vendor rounding matter. The archive's phrases “takes out” and “last sale through” support distinguishing a touch from a trade through, but do not settle every feed-edge case.

The number depends on extremes, not the close. Once both sides have traded, a bar stays a 3 even if its final close is in the middle. A live 1 can become 2u or 2d, and that live 2 can become 3. A failed 2u does not erase the high it already printed; it remains 2u until it also exceeds the prior low. Conversely, the final label alone cannot tell us which side broke first. That requires the intrabar path.

**Original drill.** Previous range is 100–110. Current bar opens104, trades111, then102 and closes103: red2u. If it subsequently trades99 before that same period closes, it is3, regardless of a later close at108. If it instead trades101–109 and closes108, it is green1. Describe the number, color, and containment separately each time.

A gap deserves explicit handling. A new bar can open outside the prior range; do not mechanically insist that every real-world opening print begins as1. The teaching's inside→2→3 animation is a path illustration, not a universal claim about gapless data.

## 3. Read combinations as events, not decorative names

The sequence describes how one attempt interacts with the next. The most useful beginner distinction is between an immediate failed break and a pause before the next break.

### Immediate 2-2 reversal

A 2d followed by2u reverses the immediately preceding downward break;2u followed by2d is the mirror. In the docs' X–2d–2u anatomy, X is the bar before the initial2d. Entry triggers through the2d's high; the first structural objective is X's high. The combination has already taken X's low and is trying to take X's high. When it exceeds that far boundary, the combined range covers both sides of X—a **compound3**.

**Original numerical illustration:** X spans100–110. The next bar spans98–106 and closes105 after opening102: green2d. A subsequent trade above106 triggers the bullish reversal.110 is the first mapped objective, not an invented extension.100 is a separate reclaim reference if the failed breakdown closed back above it. These are three different prices with three different jobs. A target at110 does not imply certainty that110 will trade.

### 2-1-2 reversal versus continuation

The1 is a temporary equilibrium inside its predecessor. In2d–1–2u, the next break is against the preceding downward2. Trigger through the inside bar's high; use the earlier2d's high as the initial magnitude reference. In2u–1–2u, the inside bar resolves with the preceding upward2, so it is continuation. Mirror both for the short side.

If an inside bar spans102–105 within a2d spanning98–106, the bullish trigger lies just above105, the first structural objective is106, and the other side of the1 lies near102. That is a narrow objective relative to the structural stop. The sequence's attractive name does not manufacture additional room. This is why locating the formation on the larger chart is part of reading it, not an optional risk appendix.

### 3-1-2

The archived docs also teach an outside bar, then inside bar, then directional break. For the reversal variant, the last break opposes the3's close direction. Here “3u” or “3d” adds a direction/color qualifier to an outside bar; it does not mean that only one boundary was crossed. Read the actual OHLC values rather than mistaking the suffix for the2u/2d rule.

### Outside-bar reversal: a different entry location

Suppose the current bar breaks the previous low first, recovers, and then exceeds the previous high. At the final upward break it becomes3. The docs emphasize that the opposite edge of the previous range was the range-crossing objective; entering at that edge means entering where that particular objective is already completed. Further room must come from another, larger reference—not from recycling the completed same-bar target. This is a crucial difference between anticipating a2 going3 earlier in the path and buying the finished3 at its far extreme.

### Momentum stack and shotgun

The2-2 page also describes2u–2d–2u: an upward move, one-bar downward pullback, then resumption. Locally the last pair reverses the pullback; in the larger campaign it continues the uptrend. The shotgun description adds the significance of both sides being swept across three bars. These are contextual readings of the same numeric alphabet, not permission to ignore which prices were actually taken. For a compound3 claim, specify the reference range and aggregation window; arbitrary clock-aligned higher-timeframe candles need not equal an informally combined two- or three-bar sequence.

## 4. Momentum is not a synonym for continuation

The archived momentum/retracement page teaches a specific one-bar color test: inspect the bar immediately before the actionable signal. If its color matches the intended trade direction, call the entry momentum; otherwise call it retracement. This is a source-specific label, not the broad textbook definition of momentum.

For example, a red2u followed by1 and then2u is **structural continuation**, yet its long entry is **retracement** under this test. A red2u followed by1 and then2d is **structural reversal**, yet its short entry is **momentum**. Gap behavior makes this distinction particularly visible. Keep two columns in a journal rather than collapsing them into one bullish/bearish flag.

For the retracement version, Alex's documentation places extra emphasis on the color flip: the trade needs price to change its relationship to the relevant open, not merely a visually attractive signal. Do not turn that explanation into a universal additional close-confirmation requirement. These same docs explicitly describe intrabar last-sale trigger execution.

## 5. Full timeframe continuity is a live context layer

The October long lesson gives a deliberately simplified version: compare the latest price with the opens of the60-minute, daily, weekly, and monthly periods. Above all four distinct opens indicates aligned upward color context; below all four indicates the opposite. It offers quarter/month/week/day for longer-horizon reading. This is not a complete specification of every FTFC variant, and the linked dedicated FTFC page was not part of this fourteen-file assignment.

Make a small table before looking for entries:

| Period | Open | Previous high/low | Running scenario | Price versus open | Closed or live? |
|---|---|---|---|---|---|
| Month | Record | Record | Record | Above/below/equal | Live |
| Week | Record | Record | Record | Above/below/equal | Live |
| Day | Record | Record | Record | Above/below/equal | Live |
| Execution period | Record | Record | Record | Above/below/equal | Explicit |

Why keep opens and extremes? Color alignment and directional boundary breaks are related but nonidentical evidence. Why keep live/closed? Monday's weekly signal can change before Friday; current evidence is not a completed weekly outcome. Why mention distinct opens? At a new week or month several opens can coincide; four labels on the same price are not four independent observations.

The campaign idea is to use higher-timeframe direction to select lower-timeframe reconfirming signals. A weekly break can provide the context while a30-minute reversal after a pullback provides the entry structure. The transcript treats the weekly evidence as relevant through the week, but also insists that the break remain in force. Calendar validity never overrides price negation.

## 6. Mother bars explain why an apparently good reversal has nowhere to go

The September lesson's central visual warning is scale. A five-minute chart can auto-fit a small oscillation to fill the screen and make an internal range look like a large opportunity. The remedy is not simply changing chart cosmetics: inspect the enclosing30-minute, daily, and weekly ranges.

A mother-bar problem occurs when multiple later bars remain within an earlier bar's range. Internal2s and reversals can be genuine relative to adjacent bars while still leaving the larger structure contained. A useful read therefore says, “local2d–1–2u, still below mother high,” rather than “trend has reversed” without qualification.

Draw the mother high and low horizontally. Record how many bars remain contained, where the latest internal signal lies, and the distance to the enclosing boundary. A signal in the middle has different structural opportunity from a reclaim near one edge. The timing-breakouts page combines this containment map with nested inside periods and a broadening formation: the intended expansion is a break that resolves the larger structure, not merely another wiggle within it.

## 7. Broadening formations: map extremes before drawing diagonal lines

In this teaching, a3 is the smallest visible example of range expansion to both sides. Across bars, progressively higher highs and lower lows can form the expanding boundaries often called a megaphone. The practical use is to map the other side of a rejected range and recognize exhaustion when the far side is reached.

The sources emphasize drawing right to left from relevant taken-out extremes and recognizing that lines change as new bars form. Do not force every chart into a visually tidy triangle. First name the actual pivot prices, identify the boundary being reclaimed, and state what would invalidate the proposed crossing. Only then draw lines to make the range readable.

This supports a constructive sequence: locate an expanding range; observe a failed excursion; identify reclaim; wait for the specific trigger and relevant continuity; map the opposite side; then update if price reverses. The original teaching often uses very strong language about the destination. Our operational translation keeps the path conditional, consistent with the September lesson's explicit admission that another reversal prevents the target from being reached.

## 8. Simultaneous breaks add group context

The October lesson looks for related instruments taking comparable prior-period boundaries in the same direction within a shared observation window. Examples in the retained teaching include energy stocks and their sector funds, semiconductor constituents and their ETF, and bitcoin miners with WGMI. The point is to distinguish one stock's isolated break from a sector-wide event.

Build the basket before observing the outcome. Record each constituent's relevant boundary, break timestamp, whether it remains beyond that boundary, and whether the ETF agrees. The docs discuss80% participation as a stronger group condition; the video introduces two or more correlated instruments as the basic idea. These are not identical thresholds. Preserve the source distinction instead of quietly turning either into a universally established cutoff.

The visible evidence is synchronized boundary crossing. The speaker interprets this as institutional algorithmic participation. OHLC alone does not reveal parent-order ownership, remaining order size, or each holder's actual inventory. Treat that explanation as the source's causal model while retaining the observable breadth measure for practice. Likewise, a basket of miners can move as one theme: ten names do not necessarily create ten independent exposures.

## 9. Trigger, stop, target, and reclaim belong in separate fields

The captured docs teach execution through a boundary rather than automatically waiting for a closing bar. That is an important source-specific difference from many classical breakout rules. A source-faithful worksheet needs:

- **Setup:** sequence and larger location before activation.
- **Trigger:** exact boundary and the required trade-through.
- **Reclaim:** earlier failed-break boundary supporting the interpretation.
- **Stop reference:** the source's setup-specific invalidation convention.
- **First objective:** actual prior extreme supplying magnitude.
- **Continuation condition:** what must remain true after the trigger.

The types-of-reversals page distinguishes three stop families: opposite side of the inside bar for2-1-2/3-1-2; beyond the developing entry-bar extreme for specified hammer/shooter/momentum/reversal variants; and just beyond the entry level when entering a bar as it becomes3. It specifically rejects parking an outside-bar entry's stop all the way across that wide3. Its “one penny” language is equity-oriented: an educational translation to another instrument must explicitly use that instrument's executable tick and spread rather than assume a cent means the same thing everywhere.

A developing entry-bar low/high is a live quantity. A reproducible replay must freeze the known extreme at entry and document subsequent tightening. It cannot use the eventual full-bar low to simulate a stop supposedly known earlier. The docs say stops only tighten, but the long video's discussion of optional wider initial stops introduces nuance. Do not silently resolve that into a single automated rule or widen a losing trade by inference. Record the initial convention and any allowed re-entry policy before practice.

## 10. Comparison with classical chart reading

TheStrat and classical price action share raw ingredients but organize them differently:

| Classical lens | TheStrat lens | Keep the distinction |
|---|---|---|
| Higher-high/higher-low trend | Adjacent-bar2u/2d and confirmation/negation | A one-bar directional scenario is not automatically a multi-swing trend |
| Inside candle/consolidation | Scenario1 and compound mother-bar containment | Local compression may remain inside a much larger range |
| Engulfing/rejection candle | Scenario3, hammer/shooter, failed2 | Full-range outside is not the same as body engulfing |
| Breakout and retest | Boundary trigger, reclaim, staying in force | This source does not universally require a retest or closing confirmation |
| Megaphone | Broadening formation and compound3 | An outside bar is a range fact; a drawn multi-swing formation has additional geometry |
| Support/resistance target | Previous extremes supplying magnitude | A numerical sequence still requires room to the mapped target |
| Sector confirmation | Simultaneous breaks | Shared movement adds context but is not independent exposure |

Use both lenses when useful: classical analysis describes location and larger structure; TheStrat provides a concise grammar for exactly which boundaries have changed. Neither needs to be caricatured to make the other useful.

## 11. A complete visual practice routine

1. Fix instrument, session definition, timezone, candle construction, and whether after-hours trading is included.
2. Mask all future bars. Select the decision timestamp before viewing the next result.
3. Mark enclosing mother ranges and larger extremes; record actual prices, not just pixels.
4. Label the last several completed bars1/2u/2d/3; separately mark their colors.
5. Label the current live bar provisionally and note which side broke first if known.
6. Fill the timeframe table; distinguish color alignment from boundary alignment.
7. State the exact setup in words: for example, a bullish2-1-2 against the prior local decline, still within a weekly mother range.
8. Mark trigger, reclaim, structural stop, first objective, and room remaining. If the target is already reached at the intended entry, say so.
9. If using group evidence, freeze the basket and synchronization window before counting breaks.
10. Write three outcomes: activation and continuation; activation then negation; no activation. A setup that never triggers is not a losing entry.
11. Reveal one bar at a time; update only from information available then. Never backfill live-state knowledge from the final OHLC.
12. Grade the reading separately from the eventual outcome: correct classification, context, trigger discipline, target logic, and stop chronology.

The craft to internalize is not predicting every destination. It is describing what has happened precisely, identifying what has not happened yet, and having an explicit response when a developing scenario changes.

## Source guide

Archived versions are pinned in `full_read_ledger.json`. The public teaching URLs below identify the original sources; this pass studied their retained text rather than re-fetching current editions.

- [Scenario basics short](https://www.youtube.com/watch?v=UuTzwwBtVgo)
- [Color conflict short](https://www.youtube.com/watch?v=I0_2uQu5CKo)
- [Outside-bar short](https://www.youtube.com/watch?v=_K8HV1zymtA)
- [Broadening formation short](https://www.youtube.com/watch?v=953TDLF-V-4)
- [Mother-bar short](https://www.youtube.com/watch?v=AngD5h5iuZ0)
- [Chart scale short](https://www.youtube.com/watch?v=Pyjfqud7BeY)
- [September direction lesson](https://www.youtube.com/watch?v=NhjsVNsjDjg), especially01:11–06:28 classification,06:28–09:38 targets,09:38–13:19 containment/scale.
- [October group-participation lesson](https://www.youtube.com/watch?v=i4UzNsv-7Dc), especially01:29–05:12 scenarios,05:15–07:19 opens,10:01–17:01 group examples,17:01–23:10 execution.
- [2-2 reversal](https://thestrat.ai/docs/2-2-reversal/)
- [Types of reversals](https://thestrat.ai/docs/types-of-reversals/)
- [Momentum versus retracement](https://thestrat.ai/docs/momentum-vs-retracement/)
- [Timing breakouts](https://thestrat.ai/docs/timing-breakouts/)
- [Simultaneous-break diversification](https://thestrat.ai/docs/simultaneous-break-diversification/)

### Remaining precision gaps

The linked dedicated FTFC, stops, reclaim, mother-bar, and simultaneous-break pages were not among this assignment's fourteen files. Exact equality handling, gap treatment, session boundaries, synchronization tolerance, and some evolving-entry-bar stop mechanics therefore remain explicit implementation choices pending those primary specifications. Two cataloged streams lack retained transcripts here. Numeric market examples and performance claims in the teaching were not independently market-data audited. These narrow provenance limits do not prevent learning the observable range-reading method above.
