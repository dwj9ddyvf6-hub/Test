# Chart-reading source ledger

Research date: 2026-10-30. IDs resolve references in `chart_reading_craft.md`. “Read” means the substantive web text or selected PDF text was returned and inspected, not that every embedded illustration/video was watched. Sources are firsthand educational publishers, practitioner sites, an authorized publisher excerpt, or a firsthand interview. These are primary evidence for what those practitioners teach, not primary statistical proof of every technique's profitability. No paywall bypass or private access was used. Short source explanations are supplemented by original examples and procedures, not reproduced chapters.

| ID | Source and direct link | Actual coverage/status |
|---|---|---|
| S01 | [ChartSchool: Support and Resistance](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/support-and-resistance) | Read zones, highs/lows, role reversal and trading-range discussion. |
| S02 | [ChartSchool: Trend Lines](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/trend-lines) | Read formation, scale, spacing and validation. |
| S03 | [Fidelity: Basic Concepts of Trend](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/basic-concepts-trend) | Substantive indexed tutorial text read: higher/lower swings and primary/secondary/minor trends. |
| S04 | [ChartSchool: Dow Theory](https://chartschool.stockcharts.com/table-of-contents/market-analysis/dow-theory) | Read assumptions, trend structure and secondary-movement passages; not original Dow editorials. |
| S05 | [ChartSchool: Introduction to Candlesticks](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/candlestick-charts/introduction-to-candlesticks) | Read candle anatomy, bodies and shadows. |
| S06 | [ChartSchool: Bullish Reversal Candles](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/candlestick-charts/candlestick-bullish-reversal-patterns) | Read context, confirmation and pattern examples. |
| S07 | [ChartSchool: Bearish Reversal Candles](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/candlestick-charts/candlestick-bearish-reversal-patterns) | Read context, confirmation, evening-star/dark-cloud examples. |
| S08 | [Fidelity: Stock Volume](https://www.fidelity.com/viewpoints/active-investor/stock-volume) | Read educational explanation of volume as participation/confirmation. No current market recommendation imported. |
| S09 | [ChartSchool: Head and Shoulders Top](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/head-and-shoulders-top) | Read anatomy, neckline confirmation, volume and target convention. |
| S10 | [ChartSchool: Head and Shoulders Bottom](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/head-and-shoulders-bottom) | Read anatomy, prior trend and volume. |
| S11 | [ChartSchool: Double Top](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/double-top-reversal) | Read reversal structure and confirmation. |
| S12 | [ChartSchool: Double Bottom](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/double-bottom-reversal) | Read structure, confirmation and neckline logic. |
| S13 | [ChartSchool: Triple Top](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/triple-top-reversal) | Read formation and breakdown requirement. |
| S14 | [ChartSchool: Triple Bottom](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/triple-bottom-reversal) | Read formation and breakout requirement. |
| S15 | [ChartSchool: Ascending Triangle](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/ascending-triangle) | Read geometry, directional interpretation and confirmation. |
| S16 | [ChartSchool: Descending Triangle](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/descending-triangle) | Read geometry and breakdown. |
| S17 | [ChartSchool: Symmetrical Triangle](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/symmetrical-triangle) | Read convergence and breakout interpretation. |
| S18 | [ChartSchool: Rising Wedge](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/rising-wedge) | Read converging rising boundaries and bearish interpretation. |
| S19 | [ChartSchool: Falling Wedge](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/falling-wedge) | Read converging falling boundaries and bullish interpretation. |
| S20 | [ChartSchool: Broadening Top](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/broadening-top-or-megaphone-top) | Read widening alternating swings. |
| S21 | [Bulkowski: Ascending Broadening Wedge](https://thepatternsite.com/abw.html) | First-party indexed search excerpt read; direct page returned 403. Geometry only used; tables, charts and success-rate methodology not audited. |
| S22 | [Bulkowski: Descending Broadening Wedge](https://thepatternsite.com/dbw.html) | First-party indexed search excerpt read; direct page returned 403. Same limitation. |
| S23 | [ChartSchool: Flag/Pennant](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/flag-pennant) | Read impulse/pause, geometry, volume and continuation. |
| S24 | [ChartSchool: Cup with Handle](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/cup-with-handle) | Read cup, handle and breakout structure. |
| S25 | [Bulkowski: Inverted Cup with Handle](https://thepatternsite.com/icup.html) | First-party indexed excerpt only; direct 403. No claim to have read full page or audited statistics. |
| S26 | [ChartSchool: Rectangle](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/rectangle) | Read horizontal range and breakout interpretation. |
| S27 | [Brian Shannon / AlphaTrends FAQ](https://alphatrends.net/faq/) | Read timeframe, volume and indicator-reference teaching. Not his complete book/course. |
| S28 | [ChartSchool: Price Channel](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/price-channel) | Read substantive price-channel article. |
| S29 | [Adam Grimes: Simple Things Work](https://www.adamhgrimes.com/simple-things-work/) | Main article text read. |
| S30 | [Adam Grimes: Nested Pullback](https://www.adamhgrimes.com/nested-pullback/) | Main exposition through multi-timeframe/nested-pullback discussion read. |
| S31 | [ChartSchool: Gaps and Gap Analysis](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/gaps-and-gap-analysis) | Read definitions and common/breakaway/runaway passages; chapter's distinctions are original synthesis, not page reproduction. |
| S32 | [ChartSchool: Price Relative](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/price-relative-relative-strength) | Read ratio construction and interpretation. |
| S33 | [Wyckoff SMI: Five-Step Method PDF](https://wyckoffsmi.com/wp-content/uploads/2022/06/Wyckoff-5-Step-Method.pdf) | Eight-page PDF text returned; read five-step material and examples across pages 0–6. Screenshot attempt did not yield a verified visual inspection. |
| S34 | [Wyckoff Analytics: Wyckoff Method](https://www.wyckoffanalytics.com/wyckoff-method/) | Read phases/events, effort-versus-result and Composite Man teaching. Overlap with ChartSchool's Wyckoff tutorial treated as duplicated material, not independent corroboration. |
| S35 | [Wiley authorized excerpt: The Art and Science of Technical Analysis](https://catalogimages.wiley.com/images/db/pdf/9781118115121.excerpt.pdf) | Selected passages from the 30-page legal excerpt: chart conventions, pivots/structure vs action, swing relationships and lower-timeframe detail. Full commercial book NOT read. |
| S36 | [Grimes author-hosted flag article PDF](https://www.adamhgrimes.com/content/files/2025/08/grimes0803.pdf) | “Flags: Not Just for Patriots,” selected text on impulse, pause, entry and targets, PDF pages 0–3. Whole journal issue not read; performance assertions not adopted. |
| S37 | [Firsthand interview: Adam Grimes with Rayner Teo](https://www.tradingwithrayner.com/art-and-science-of-technical-analysis-with-adam-grimes/) | Transcript sections approximately 41:42–54:29 read, especially failure tests, obvious levels, timeframe relevance and complex bull-flag example. Whole interview not watched. Transcript appears imperfect in places; no questionable verbatim wording reused. |
| S38 | [Al Brooks: Price Action Glossary](https://www.brookstradingcourse.com/price-action-trading-terms-glossary/) | Read context, flags/double bottoms, breakout/pullback/test/follow-through and failed-failure entries. Not entire course/books; numerical probability assertions not adopted. |

## Access limitations and discoveries not counted as deep reading

- Linda Raschke's [official articles index](https://lindaraschke.net/articles/) was read. Its currently linked [Rituals of Trading PDF](https://lindaraschke.net/wp-content/uploads/2026/01/rituals.pdf) and [Trading Style and Daily Market Regimen PDF](https://lindaraschke.net/wp-content/uploads/2026/01/raschke0204.pdf) timed out twice through the web reader. Earlier legacy upload paths returned 404. The PDFs are not represented as studied.
- Wyckoff Analytics' larger English manual PDF was too large for the web fetch (about 23 MB); not read. Accessible web tutorial and SMI PDF were used instead.
- The Wiley product page for Brooks's *Reading Price Charts Bar by Bar* returned 403. No claim to have read that book.
- CME technical-analysis course overview was discovered/opened, but inaccessible lesson URLs were not counted as studied lessons.
- An initial incorrect candlestick URL was replaced by S05, which was accessible.

## Interpretation provenance

The ledger identifies source-derived definitions and practitioner perspectives. Operational checklists, numerical cases, state labels, comparison grids and exercises in the companion chapter are original educational synthesis. They should be evaluated as proposed practice protocols, not mislabeled as an author's tested system. Pattern orientation is conventional teaching; it does not supply an independently established probability for a particular asset/timeframe. A dated chart application must preserve what was observable then.
