# Technical analysis: working knowledge and reading protocol

## Purpose

Learn and apply technical analysis as a practical visual craft. Start from observed market structure and use methods, indicators and tools to understand its development. This collection combines the user's retained research, firsthand practitioner teaching, public tools, community explanations and actual visual practice. It is a study and reusable reference, not a claim that all possible artifacts have been read or that the learner has become infallible.

## The working sequence

1. **Identify the chart.** Symbol, market/feed, units, timeframe, session, adjustment, scale, latest completed bar and selected cursor. A weekly average on daily candles remains a weekly reference. A rebased axis is not dollar price.
2. **Read the whole scene.** Larger trend/range/transition, current location, distance to major boundaries and room in the proposed direction. Describe the scene before naming a pattern.
3. **Compare swings.** Direction, distance, duration, overlap, depth of correction, closing behavior and participation. Record the pivot date separately from its first knowable confirmation date.
4. **Inspect the relevant area closely.** Distinguish approach, probe, close-through, acceptance, retest and response. Give significant zones an origin and timeframe.
5. **Select the useful method.** Classical pattern, wave interpretation, trend/pullback, Wyckoff sequence, relative strength or auction/profile view. Explain what it adds. Do not require every school to agree in vocabulary.
6. **Use indicators for explicit questions.** Trend reference, momentum character, volatility/extension, or participation. Keep related calculations distinct without pretending they are independent votes.
7. **State the primary and alternate.** Current structure; next observable development; what promotes the alternate; which previous interpretation is then retired. Missing evidence stays missing.
8. **Separate decisions.** Watch-zone arrival, starter condition, add condition, timing failure, larger thesis failure, target response and management are different events. A bullish chart can be a poor new entry.
9. **Check execution geometry only after the read.** Nearby obstacles, actual confirmation price, sensible structural risk and costs. Do not invent a tighter stop or credit a target reached before confirmation.
10. **Preserve the read and learn.** Save the original image/data cutoff, measured observations, interpretation and conditional plan. Reveal later information only afterward in practice; update without rewriting earlier conclusions.

## High-value distinctions learned in this study

- Echo's support flip is a sequence, not a single touch: recovery across a reference, test, then renewed progress. His starter/add and holding policies vary by setup; do not force one absolute rule onto every post.
- An Elliott wave-3 opportunity and a corrective B/X opportunity may both point upward but have different holding and exit logic. Every Fib measurement needs named anchors and degree.
- Saty's conditional map may combine a candle interval, another ribbon interval and an ATR reference period. Do not collapse those clocks into one field.
- Qullamaggie's leader/base/trigger sequence is different from a deep-reset entry. An event-gap case needs information available at the selected intraday decision, not final daily volume retrofitted onto the opening minute.
- Wyckoff phase language and bar-by-bar reading complement each other: the phase is a conceptual map, while changes in swing and candle behavior supply the evolving evidence.
- A P&F double-top buy signal is not the bearish classical double-top reversal. Construction rules determine the meaning of a representation.
- Relative leadership is not necessarily positive absolute return. RRG endpoint quadrant and tail trajectory answer different questions.
- Volume-at-price, close-binned volume and TPO counts are distinct measurements. Their similar-looking profiles do not imply identical information.
- A full chart with later bars visible is useful anatomy practice but not an unseen prediction exercise. A text record of a prior image inspection is not a fresh pixel inspection.

## Where to study next within the delivered collection

- Craft and pattern atlas: `chart_reading_craft.md` and linked source ledger.
- Visual measurement and synthetic teaching plates: `visual_chart_practice.md`.
- Actual retained charts: `actual_chart_readings.md` and `echo_visual/READINGS.md`.
- Echo's newsletters and archived X methods: `echo_email/STUDY.md`, the original syntheses under `public_community/`, and their complete coverage records.
- Existing engines and prior research: `femto_chart_read_learning.md`, `visual_tensor/READING_SYNTHESIS.md`, `corpus_triage/` modules, `saty_and_chart_tool_lessons.md` and `measurement_and_drawing_lessons.md`.
- Broader representations/practitioners/public tools: `advanced_public/advanced_chart_reading_synthesis.md`.
- Frozen practice: `masked_practice/ROOT_PRE_REVEAL_READINGS.md`, `EVALUATION.md` and `LEARNING_REVIEW.md`.
- Discovery/read coverage and remaining queue: the reconciled GitHub inventory and source-read ledgers. These distinguish full reading, selected-section reading, parsed records, viewed pixels and discovery only.

## Boundary for future use

This is learned research guidance. It does not change any existing portfolio, risk budget, engine, alert configuration or trading schedule. On a future authorized chart task, retrieve the relevant method and source settings, perform a fresh actual reading, and show the observable basis for the conclusion. Improve through new examples and retained feedback rather than declarations of mastery.
