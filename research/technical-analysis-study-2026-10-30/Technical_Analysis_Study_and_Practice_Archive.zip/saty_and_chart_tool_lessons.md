# Conditional chart maps: lessons from the archived Saty and ChartPrime research

## Reading scope

Twelve additional files, 95,693 source bytes, were fully read and their local bytes matched the pinned Git blob identities. The exact paths, sizes, commit and links are in `parent_read_batch/full_reads_ledger.json`. These files reside in Silicon at commit 3815c4b223be493704850519656fa7e7b3e3750b. The archived research describes earlier visual inspections; this pass read those reports, not all their underlying images. Public documentation extracts are summarized briefly, not republished.

## 1. Learn to draw a conditional map

The practical contribution of the Saty material is a map with **several relevant clocks and alternative routes**. Price may be approaching a daily ATR reference while the displayed candles are ten-minute and the ribbon represents an hourly or weekly trend. These are three different objects. State each before interpreting the chart.

The archived [official-rules reconstruction](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/saty_mahajan/research/official_rules.md) explains the ATR ladder as prior reference close plus or minus a multiplier of prior ATR. It distinguishes the original ribbon from Pro, and describes the Phase Oscillator as smoothed, ATR-normalized displacement from EMA21. Volume Stack divides volume according to the close's position within the candle; it is not an observed order book. The useful learning distinction is between a price map, trend state, displacement state and close-location display. Treat them as separate descriptions rather than four interchangeable votes.

The [proposed operating playbook](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/saty_mahajan/research/operating_playbook.md) organizes compression, transition, continuation and mean reversion as different setup families. It requires an arming event and selected confirmation, then identifies the nearest obstacle and a lifecycle. This is the archive author's proposed mechanical interpretation, not a universal personal rulebook from Saty.

## 2. What the retained visual casebooks teach

The [YouTube casebook](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/saty_mahajan/youtube/CHART_CASEBOOK.md) contains fourteen detailed historical chart readings. Its strongest transferable distinctions are: divergence inside an intact trend versus actual trend failure; weekly support overlaid on daily candles; local recovery below higher-timeframe supply; and a prospective pattern whose neckline has not broken. The [Community synthesis](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/saty_mahajan/youtube/COMMUNITY_SYNTHESIS.md) describes 200 retained posts and the recurring preparation sequence: prior close, overnight range, ATR levels, ribbon, structural zones, then conditional paths. Option strikes named beside a chart are not underlying entry prices.

The [expanded X visual survey](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/saty_mahajan/posts/x_visual_survey.md) shows the method evolving across versions and emphasizes structure alongside indicators. Its older AMZN/FB examples describe a sequence of ribbon change, revisit, entry, partials and later exit rather than an immediate trade on a crossover. The [additional X notes](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/saty_mahajan/posts/x_additional_visual_notes.md) add an important management-reading distinction: a stopped runner after earlier profit-taking is different from a full initial-position stop. A nearby higher-timeframe barrier can interrupt an otherwise plausible path toward a more distant target.

The [Bluesky survey](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/saty_mahajan/posts/bluesky_visual_survey.md) contributes examples of supply becoming demand, conditional additions, repeated ribbon rejection and event-shock recovery. Dashed projected paths are scenarios, not candles. A chart header can describe a selected historical bar rather than its last bar. These are practical visual-reading details that matter when learning from published examples.

## 3. Original worked exercise: a target is also a decision point

Invented chart: price declines from a prior close of 100 toward support at 97.5, with a falling hourly ribbon around 99. The smaller timeframe reaches an unusually low oscillator reading. There are three different questions:

1. Is the original downward path still progressing? Inspect lower highs, retained closes and the next support test.
2. Can a local rebound occur? Inspect rejection at 97.5, a higher test, then a break of the smaller reaction high.
3. Has the hourly trend reversed? A rebound toward 99 is not enough by itself; inspect whether price can retain the ribbon region and form a new higher low.

A rebound can satisfy the second question while leaving the third unresolved. A short-term target at 99 therefore need not imply a longer-horizon bullish forecast. Conversely, failure of 97.5 opens a new downside route, not a reason to keep calling the oscillator extreme a floor.

Draw all three paths before revealing later candles. Label the timeframe of each confirmation. This exercise trains a useful skill: holding several conditional ideas without treating them as contradictory predictions.

## 4. Interpret commercial indicator vocabulary precisely

The retained [ChartPrime order-block documentation](https://docs.chartprime.com/market-dynamics/order-blocks.md) describes inferred volume zones with relative-volume shares and strength categories. Those shares compare displayed blocks; they are not the probability that a level will hold. The [reversal guide](https://docs.chartprime.com/market-oracle/reversal-signals.md) treats reversal signals as contrarian assistance and distinguishes ranging from trending conditions. The [trend-signal guide](https://docs.chartprime.com/market-oracle/trend-signals.md) describes trend states, tuning choices and profit-taking annotations. The [oscillator guide](https://docs.chartprime.com/prime-oscillators/prime-oscillator.md) describes its centerline, colors, divergence, bands and extremity labels. These are product semantics, not interchangeable definitions of every similarly named tool.

For practical learning, open the legend before reading the marks. Write what each mark claims to measure, whether it describes an event or a continuing condition, and what price behavior would make it useful in the current location. A visually similar green arrow in another system may have an entirely different definition.

The archived [Milkman manual extract](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/rea-teardowns/saty-stack/references/milkman-manual-2.1-2.4.md) is a third-party interpretation. It includes implementation choices such as session treatment and wick clipping that must not be silently imported into the original author's indicator definitions. The lesson is to preserve lineage: author method, community adaptation and our own operational rule are separate layers.

## 5. A reusable method-comparison card

When studying any chart teacher or tool, complete these fields:

- **What is the map?** Horizontal levels, moving references, wave anchors, profile areas or volatility ladder.
- **What is the state?** Trend, range, transition, extension or compression.
- **What is the trigger?** Exact price response, completed bar, crossover, retest or sequence.
- **What is the next obstacle?** The nearest meaningful opposing structure, not merely the most ambitious projection.
- **What changes the interpretation?** Local entry failure, larger structural failure, or lack of progress.
- **How is it managed?** Initial position, additions, partials, residual exposure and new entries.
- **Which clock belongs to each feature?** Candle interval, reference interval, session and time when it was known.

This card allows useful techniques to be combined without flattening different discretionary styles into one rigid system. It also preserves the human lesson inside the archive's engineering: the chart supplies an evolving situation, and the analyst chooses the relevant relationship and next decision.
