# Advanced chart-reading: distinct practitioner workflows and public tools

Research date: 2026-10-30. This is an extension of the existing study, not a claim to have read all internet material. Scope: how to read, compare, annotate, and practice charts. Source descriptions below are bounded summaries; the exercises are an original proposed training design, not documented performance results. No software was installed or executed from the reviewed repositories; no accounts, subscriptions, follows, or external writes were made.

## The most useful additions

1. **Change the question when changing the chart.** A price chart asks what the instrument did; a ratio chart asks how it did against something else; an RRG compresses relative trend and relative momentum; a P&F chart filters movement by box and reversal rules; a profile reorganizes activity by price. These are complementary representations, not interchangeable confirmations.
2. **Observe sequences, not only shapes.** A directional attempt followed by acceptance, a rejected breakout, or the first retracement after momentum expansion teaches more than naming the last candle.
3. **Make chart construction part of chart literacy.** Box size, close versus high/low, session boundaries, price-row size, and whether a profile uses volume or TPO counts can change the visible setup.
4. **Separate recognition practice from execution practice.** A replay chart can teach decisions with a hidden future without supplying realistic fills, intrabar paths, fees, or market impact. Use it for the skill it actually implements.

## 1. Relative strength and rotation: reading leadership without confusing it with direction

### Originator-hosted RRG guide — full six-page text read; one chart inspected

The [Thomson Reuters RRG guide hosted by Relative Rotation Graphs](https://relativerotationgraphs.com/wp-content/uploads/2024/10/Relative-Rotation-Graph-Thomson-Reuters-Guide.pdf) is an older, copyright-2013 guide, despite its recent upload path. Its conceptual explanation remains the relevant material here; its platform limits are historical, not verified current product facts. JdK RS-Ratio is horizontal, RS-Momentum vertical, with the center at 100. These are proprietary formulas. Relative leadership can coexist with an absolute loss; smooth clockwise rotation is not guaranteed.

**Actual visual reading:** page 2 uses OMXC20 and seven daily tail observations. CARLb.CO and PNDORA.CO remain in the leading quadrant while their tails descend toward the horizontal boundary. TDC.CO lies in improving, left of the relative-trend boundary. This teaches an important distinction: a green endpoint need not mean improving momentum. Color classifies the current quadrant; trajectory adds information. The PDF prose mistakenly calls blue “LEADING”; the chart itself labels blue “IMPROVING.” Do not propagate the typo.

### Dorsey Wright FAQ — full methodology section read

[Dorsey Wright’s P&F University FAQ](https://oxlive.dorseywright.com/university/faq.html) explicitly separates a bullish absolute-price chart from negative relative strength: a stock can rise while trailing a faster-rising index. It compares a technically elaborate breakout with weak context against a simpler breakout supported by trend and relative strength, preferring the latter. It also describes adjusting box size for perspective rather than automatically discarding the default view. These are methodology preferences, not measured probabilities.

**Original drill: two-axis leader sheet.** Select a fixed historical date and six instruments. Without later data, assign each to one of four cells: price rising/relative line rising; price rising/relative line falling; price falling/relative line rising; price falling/relative line falling. Then ask a separate question: is relative improvement accelerating or fading? Before seeing outcomes, record which instruments deserve closer examination and which have no actionable price location. The learning objective is to avoid buying “least weak” as if it meant “strong uptrend.”

### Community application — main post and first discussion read, not entire thread

[u/kronegker’s r/thetagang post](https://www.reddit.com/r/thetagang/comments/m0c0pv/anticipating_the_rotation_relative_rotation_graphs/) shows a practitioner using sector/ETF rotation to organize options ideas. The thread raises horizon alignment: a rotation sample should relate to the intended trade duration. Its option actions and performance implications are the author’s proposal, not a recommendation here. This is useful experiential evidence of how a chart becomes a watchlist, but the public post does not establish that its custom calculations exactly reproduce licensed JdK indicators.

**Original annotation format:** benchmark; absolute trend; relative trend; relative momentum; observation interval; tail length; relevant support/resistance; next observable event. Do not count the same price-derived information repeatedly as independent evidence.

## 2. Point-and-figure: learn the representation before the pattern vocabulary

### Nasdaq Dorsey Wright construction — complete substantive text read

[Point & Figure Basics](https://nasdaqdorseywright.zendesk.com/hc/en-us/articles/12906431410829-Point-Figure-Basics) documents a three-box reversal and an intraday-high/low method. When one daily bar could both extend and reverse a column, the current-column extension takes precedence in its method. Columns are movement events, not equal units of elapsed time. A P&F double-top buy signal means an X column exceeds the preceding X-column top; it is not the bearish two-peak reversal familiar from bar charts. The page separates short-term signals from the bullish support/bearish resistance line used for trend context. Smaller boxes reveal finer movement; larger boxes suppress it.

### Public tool: swaschke/pypnf

Read the [complete README](https://github.com/swaschke/pypnf/blob/main/README.md), package initializer, and first 230 lines of [chart.py](https://github.com/swaschke/pypnf/blob/main/pypnf/chart.py), not the complete implementation. The interface supports close, high/low, low/high, HLC, and OHLC methods and absolute, ATR, classic, and logarithmic scales. It exposes a box matrix, column indices, trends, trendlines, and breakouts. README examples include ASCII charts, useful for manual verification. The full repository was not audited or tested. Readme/core identify GPL licensing; a permissive header remains in the initializer, so anyone redistributing should resolve license scope rather than assume uniformity.

**Original manual exercise:** choose a simple close series and a fixed one-unit box with three-box reversals. Plot it on paper. Label every new column with its first date. Now repeat with two-unit boxes, without changing the price series. Explain which resistance levels survive, which disappear, and why the passage of ten calendar days may add no column. Then compare a close-only version with an explicitly specified high/low version. A disagreement is initially a construction question, not proof one chart reader is wrong.

**What to inspect before trusting a P&F chart:** adjusted versus unadjusted prices; price sampling; box rule; reversal count; handling of same-bar ambiguity; initial state; treatment of the still-forming last bar. Treat ATR-based box construction as a separate audit question: determine which observations set the scale and whether extending the dataset changes earlier geometry. That last check is proposed here, not a finding that this library necessarily repaints.

## 3. Profiles: separate where price visited, how often, and how much traded

### Sierra Chart implementation reference — selected substantive sections read

[Sierra’s TPO documentation](https://www.sierrachart.com/index.php?page=doc/StudiesReference/TimePriceOpportunityCharts.html) distinguishes TPO count from volume count, documents POC tie-breaking, value-area expansion, and optional two-level counting. Initial balance is configurable in subperiods; two 30-minute periods produce an hour, not a universal definition for every instrument. It supports both consolidated profiles and each subperiod in its own column, plus splitting/merging. Its comparison checklist stresses matching sessions, row increments, percentages, and data resolution; it recommends tick-by-tick data for volume-profile accuracy. Read sections: elements, display modes, splitting/merging, POC/value-area calculation, and discrepant-value troubleshooting. Not all 1,525 web lines were read.

### Public tool: bfolkens/py-market-profile — full README and core module read

The [core implementation](https://github.com/bfolkens/py-market-profile/blob/master/src/market_profile/__init__.py) rounds each **Close** upward to a row, then groups by that rounded close. In volume mode it sums each record’s volume; in TPO mode it counts closes. This is valuable for reproducible histograms, but feeding daily OHLCV does not reconstruct every intraday price visited or the actual volume traded at each price. The [README](https://github.com/bfolkens/py-market-profile/blob/master/README.rst) demonstrates daily AMZN data and exposes initial balance/open-range functions; those function names do not magically provide missing intraday granularity. Its value-area tie logic also differs from Sierra’s documented simultaneous inclusion of equal adjacent rows. No runtime testing occurred.

### Tim Racette’s practitioner walkthrough — complete article body read

[EminiMind’s guide](https://eminimind.com/the-ultimate-guide-to-market-profile/) walks through a TPO value-area calculation and compares developing value with prior value. It treats range extension, trending profiles, and double distributions as interpretable day structures, while saying the profile is not an entry/exit method by itself. The normal-distribution language and day-type tendencies are the author’s teaching heuristics, not a requirement that every profile be bell-shaped. Its worked method combines two adjacent rows; that is a concrete reason implementations may differ even before data quality enters the discussion.

### Forum worked explanation — complete main post, partial comments

[u/bmac1993’s profile walkthrough](https://www.reddit.com/r/Daytrading/comments/iw7u69/introduction_to_market_profile_volume_profile/) explains a combined time/volume display and a poor-low interpretation. It is useful because it makes the visual reading explicit, rather than merely listing terms. However, it sometimes speaks generically about value and POC while showing both measures. Its expectation that a poor low will be repaired is practitioner interpretation, not a deadline or certainty. The text names 9/20/2020 for the example, but the underlying instrument/session was not independently resolved here. Images linked from this forum were not visually inspected in this pass.

**Original observation exercise:** take two profiles with similar overall outlines. First inspect only their final histograms and write a neutral description. Then reveal subperiod columns. Ask which high came first, whether later trade returned to the same prices, and whether the last portion was building new activity outside old value or merely probing and retreating. The skill is distinguishing two sessions that finish with similar distributions but took different paths.

**Original configuration card:** symbol/contract; timezone; session start/end; overnight included?; bar or tick source; row increment; TPO subperiod; volume/TPO mode; value percentage; tie rule; composite start/end; completed versus developing. Keep the card next to the screenshot so later review compares like with like.

## 4. Discretionary setups as sequences: Raschke and Qullamaggie

### Raschke — all four pages of interview text read

The [March 2004 Active Trader interview hosted on Linda Raschke’s site](https://lindaraschke.net/wp-content/uploads/2026/03/raschke_pt2_0304.pdf) gives an S&P example: consolidation breakout, new momentum, ADX above 30 on a specified timeframe, then its first retracement to the 20-period EMA. It follows the sequence from 30-minute to hourly and 120-minute opportunities; each timeframe must independently meet the condition. Her 3–10 oscillator uses simple averages, with a 16-period simple average of their difference—not an unmodified standard exponential MACD. She also distinguishes forecasting a price being **traded through** from forecasting the subsequent **close**. Reported percentages are historical source claims, not recalculated contemporary odds. Text and figure captions were read; the chart bitmap was not successfully inspected through the available screenshot response.

**Original sequence card:** expansion event → momentum evidence → first pullback → response at the reference → opportunity expires. Record all five before choosing a trade label. Distinguish a pullback in an established move from repeated tests after that move has lost urgency. Do not silently replace “first pullback” with “every touch of the moving average.”

### Qullamaggie — complete EP article body and TEAM before/after charts inspected

[His EP mastery article](https://qullamaggie.com/how-to-master-a-setup-episodic-pivots/) describes building a large historical screenshot/news database, then recognizing variants. His definition emphasizes a substantial gap and exceptional early volume, often after prolonged quiet trading, followed by an opening-range trigger with a day-low stop. These are his preferences; the article itself admits stopped-out trades. Its aspirational financial claims are not adopted.

**Actual chart reading:** [TEAM before](https://qullamaggie.com/wp-content/uploads/2021/11/team1-1024x969.png) shows prolonged overlap, a later shelf near the old high, then a conspicuous upside gap with expanded volume. [TEAM after](https://qullamaggie.com/wp-content/uploads/2021/11/team2-1024x964.png) reveals a sustained advance and later earnings-gap area. The daily image does not establish the intraday entry, stop sequence, fills, or whether a particular trader survived the pullbacks. “Before” here already contains the event bar: it is not a fully pre-event prediction test.

**Original case-library schema:** event timestamp; what was known then; higher-timeframe structure; pre-event compression/extension; relative volume measured at a stated elapsed time; first eligible decision; invalidation; no-trade reason; subsequent path; lesson. Keep a separate page for visually similar non-examples. The point is to build discriminating perception rather than accumulate attractive screenshots.

## 5. A daily observation routine and learning loops

### Dalton’s routine — full article read

[Jim Dalton’s preparation article](https://jimdaltontrading.com/routine/) starts monthly, weekly, then daily, allowing different states on each. He reviews the prior session’s attempted direction, value migration, relative volume, profile shape, and behavior at predefined references. He prunes obsolete levels, prioritizes longer-timeframe references within reach, builds up/range/down scenarios, and revises them after overnight inventory and opening-location review. This is a workflow for contextual judgment, not a requirement that all three timeframes agree.

### Dalton on repetition and observation — two short articles fully read

[Repetition with Variation](https://jimdaltontrading.com/repetition-with-variation-the-year-is-ending/) argues for task-specific practice and adaptation to changing conditions. [Learning to Observe](https://jimdaltontrading.com/welcome-to-short-term-trading-learning-to-observe/) emphasizes accumulating observations rather than immediately acting on each new insight. These are practitioner learning philosophies, not clinical evidence about cognition. His stronger claims about intuition, hidden intent, or superiority to mechanical methods are not established by these articles. A third, longer mastery page was only partially read and is not treated as completed.

### Public replay tool — full README and roadmap read, not executed

[Market Replay Trainer](https://github.com/SigaukeCogitater/trading-simulator-app) offers a chart/replay core, drawing tools, and multi-timeframe replay. The README says the public demo uses synthetic candles; real-data support is currently local-proxy crypto, not verified real stocks/forex. The [roadmap](https://github.com/SigaukeCogitater/trading-simulator-app/blob/main/docs/ROADMAP.md) says order simulation, account state, fees, journal, scoring, and review analytics are not yet built. It also distinguishes a visually hidden future from server-side anti-cheat: the browser currently holds the full loaded series. Intrabar paths are synthesized. Thus this is a promising visual-practice prototype, not a verified fill simulator or evidence of a strategy’s performance.

## 6. Original integrated practice program

This program is a proposed application of the reading, not a source claim or tested curriculum.

### Session A: representation fluency

Take one fixed interval and view price, relative-price ratio, P&F, and profile. For each, write two things it makes easier to see and two things it hides. Example: an equal-width P&F column should not be interpreted as equal elapsed time; a final profile compresses sequence; an RRG cannot directly give a stop price. Finish by answering: which representation is relevant to my current question?

### Session B: a left-to-right narration

Hide later observations. At five successive checkpoints write only: location, directional attempt, response, continuation/failure condition, and uncertainty. Avoid predicting the exact next candle. Reveal the next section and update only what changed. Save both versions so the later explanation cannot overwrite the original perception.

### Session C: contrastive pairs

Choose two charts that share a label but differ in context, then two that look different but imply a similar decision. Examples: upward break in a rising leader versus upward break in a relative laggard; opening outside old value and staying outside versus opening outside and returning; a first retracement versus a sixth test. Explain the decisive difference in one sentence, not a list of indicators.

### Session D: execution feasibility, kept separate

For a selected setup, specify the actual available order, invalidation, plausible gap risk, and missing intrabar information. If a bar contains both entry and stop and no lower-resolution record resolves the order, label the path ambiguous. Keep that uncertainty separate from whether the chart structure was correctly recognized. A strong recognition score does not prove tradable expectancy.

### Session E: teach-back and calibration

Explain a case to a reader without using the setup’s name. Give the visible observations, competing interpretation, and the next piece of evidence that would distinguish them. Ask the reader to reconstruct the same decision boundary. If they cannot, the rule may be too vague—or a construction setting may be missing.

### Review rubric

- **Observation fidelity:** Are claims visible at the timestamp, or imported from the future?
- **Context:** Are market/sector/benchmark and higher-timeframe states explicit where relevant?
- **Construction literacy:** Could another reader reproduce the chart?
- **Sequence:** Is attempted action separated from market response?
- **Decision clarity:** Is there an actionable condition, invalidation, or reason to wait?
- **Adaptation:** Does the explanation change when evidence changes, without rewriting history?
- **Transfer:** Can the distinction be recognized in another instrument or a less textbook example?

Measure progress by fewer category errors, more reproducible annotations, faster recognition of genuinely relevant differences, and better explanations of why a case is not ready. Keep financial outcomes as a separate later validation task, not the sole score for the perceptual exercise.

## Access and scope boundaries

- Raschke PDF: web text was accessible; an ordinary local download returned HTTP 406. No header spoofing, proxy, or access-control workaround was attempted. A screenshot tool returned references but no image content usable for inspection; therefore no claimed visual verification of that chart.
- Qullamaggie’s general three-setups URL returned a tool accessibility error; the separately accessible EP article was read normally. No claim the inaccessible page was read.
- Dalton TPO-versus-volume page timed out; its content was not inferred from its title.
- pypnf raw README URL had a cache miss; the ordinary authorized GitHub connector supplied the public file. This was not an account/login bypass.
- The RRG guide’s final-page screenshot failed, but complete text was read; local PDF retrieval and page-2 rendering succeeded.
- No books, paid courses, entire repositories, or whole discussion communities were claimed read. X was not directly inspected in this extension; use the parent study’s separately documented X coverage.
