# Learning the chart tools: structure, candles, context, and evidence

This is a positive operational study of technical analysis, not an attempt to invalidate it. These lessons come from complete static source readings listed in `reads_manifest.json`. They describe what the sources compute and teach, not a claim that every tool is deployed or every setup profitable. Exact pinned source URLs are in that ledger and the candidate inventories.

## 1. Start with the price situation, then select annotations

The `x_charts` renderer distinguishes **deep reset** from **leader dip**, an important analytical distinction often lost when applying the same indicators to every picture. In a deep reset, map the old high, subsequent low, declining supply line, overhead shelves, anchored VWAP from the high, and retracements of the decline. In a leader dip, map the prior up-leg, rising moving averages, controlled retracement, higher-low area, and anchored VWAP from the leg's origin. A rally into declining overhead structure is not equivalent to a pullback into rising support.

The source's automatic regime classification (rising EMA200 and proximity within 25% of highs), prior-60-bar anchor, half-ATR stop buffer, and 2-ATR extension check are **local engineering choices**, not universal technical-analysis laws. The reusable skill is selecting anchors appropriate to the actual swing and checking whether price is already too far from the structural decision point.

The v2 drawing discipline is especially valuable: put only thesis-bearing objects on the chart. Label entry, structural invalidation, first obstacle, next objective, relevant pattern, and any wave count that actually affects the decision. A visually attractive chart full of unrelated lines is less useful than a sparse chart where every object explains a decision. Preserve a sidecar linking each annotation to its exact date/price anchor and reason.

## 2. A chart read belongs inside a market read

`CHARTSLECTOR/README.md` describes a wider workflow than a four-panel chart: universe ranking, relative strength and relative volume, breadth, risk appetite, theme leadership and rotation, daily/weekly/hourly context, candle stage, ATR distance, gaps, and intraday pivots. The lesson is to distinguish **good-looking geometry** from **a well-positioned opportunity in its market environment**. The repository explicitly separates disclosed inputs, reverse-engineered approximations, and generic substitutes; maintain these distinctions instead of treating every recreation as identical to the source system.

## 3. Candles are a language of measured relations

`CANDLES/code/cd_patterns.py` implements families of shapes rather than one magical textbook constant. Its primitives include body fraction, upper/lower wick, close location, range relative to ATR, direction, gaps, containment and prior trend. A hammer and hanging man can share morphology while differing in the preceding trend; likewise inverted hammer versus shooting star. That is a direct implementation of **shape plus location plus sequence**, not shape alone.

The library separates body engulfing from full-range engulfing; harami containment from engulfing; morning/evening star transitions from single-bar rejection; three-inside/outside confirmation from their two-bar precursors; windows/gaps from ordinary large candles. Its ICM variants distinguish an anchor rejection/engulfing candle from the following realized distribution candle. This matters temporally: if the confirmation bar is needed to name the completed formation, the signal is only known at that bar's close—not retroactively at the anchor.

For visual practice, narrate a candle before naming it: where did it open, how far did each side push, where did it close within its range, what neighboring level was tested, and did the next bar accept or reject the move? Names then become compact descriptions rather than substitutes for observation. The grid thresholds in this implementation are research variants, not authoritative definitions or proof of efficacy.

## 4. Moving-average ribbons encode multiple distinct facts

The Saty free ribbon uses 8/21/34 EMAs and separate 13/48 conviction transitions. A fast-cloud change, slow-cloud state, and fresh conviction transition are not interchangeable. Its candle colors encode candle direction *relative to a bias average*: an up candle below bias is a bounce, not automatically bullish trend; a down candle above bias is a pullback, not automatically bearish trend. Read the relationship before interpreting the color.

The Phase Oscillator normalizes distance from EMA21 by three ATRs and smooths it with EMA3. This teaches an important visual distinction between **direction**, **extension**, and **compression**. Positive does not necessarily mean early; extreme does not necessarily mean reversal; compression says something about range geometry, not by itself the direction of resolution. Its labels such as accumulation/distribution are oscillator-zone names, not independent evidence of actual institutional inventory.

The repository's corrected SPEC accurately highlights that compression is recomputed each bar, not latched. Early release can occur while band width remains within the nominal ATR envelope if the specified expansion condition is met. A port that remembers compression until a later reset would teach the reader a different indicator. Higher-timeframe values and sessions also matter: distinguish a forming higher-timeframe observation from a closed confirmation, and do not silently mix extended-hours with regular-session calculations. The archived code contains historical-lookahead concerns in warped oscillator mode; preserve useful visual semantics without treating leaked historical displays as real-time knowledge.

Volume Stack computes a close-location allocation: volume multiplied by the close's fractional distance from low versus high. This is a **buy/sell proxy**, not exchange aggressor-side tape delta. Its useful visual information is where a volume-bearing candle finished; do not pretend it observes actual orders or identities.

## 5. Market structure and profile tools supply a map

The ChartPrime source documentation separates swing versus internal structure sensitivity, continuation breaks versus changes of character, trend lines/channels/triangles/wedges and failed swings, wick versus body anchors, and classical versus volatility-based objectives. The useful skill is specifying which structural scale is being read and how it would be invalidated. A small internal change can coexist with an intact larger trend. Confirmed pivots arrive after their pivot bar, so their retrospective placement is not the time at which they became observable.

Volume-profile lessons include choosing the anchored window, identifying a point of control and high/low-volume areas, and relating those areas to the current auction. Window selection changes the map. Thin zones can describe less prior two-sided activity; they do not guarantee fast travel. Fair-value gaps and vendor liquidity/order-block drawings are observed price-derived zones or proxies, not direct proof of hidden institutional orders. Keep the map useful without inventing what cannot be seen.

## 6. Strong setup study separates impulse, base, trigger and management

The Qullamaggie rule registry/inferred-rules files distinguish primary stated rules from the researcher's quantified approximations. Their core structure is an antecedent strong impulse, orderly contraction or higher-low base, support/surfing behavior, volume dry-up, relative leadership, market context and a breakout trigger. These are relational facts, not independent boxes whose simple count creates certainty.

An attractive base is not yet a triggered entry, and a valid entry is not a full management plan. Record the first structural failure, opening-range or breakout reference where relevant, what continuation should look like, how extension changes the next action, and which moving average or swing is relevant to holding versus exiting. Preserve inferred numerical defaults as inferred—never attribute a coder's convenient threshold to the original trader.

## 7. Multiple screenshots require source discipline

The full `chart-evidence-synthesis.ts` read shows an evidence-coordination layer, not a stand-alone vision model. It binds screenshots to manifests, verifies symbol and dates, checks exact/perceptual duplication, compares claimed zones with canonical data, clusters nearby levels, and surfaces cross-timeframe conflicts. Its engineered tolerance and freshness windows are local defaults.

The general skill is excellent: several screenshots from the same source or near-identical image are not several independent confirmations. A trend label on a daily image can legitimately differ from a weekly label. Explain the scales and timestamps before averaging opinions. A numeric zone should have a structural anchor; do not manufacture precise support from a blurry chart. The code's regex trend-text parsing is much narrower than real visual comprehension, so it must not be mistaken for all of chart reading.

## 8. Reusable read sequence

1. Establish instrument, timeframe, session, scale, data timestamp and whether the final bar is closed.
2. Describe the broad trend/range and the current lifecycle stage.
3. Map the few consequential swing extremes, shelves, supply/demand zones and anchors.
4. Describe the latest approach: impulse, controlled pullback, compression, failed break, repair or extension.
5. Read candles and volume as interactions with that map, not isolated labels.
6. Add only indicators that answer a specific unresolved question.
7. State a primary conditional scenario, plausible alternative, trigger, structural invalidation and first obstacle.
8. Separate what is observed now, inferred now, and still awaiting confirmation. Record what would change the read.

The goal is disciplined visual fluency: precise observation, coherent context, useful conditional decisions, and learning from subsequent behavior. None of those requires pretending every archived script is correct or adopting old repository mandates to kill technical analysis.

## 9. Complete archived visual ledger: 279 observations

The 60,404-byte inspection ledger was read end-to-end: Echo100, BP100, Mind79, Long Investor0; its historical collection was explicitly ended by the user before the original target. This is our reading of all archived observations, not fresh inspection of279 images. Repeated dated charts show a particularly useful learning surface: an unchanged macro thesis can coexist with changed near-term subwaves, a new alternate, different average selection or a tighter crop. Distinguish a genuine new state from an identical repost.

Across the ledger, conditional multi-stage narratives dominate: rebound into resistance before deeper correction, terminal corrective zone before a larger advance, or a shallow primary versus deeper alternate. Solid versus dotted paths, label degree, localized Fibonacci segments, historical versus projected brackets, and explicit invalidation rays carry separate meanings. A large future arrow is a scenario, not a present signal or a calibrated probability. Some charts appropriately omit waves, averages or Fibonacci entirely when a wedge/channel is the central information.

The most reusable examples are DLO breakout-volume versus quiet-retest-volume comparisons, higher-timeframe correction alongside lower-timeframe impulses, indicator divergence tied to corresponding price pivots, and explicit primary/alternate switches at structural levels. Preserve the timing of a scenario revision rather than retroactively crediting the final count. Whitespace and chart framing must show the projected scenario without crushing the actual candles into illegibility.
