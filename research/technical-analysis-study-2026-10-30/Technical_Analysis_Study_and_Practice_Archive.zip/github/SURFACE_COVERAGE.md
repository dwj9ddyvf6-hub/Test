# GitHub research surface coverage — 2026-10-30

## Boundary and interpretation
This inventory covers the 33 repositories returned by the connected GitHub repository listing for `dwj9 ddyvf6-hub`, with pagination through the empty final page, plus the reachable branch and release metadata described below. It is **not all of public GitHub**, every historical commit, or proof every indexed object has been read. Public ecosystem study is separately documented by the main research team.

A file-location row is one repository/commit/path; exact Git blob SHA deduplication identifies repeated bytes. Broad pathname matches deliberately over-include vendor code, generated content, unrelated support/pattern names and historical copies. A candidate is not yet confirmed substantive relevance. Read statuses distinguish complete static reading, selected sections, complete structured-corpus parsing, and fresh pixel inspection.

## Surfaces
- **Repositories:** 33 enumerated; second listing page empty. Only one reports code-search indexing, so tree walking—not search hits—was the main discovery method.
- **Default trees:** 32 reachable repository roots, including large trees recursively subdivided. InfinityBlade tree fetch returned404 both default name and its listed branch SHA; release metadata remains reachable. Child inventory covers Agentic and Claude roots/partitions.
- **Branches:** 504 named branch entries after paging Femto-lean through115 and ClaudeDesk through221. Identical commit roots are traversed once. ClaudeDesk's221 branch trees are complete with no gaps. All reachable selected branch roots now have complete tree closure; InfinityBlade alone returned404. Cross-repository identical commit trees are reused while retaining each repository location. `final_tree_coverage.json` and `branch_file_counts.json` are the authoritative final boundary. Older `branch_remaining_gaps.json`, `merged_summary.json`, `ta_candidates*` and `ta_allrefs_candidates*` are superseded intermediate snapshots and must not be used as final coverage. Successful recursive responses are checked for truncation; oversize transport failures are subdivided rather than treated as empty.
- **Releases:** all33 repository release lists fetched,15 releases total,532 asset metadata rows. Asset lists with128 and300 entries separately paginated to termination, confirming totals. Combined asset size109,352,230,702 bytes includes general backups, alternate data and encrypted archives, not exclusively TA. Asset names/URLs/sizes are in `release_assets_inventory.json`; payloads are not read.
- **Tags:** generic tags endpoint rejected as unsupported by this connector (400). No further attempt to bypass that unsupported surface. Release-associated tag names are recorded; independent tag-only histories are unenumerated.
- **Git LFS:** all11 distinct default-tree `.gitattributes` blobs read.12 declared LFS objects in foliotend-research-operations-archive verified as actual UTF8 pointer files, not payloads; their declared underlying bytes total4,118,021,724. Pointer OIDs/sizes preserved in `lfs_pointer_reads.json`. LFS payloads not downloaded. Midna attributes explicitly say model-weight parts are ordinary Git blobs rather than LFS.
- **Archives and binaries:** ZIP/tar/sqlite/parquet/model/image paths and release assets are indexed where visible. The GitHub connector rejects non-UTF8/binary downloads; archive internal entries and nested archives have not been independently enumerated merely by seeing their outer names. Some archives contain encrypted chunks; no decryption or key-seeking attempted. Existing extracted counterpart trees can be studied, but are not presumed complete replacements without a matching manifest.
- **Images:** discovered and deduplicated metadata are distinct from pixels viewed.12,950 historical chart-review records were completely parsed; this does not mean12,950 images freshly viewed. Selected new pixel inspections are separately logged by separate image-inspection ledgers.
- **Issues/PRs:** all33 repository issue collections paginated to termination;57 items (42 issues,15 PRs).12 broad TA/tool candidate PR titles and full collection bodies read; comments, review threads, patches and full PR histories remain unenumerated/unread. See `items_surface/`. **Actions artifacts:** collection endpoint explicitly unsupported400; stopped endpoint family without retry. **Discussions/wiki:** unenumerated.
- **Commit history:** branch tips captured with exact commit references, not every prior commit. Some live branches changed during collection (notably Midna); old and newly listed tips are preserved, not silently conflated.

## Read integrity
Reviewed source identities were checked against pinned Git blob hashes. No retrieved code was executed, no repository changed, and no deployment performed.

## Honest completion condition
A complete file discovery pass means all reachable selected roots have non-truncated tree closure, with inaccessible roots explicitly listed. A complete study of that discovered corpus additionally requires every relevant substantive unique blob and every intended visual/record surface to be read at its stated level. The latter remains an explicit queue, not a blanket claim of mastery or omniscience.

## Final reconciled counts (current authoritative snapshot)

- 498 reachable repository/commit roots out of499 across504 named branches. One unavailable root: InfinityBlade404.
- 3,430,274 file locations,382,823 unique Git blobs;0 unresolved subtree SHAs.
- 181,081 broad pathname/repository-matched candidate blobs;22,665 text/code/document candidates. These deliberately include noninstructional/vendor/operations false positives for semantic triage.
- 133 distinct Git-source blobs with completed text review: 128 complete raw text/code and 5 full extracted/visible-text reviews. They include receipts/nonlesson files; they are not 133 independent methods. Eight other blobs have selected-section reviews.
- 133 JSON sources parsed into12,950 unique chart-review records. This is not fresh viewing of12,950 charts.
- 24 distinct source image files freshly inspected, SHA256 deduplicated across all visual ledgers. Synthetic teaching figures and4 masked practice variants are separate, not extra original source charts.

Authoritative files: `final_tree_coverage.json`, `final_candidate_summary.json`, `study_coverage_summary.json`, `merged_full_source_reviews.json`, `final_visual_coverage.json`, `repository_learning_map.json`. The final candidate queue is `ta_final_candidates.json`/`.csv`; all location rows are streamed in `final_all_file_locations.jsonl.gz`, with candidate locations in `final_candidate_locations.jsonl.gz`. Full tree closure is discovery, not full reading.

## Gitlinks are a separate surface

The tree inventories also expose 33 distinct non-blob Gitlink commit entries, including captured worktrees and external indicator/source submodules. Their paths and pinned commit IDs are retained in `nonblob_tree_entries.json`. They are not counted as file blobs, and the linked repositories/commits were not recursively expanded merely because a Gitlink exists. Zero unresolved subtree SHAs means complete ordinary tree closure, not automatic external submodule expansion.
