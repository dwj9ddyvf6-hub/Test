# Candle episodes: learn the relationship, not just the silhouette

This is an additive teaching module to `chart_reading_craft.md`, `thestrat_learning/thestrat_chart_craft.md`, and `remaining_methods/SYNTHESIS.md`. Four newly discovered, commit-pinned archive documents were read in full: the candle taxonomy, its addendum, final synthesis, and AI-50 pattern atlas. Exact bytes and complete reading ranges are in `full_read_ledger.json`. No repository code was executed and no archived experiment was rerun. Reference screenshots described by those documents were **not** independently viewed in this pass.

## 1. A better candle worksheet: three scales, three relationships

The existing craft chapter introduces range/body/wick measurements. Extend that into three separate scales:

- **Within-bar shape:** body versus its own range; upper/lower wick balance; where the close sits.
- **Recent-market scale:** body and range versus recent ordinary bars or an explicitly defined volatility baseline. A nearly wickless tiny bar is not the same event as a large directional displacement.
- **Episode scale:** second body versus first body; counter-move versus original impulse; elapsed bars before resumption.

Then record three independent relationships: body containment/engulfment, full-range containment/expansion, and location relative to a prior structural level. These are not substitutes for one another.

**Original drill:** first candle O=106,H=110,L=99,C=102; next O=101,H=108,L=100,C=107. The green second body engulfs the first red body, but its entire high-low range remains inside the first. It is simultaneously a body-engulfing shape and a TheStrat inside bar under strict-exceedance convention. Neither label is wrong; they answer different questions. Add prior decline before calling this a classical bullish-reversal setup.

**Second drill:** first O=102,H=108,L=98,C=106; next O=105,H=109,L=97,C=103. The second body's endpoints sit inside the first body, while both old extremes were crossed: a harami-like body contraction can coexist with an outside-range bar. Do not infer quiet trading from the small body. This is a two-sided excursion with a smaller net open-to-close displacement.

The archive's ATR fractions, five-session trend sign, and minimum-range exclusion are **custom detector settings**, not laws of candlestick reading. Use them to understand how a verbal concept becomes a reproducible classifier, but retain borderline charts for visual study. A short-range session can genuinely be informative compression; deleting it for one study does not erase that information.

## 2. Read a family as stages of an episode

A useful way to learn many names without memorizing disconnected icons is to follow changes in progress:

| Episode | What to see first | What to inspect next |
|---|---|---|
| Harami / harami cross | A large body followed by a much smaller contained body; the cross has a doji second body | Is this merely a pause, or does subsequent price escape the first candle's territory? Mark body edges and full-range edges separately. |
| Engulfing / three outside | A counter-colored body consumes the previous body; an additional bar then extends in the intended direction | Record the two-bar completion and three-bar confirmation as different timestamps. They cannot share an earlier hypothetical entry. |
| Harami / three inside | Contraction followed by directional confirmation | Name whether confirmation must clear a body, a close, or both earlier highs/lows. The archive uses a particularly strict high/low-clearing rule. |
| Thrusting / piercing / engulfing progression | After a red first body, the next rally penetrates progressively more of that body | Compare recovery with the first body's midpoint and open. Partial recovery, deep penetration and full body engulfment are distinct observations. |
| Doji star / morning-doji-star / abandoned baby | Detached hesitation, then recovery; full range isolation is stronger geometric separation than body separation | Count the bars and identify exactly which gaps exist. A two-bar doji star has not yet supplied the third recovery bar. |
| Rising/falling three methods | Impulse, countertrend digestion, resumption | Check overlap, speed and depth of the pause; ask whether the final bar restores progress or merely bounces within the original range. |
| Soldiers/crows versus stalling | Several directional bodies with advancing/declining closes | Are bodies maintaining effort and close quality, or shrinking while adverse wicks grow? Describe the deterioration before assigning an exhaustion name. |

For the piercing progression, take an initial red body O=105,C=100. A later close at102 recovers less than half;103 recovers more than half;105 reaches the old open. **Those close levels alone do not complete any named pattern**: next open, color, wick geometry, preceding context and chosen definition still matter. The archive's strict piercing cap `<105` makes its piercing and engulfing classifications disjoint at105; its claim that the boundary fires both contradicts its formula.

Treat confirmation as an exchange of information for location. If waiting for a third bar moves the candidate entry nearer resistance, remeasure available room and the distance to invalidation. More confirmation is not automatically a better entry. Conversely, a failed early signal followed by a meaningful reclaim can be a new episode, not a reason to rewrite the first observation.

## 3. Gap literacy: mark the empty interval precisely

Use three different labels:

1. **Open-to-previous-close gap:** a discontinuity between two prints. The new bar can subsequently overlap the whole old range.
2. **Body gap:** the open-close intervals do not overlap; wicks may still overlap.
3. **Full-range gap/window:** the entire new low is above the old high, or the entire new high below the old low.

A rising window can coexist with a red candle: the session can fall from its own open while its whole range remains above the previous range. Mark both window edges, whether a later bar enters the interval, whether it traverses the whole interval, and whether price subsequently regains or rejects it. Filling and sustained failure are separate events; choose and record the method's criterion.

The archived addendum calls windows meaningless intraday. That is too absolute: adjacent intraday ranges can be discontinuous around session boundaries, halts or sparse trading. The correct discipline is to inspect the feed/session and define the gap, rather than transfer daily-equity assumptions blindly. Likewise, a data omission is not a market window. Continuous-market bars may exhibit tiny boundary differences without the economic meaning of an overnight repricing.

## 4. Correct identification before absorbing the archive's names

Primary implementation documentation exposes material differences. These corrections preserve the research as research on its own definitions; they do not invalidate the chart-reading family. TA-Lib is one explicit public implementation, not the sole possible discretionary tradition.

- **Tri-star:** the archive tests three consecutive dojis with trend context but omits star positioning. TA-Lib requires a middle-doji body gap and the third body positioned back toward the first. Learn an ordinary doji cluster separately from that tri-star geometry. [TA-Lib Tristar](https://ta-lib.org/functions/cdltristar.html)
- **Breakaway:** the archive's five-bar pattern contains intermediate bodies within the first range and demands a final full reclaim of the first open. TA-Lib instead starts with a body gap between candles one and two, extends the move, and ends with the fifth close inside that original gap. Do not teach the archive's custom full-reclaim episode as an exact standard breakaway. [TA-Lib Breakaway](https://ta-lib.org/functions/cdlbreakaway.html)
- **Ladder bottom:** the archive requires a strict crows sequence, a small fourth red candle, and recovery above the first open. TA-Lib identifies declining first-three opens/closes, a fourth black candle with a material upper shadow, and a fifth white candle opening above the fourth body and closing above its high. The archive omits the distinctive fourth wick and imposes a much greater reclaim. Its zero count does not establish rarity of all ladder-bottom definitions. [TA-Lib Ladder Bottom](https://ta-lib.org/functions/cdlladderbottom.html)
- **Kicking:** the archive allows shadow-rich bars and only requires the second open beyond the first open. TA-Lib specifies opposite marubozu-like candles separated by a gap. Call the archive version a broader gap-reversal construction, not an exact equivalent. [TA-Lib Kicking](https://ta-lib.org/functions/cdlkicking.html)
- **Piercing:** opening below the previous close, as in the archive, is looser than TA-Lib's opening below the previous low. Always state which level was crossed. [TA-Lib Piercing](https://ta-lib.org/functions/cdlpiercing.html)
- **Morning star:** the archive's strict two-open-gap and midpoint-recovery rules differ from TA-Lib's body-gap and configurable penetration rule, whose documented default is30%. Do not silently combine counts or examples across these recipes. [TA-Lib Morning Star](https://ta-lib.org/functions/cdlmorningstar.html)
- **Three methods:** number of intervening candles and containment rules vary. TA-Lib documents exactly three small middle candles and partial range overlap; the archive instead demands their bodies remain inside the first range. A visual impulse-pause-resumption lesson is broader than either exact classifier. [TA-Lib Three Methods](https://ta-lib.org/functions/cdlrisefall3methods.html)

**Internal mathematical repairs:** the archive's claimed dragonfly→hammer-geometry subset is not guaranteed by its actual thresholds. With range1, body0.3, lower wick0.6, upper wick0.1 and ATR3, its dragonfly gates pass but its hammer top-third gate fails. The final synthesis acknowledges a later prose correction. Likewise, body≥0.5ATR and body≥0.7range do not imply range≥approximately0.7ATR; they guarantee only range≥0.5ATR. And engulfing a body is not engulfing the whole previous range, despite one stray narrative sentence saying so.

Avoid causal overreach in translations: a long lower wick after an advance is the hanging-man context, but OHLC does not reveal exactly which participants distributed or absorbed orders. An inverted hammer need not close above its own open. Read its upper excursion and subsequent response without inventing an intrabar path.

## 5. Use the AI-50 atlas constructively: learn a market's pace

The atlas's useful training idea is **instrument personality**: study leg size, duration, retracement depth, average-relative location and volatility separately. It describes50 AI-related stocks plus6 comparison ETFs during2021-10-25 through2026-10-23, with fixed percentage close-based zigzags. Its numerical findings are archived claims, not fresh validation here.

Build a personality card before generalizing a pattern:

- What counts as an ordinary versus unusually large daily excursion for this instrument?
- Do corrective legs tend to happen quickly or drift? Compare elapsed bars as well as percentage distance.
- Is current extension large relative to this instrument's own recent behavior?
- Is a small constituent's violent move comparable to the smoother sector ETF's move?
- How far is the next meaningful obstacle relative to ordinary fluctuation?

The archive reports bigger, longer advances than declines in its selected rising window. Use that to formulate questions about asymmetric pacing, not as a universal rule that every down leg must rebound. Its completed zigzag endpoints are retrospective; a live reader must distinguish the tentative extreme from the later reversal that confirms it.

Its confluence section measures individual state frequencies, **not** the success rate of their combination. A constellation of support proximity, a low oscillator reading and a turn in momentum is a useful chart description; the archive did not measure the joint setup's probability. Its compression table reports subsequent ranges without an unconditional range comparator, so it does not establish a compression-specific expansion multiplier.

The candle synthesis likewise remains an archived2019–2022 daily study under custom definitions, entry/exit rules and costs. It reports41 inconclusive hypotheses and an unusable matched-control leg, not a universal verdict on candle craft. Its old restrictions on desk tracking are historical policies, not instructions governing this learning module. Its ICM recipes were explicitly author-constructed without a verified original source; they must not be attributed to Echo or taught as authenticated ICM.

## 6. Five deliberate practice exercises

1. **Dual grammar:** for20 masked two-bar examples, label body relation and full-range relation separately before attaching a pattern name. Score mistakes in each column.
2. **Context transplant:** use one hammer-like silhouette after a decline, after an advance, and inside congestion. Write what the geometry proves, what context changes, and what response would support the proposed interpretation.
3. **Confirmation clock:** freeze an engulfing read after bar two. Reveal bar three, then remeasure location and room. Keep the original decision rather than backdating the confirmed pattern.
4. **Gap ladder:** inspect session-open examples and mark open gaps, body gaps and full-range windows separately. Record which survived to the close and which were filled.
5. **Episode compression:** summarize five candles as impulse→digestion→resumption, impulse→stall→reversal, or unresolved. Then explain precisely which close or boundary would change that summary.

These are learning exercises, not reported completed trials. Their goal is a more accurate account of what price did and what would confirm the next interpretation—not a promise attached to a candle name.
