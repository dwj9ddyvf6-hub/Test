# Qullamaggie: learning the complete setup sequence

Full static read: `quallamaggie_superthesis_v3.md`, including its third-pass addendum. This pass read the archived reconstruction, not every underlying interview or video. Source metadata and byte reconciliation are in `full_reads_ledger.json`. Its primary-source pointers are useful for verification; claims about personal performance remain source-qualified, not independently audited here.

## Three distinct setups

**Leader breakout:** first find exceptional prior strength, then study the pause. The useful visual sequence is impulse → orderly base → tightening range/higher lows → break of the relevant pivot or opening range. Short averages help describe the pullback; they do not replace inspecting the base. A wide, loose series of bars is not equivalent to a tight base merely because both sit above an average. Determine where the structure fails before deciding whether the entry has sensible risk.

**Episodic pivot:** first understand the information change. A gap is not itself the whole setup. Combine a meaningful catalyst, unusually strong early volume, prior quietness or neglect, and price strength after the opening range. A stock can look like an EP in retrospect because it later rose; that does not establish that the catalyst and volume were knowable at the proposed entry time. In practice, write down exactly what new information became public and when, then inspect how price accepts or rejects the repricing.

**Parabolic short:** distinguish extension from exhaustion. A vertical run identifies a candidate for attention, not an automatic short. The studied method waits for observable weakness: an opening-range-low break, a red candle, or a failed VWAP reclaim, depending on the specified version. Risk is qualitatively different from the long setups because squeezes, halts, gaps and borrow availability can dominate the chart. Study the geometry without treating an attractive screenshot as executable evidence.

## Why the exit belongs to the setup

The reconstructed long-side process protects an initial chart-defined stop, takes a partial after several successful sessions, and attempts to retain a runner with a10- or20-day average trail. The purpose is to combine repeated manageable failures with occasional long continuations. A small hit rate is neither a success nor a failure by itself: the sizes of gains, losses, costs and missed exceptional winners jointly matter. A fixed quick target may materially change the intended method by removing its long right tail.

## What to practice visually

Create paired charts of constructive and noisy bases that share similar numerical width. Mark prior impulse, compression, higher lows, close overlap, volume change, relative strength against a contemporaneous index, and the actual invalidation. Then hide future bars and write a decision. For EPs, add a timestamped catalyst card and the opening-volume curve. For parabolic candidates, distinguish the last strong continuation from the first actual failure. Preserve both rejected and selected cases: winner-first study is useful for learning the pattern vocabulary, while the full candidate set teaches discrimination.

## Preserve the difference between public teaching and engineering choices

The thesis separates direct rules from its own thresholds. A top2% rank union, ten-session base,28% maximum base width,70% moving-average support,0.5×ADV after20minutes, QQQ regime proxy, and1.5ATR trail-switch threshold are prototype choices—not a recovered private algorithm. Public accounts also differ by date about typical base duration, risk, opening-range choices and management. Keep those as versions rather than manufacture one timeless exact formula.

The third-pass addendum corrects the main manuscript's fill assumption. It reports a first-person rejection of buy-stop orders and therefore separates an observed breakout from an assumed standing order filled exactly at the line. Its next-bar-open model is a simulation choice, not proof of the trader's precise execution. Likewise,20-minute volume cannot justify a five-minute entry retroactively. A daily closing moving-average breach cannot be used to claim an earlier intraday exit.

A practical chart-reading lesson follows: **setup, trigger, invalidation, execution and management are separate steps**. Mastering one recognizable shape is not the same as learning the whole method.

## Archived source status to retain

The earlier body mentions11 tests; the later third-pass addendum reports27 after further corrections. The addendum also corrects an earlier Finnish-program attribution: the located program analyzes the strategy rather than being an interview with Kullamägi. These are internal version updates, not independently rerun results in this pass. Empirical replication remains blocked in the archived package by missing point-in-time data, especially event timing and historical short mechanics; no new strategy test was run here.
