# Chart-reading corpus: thirty-one full reads and practical synthesis

Research date: 2026-10-30. This is learning and static source analysis, not a trading deployment or a verdict against technical analysis.

## What was actually read

Thirty-one whole files, 116,171 whitespace-delimited words, including code/comments: standing chart-read protocol; folded Grand Synthesis; Galath Elliott study and build specification; Femto Elliott implementation; Femto pattern-calibration implementation. Exact paths, commits, Git blob SHAs, local SHA256s, line/word counts, and read status are in `full_reads_ledger.json`. All31 source files were checked against pinned Git blob identities; source code was not executed. Quoted research findings inside archived documents are inherited claims, not independently reverified papers in this pass.

## The practical method to retain

### 1. Build the scene before naming the pattern

Begin with symbol, timestamp, session, timeframe, adjustment convention, linear/log scale, indicator legend, and visible/missing panels. Read the whole chart, then deliberate crops at decision points. Mark the last several significant highs/lows and the boundaries of the current range. Recover values from the underlying bars when available; otherwise distinguish exact printed labels from approximate visual estimates. Confirm every observation that supports the conclusion against the source image or bars.

The archived methods call this geometry before narrative. It does not eliminate visual analysis: the synthesis explicitly says numerical measurements without visual inspection cannot supply the full structural picture. It disciplines visual analysis so that a line, wick, or legend error does not become an elaborate story.

### 2. Separate trend, location, and timing

Ask two different questions: is the trend still intact, and is this a good location to initiate? A steep advance can answer yes to the first and no to the second. A broadly bearish regime can contain a valid reversal candidate; bearishness alone does not tell us whether a deep reset is forming a base or merely continuing to collapse.

Work from a genuinely supplied higher-timeframe chart to a setup timeframe and then the execution timeframe. The archived desk uses weekly → daily → hourly, but that is a workflow choice rather than a universal requirement. Several swing sizes measured on daily bars are not three different timeframes.

Locate price relative to actual swing support/resistance, trend-defining averages, a named anchored VWAP, and a specifically declared retracement. Distinguish an existing structural level from a projected objective. A projection can be a scenario signpost without becoming a promise.

### 3. Read interaction with the level, not only the level

Three useful descriptive states in the Midna protocol are a return through a tested level, residence near it, and arrival beyond it. A wick through a boundary and a close beyond it are different observations. A gap through a reference and an intrabar traded cross are also different. The protocol normalizes distances with ATR, allowing a test to be described relative to typical movement rather than arbitrary dollars.

The exact 0.20 ATR test, 0.10 ATR residence, and 0.15 ATR zone-merging thresholds are that implementation's definitions, not universal chart laws. Retain the questions they make explicit: did price genuinely interact with this boundary; where did it finish; how large was the probe; what happened next; and is the apparent cluster one zone or several distinct levels?

### 4. Read price and volume together

Compare effort with result at the structure: expanding range and volume on a break; shrinking range/volume on a pullback; a large effort producing little progress; a recovery that survives a retest. Volume must be present, credible, and time-aligned. Do not infer accumulation or institutional absorption solely from a lower wick. Missing volume narrows the interpretation; it is not a negative-volume observation.

Momentum divergence needs two corresponding price pivots and two indicator pivots. The same momentum weakening repeated in an Elliott narrative, MACD panel, and RSI panel is not three independent discoveries.

### 5. Turn the read into competing plans

For the primary scenario, state present structure, the event that activates it, confirmation, a structurally sensible objective, and what would negate it. Keep an alternate scenario and the condition that would promote it. Distinguish a count's invalidation from a trade's stop: a mathematically valid count may require more risk than a particular trade can bear. If a branch has no visible trigger, leave it unfilled rather than manufacture symmetry.

For practice, freeze the chart as of a date; write the scenarios before uncovering later bars; record whether the observation, trigger, structure, or management assumption failed. This improves the craft without requiring the learner to reject a method before learning it.

## Elliott: how to actually count

The Galath study provides a useful structured lesson. Start with the clearest larger completed move; mark swings; enumerate allowed labels; enforce rules; rank remaining counts using guidelines; write the alternate; examine smaller-degree subdivisions; name invalidation; and wait when the structure is genuinely ambiguous.

An ordinary impulse must satisfy the wave-2 retracement rule, wave-3 length rule, and wave-4 non-overlap rule, alongside appropriate direction and subdivision. A diagonal is a different form, not permission to waive ordinary impulse rules silently. Alternation, extension, channeling, volume/momentum personality, equality, and ratio relationships help compare valid counts; they do not repair a broken rule.

The study differentiates sharp zigzags, sideways flats, contracting triangles, and combinations. The practical positions it studies are completion of wave 2 into wave 3, wave-1-high break during wave 3, wave-4 completion into wave 5, a completed fifth followed by correction, completion of C followed by trend resumption, and thrust after E of a triangle. Each has a different invalidation and target construction.

A useful implementation pattern is primary count + alternate + anchors + confirmation timestamps + rule trail + guideline-fit score + invalidation + projected zones. Fit is resemblance to the stated template, not an estimated probability of reaching its target. Confirmation timestamps matter: a pivot drawn on Monday may not become knowable until Wednesday.

## Two Elliott systems, not one

| Aspect | Galath proposed layer | Femto implemented module |
|---|---|---|
| Location | bestsetups/out/elliott_1016/ELLIOTT_SPEC.md | core/elliott_wave.py |
| Swing model | Three ATR directional-change thresholds, 1.5/2.5/4.0 | Williams ±2, alternating pivots, minimum1.5 ATR and three bars |
| Price measurement | Log price, mirrored for downtrend | Arithmetic price differences |
| Selection | Guideline conformance ranking and cross-size agreement | Pattern-family priority, then score, with documented fragment exceptions |
| State handling | Per-degree none/weak/ambiguous/stale/ok | Active/ambiguous/no-valid plus invalidation/expiry events |
| Scope | Build specification; no backtest claimed | Static code exists; execution not verified in this pass |

These differences are substantive choices. They must not be hidden by a generic statement that we 'have an Elliott engine.'

### Static discrepancies worth preserving, not silently correcting

1. **Completed impulse semantics:** Galath's spec treats a completed rise followed by correction as invalidated beyond the fifth-wave high. Femto `_parse_impulse` sets completed-impulse invalidation to the origin. These answer different questions: invalidation of a prospective correction versus a broader structural boundary. A read must say which is meant.
2. **Count-instance immutability:** Femto's introduction says an instance is born with an invalidation and dies by it. `run_stream` updates that invalidation when the same identity progresses to a new position. This may be intentional lifecycle evolution, but a learned rule must follow the actual code, not assume a fixed lifetime level.
3. **Calibration fallback:** `pattern_calibration.cell_for` describes a thin finer cell as never borrowing a parent's rate, yet loops through conditioning, direction, and family and returns the first measured cell. The returned slice is named, so it is not secretly blending, but a user-facing rate must identify its actual broader reference class.
4. **Validation scope:** `validate_product` checks version, roster hash, signal span, census-hash presence and required headers; it requires `as_of` presence but does not compare it to `PINNED_AS_OF`. It does not independently verify the census hash's contents. Static checks are narrower than a claim of fully verified calibration data.
5. **Objective-kind filing:** the family cell path withholds rates below30 cases; `realism_filing` marks an available objective-kind row measured without applying that threshold. These are different APIs, not one uniform minimum-sample rule.

These are observations for source interpretation. No issue, patch, test run, or change to any desk was made.

## How to handle older restrictive doctrine

The Grand Synthesis and Midna protocol contain historical 'banned' or 'killed' lists and house-specific thresholds. Their dates, scope and denominators matter. This research preserves them as archived policy and test records, not instructions governing today's request and not universal claims that candles, Fibonacci, chart patterns, or visual reading are invalid. Especially do not universalize the exact22-day/1.5% double-top definition, a1.5 ATR stop floor based on three losses, a small hindsight archetype table, or a particular desk's bearish-regime gate. Learn each method's intended construction first, then assess the exact application on matching evidence.

## Corpus coverage and next queue

`classification_queue.json` preserves the original default-branch snapshot; `final_classification_queue.json` and `final_family_dispatch_queue.json` hold the final indexed corpus; allrefs queues are superseded historical snapshots. Their companion JSON summaries are authoritative for the captured snapshot counts. These are exhaustive metadata classifications within the indexed snapshot, not all GitHub, confirmed relevance, or absorption. Every candidate retains a reason, priority and source pin; no heuristic rejection deletes its record.

Thirty-one completed source reads in this study are separately ledgered and hash-verified. Team coverage is deduplicated in `team_confirmed_full_reads_by_blob.json`; source-file, extracted-text, archived-post and direct-image readings must retain their distinct units. The captured accessible branch inventory is now closed with zero unresolved subtrees; semantic reading remains partial.

The recovered Echo post archive has a separate coverage report. This study fully read the September 279-image rulebook and October 16 trader study as documents; those historical image-inspection counts are not fresh inspections. Standalone `CHART_READING_METHOD.md` is recovered and fully read. TheStrat, visual-model research and broad oscillator/overlay studies have now been read in the additional study modules. The nine final-index named syntheses in `final_delta_teaching_frontier.json` are now fully read across the team, with additive comparisons in the visual, wave and candle modules.

## Addendum: the 279-image analyst rulebook changes the lesson

Two further full reads added `CHART_RESEARCH_1016.md` and the renderer's `analyst-rulebook.md`. The latter is a more substantial observational archive: it reports279 additional chart inspections—Echo100, BP100, Mind79—and explicitly distinguishes observed behavior (O), inferred workflow (I), and unknown private rules (U). Those are the earlier researcher's inspections, not279 new images personally inspected in this pass. Its180 numbered observations are categories of behavior, not180 independent strategies or performance tests.

The strongest teaching is **nested, conditional structure**. A macro bullish thesis can contain an immediate bearish correction; a local B/X rally can be a legitimate opportunity within a larger decline. A projected first-wave completion may be followed by a future wave-2 buy zone, rather than an instruction to buy the current rally. Different zones belong to different stages and different structural degrees. A clean analysis keeps these relationships visible instead of flattening the entire chart to bullish/bearish.

Six inferred practice sequences emerge: initial impulse → wave-2 retracement → wave3; terminal C/Y → reversal area → new cycle; breakout → retest → continuation; corrective rebound → risk area → renewed decline; wave4 → wave5 with a deeper-reset alternate; and macro thesis paired with a separate local timing chart. Practice each by naming its anchors, the present stage, the next observable condition, competing interpretation, and invalidation.

The rulebook provides specific visual operations: retain broken boundaries for retests; nest a small channel within a large correction; separate a trigger from a final target; preserve distinct origins for coincident measurements; mark the exact bars that justify a claim; compare breakout volume with the quieter retest when present; and separate realized gain brackets from projected returns. A gain arrow may start at a historical low rather than today's price. A future label's horizontal location is not automatically a time forecast.

**Important correction to simplistic imitation:** Echo need not draw one continuous forecast arrow; future wave labels and local target segments can carry the analysis. BP can show several staged turns rather than one decisive arrow. Mind does not always display RSI/MACD. The sample does not reveal universal pivot thresholds, line-fitting tolerances, Fibonacci anchors, indicator periods, execution rules or sizing. Unknown private rules remain unknown. The Oct16 small-sample renderer study's 'one idea per chart' and 'at most one indicator' are design suggestions, not universal analyst methods; the larger September rulebook explicitly corrects over-narrow small-sample conclusions.

Implementation lesson: retain a structured map of which wave contains which, which anchors produce each line or ratio, which level activates each branch, and which observation promotes an alternate. Copying colors without these relationships would not reproduce the method.


## Original chart method recovered from branch archive

The ninth full read closes the missing standalone method: ClaudeDesk commit`bd160ed2e98cbd12908713ef7e58975677eaf2e8`, `midna-corpus/gestalt/CHART_READING_METHOD.md`, blob`d6d181edbbf56eeecea11bf4d844f782c36b46da`. Its perceptual and seven-step sequence is already synthesized above. The original is more categorical than the folded Grand Synthesis: it declares an always1.5 ATR stop floor from only three losses, calls a structural-magnet extension successful from a live example, and omits cell sample sizes beside several archetype rates. The later folded synthesis adds the missing n/confidence intervals and marks these as hypotheses or judgment. Preserve the later qualifications rather than transmitting the older categorical language. This is a reason to follow provenance and versions, not a reason to discard the useful visual-reading sequence.


## Distinct next family completed

Full Qullamaggie superthesis v3 including third-pass corrections is now read; practical learning is in`qullamaggie_learning.md`. It covers leader breakout, event-driven episodic pivot, confirmed parabolic failure, chart-defined risk, runner management and timestamp-correct execution, keeping direct teaching separate from prototype thresholds.


## Wyckoff family completed

Two branch-pinned Wyckoff engines and a method note are now fully read. Practical sequence and implementation boundaries are in`wyckoff_learning.md`, including a fresh check against Wyckoff Analytics primary instructional pages.


## Practice and presentation family completed

Six further source reads are synthesized in`practice_and_presentation_learning.md`: multilateral judgment, blind visual practice, dated protocol conflicts, concrete multi-timeframe comparisons and charts that display their operative geometry and conditional scenarios clearly.


## Failed-breakout and selection families completed

Eight additional sources extend Raschke book-attribution/Turtle Soup, session sweep-and-reclaim, divergence anchor semantics and Lector selection/measurement. See `failed_breakouts_and_selection_learning.md`; it distinguishes implementation-specific thresholds and fitted weights from disclosed original rules. A generated RSI/OBV results table is not counted as a new method or a completed full read.


## Final visual and annotation delta

Two final-index reports are fully read. `visual_annotation_delta_learning.md` identifies genuine additions beyond the prior thesis/V5: encoding audits, per-claim region verification, collision-aware annotations and accessible mobile presentation. It repairs overbroad historical pattern bans and probability/target conflations instead of making them present instructions.
