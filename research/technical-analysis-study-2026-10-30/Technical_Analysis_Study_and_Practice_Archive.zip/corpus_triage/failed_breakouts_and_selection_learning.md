# Failed breakouts, divergence and selection

Eight additional retained sources were read in full. They include methods, a feature implementation and one dashboard-faithfulness table. Historical tests and chart inspections reported inside them were not rerun or newly viewed. The RSI/OBV file named `out/STRAT.md` proved to be generated results, not a strategy manual; it was classified as reference data, not counted as a full read.

## Failed-breakout families

**Turtle Soup and Plus One are distinct.** The institutional teaching article specifies a new 20-day low with the earlier low at least four sessions old for Turtle Soup, followed by same-day recovery entry above that earlier level. Plus One uses a three-session age requirement, a close at/below the old low, then next-day recovery entry at that level. Both reverse for shorts. Exact offsets, expiry and protection differ; do not blend the variants. The full books remain unread, and exact Anti/80–20/Momentum Pinball originals are still access gaps. [TradingMarkets teaching article](https://tradingmarkets.com/recent/How_To_Use_TMs_Indicators_The_Turtle_Soup_Plus_One_Lists-665446)

**Sweep-and-reclaim adds session structure.** The retained KZ specification maps prior-day/untouched older extremes and Asia/London ranges before the U.S. opening window. The useful visual sequence is excursion through a mapped level, a completed signal candle back across it, then an opposite-side objective. Distinguish a reclaim from acceptance beyond the boundary. Its source/assumption table is valuable: instrument proxies, which reclaimed level to choose, numerical buffer, scale timing and hard exit are partly new implementation choices. A contradictory example target versus its stated minimum reward/risk remains unresolved. Futures-to-ETF level mapping is a separate approximation, not identical geometry.

For both families, mark the original level before the excursion and use only the low/high known at decision time. A stop using the day's eventual extreme would know the future. A liquidity-sweep label describes price behavior; it does not independently identify whose orders traded.

## Divergence as a measured relationship

The archived scanner description pairs consecutive same-type price-close swings and compares RSI/OBV at those anchors. Regular bullish divergence means lower price but higher oscillator; regular bearish is the reverse. Its windows, minimum separation, one-bar interior-pivot confirmation, strength threshold, five-bar active life and near-30/70 labels are **that implementation**, not universal definitions. An overlap label is usable only when both component records already exist. The archive documents an earlier future-record overlap bug; visual historical labels can therefore look cleaner than signals available in real time.

Learn to draw and timestamp the anchors, then ask what price must do to confirm the interpretation. Do not treat an oscillator disagreement as an automatic reversal or transplant a single instrument/horizon result to all divergence. The later canonical-universe report changes the earlier daily-stock findings, so the early blanket headline is not the complete chronology. These are archived research claims, not freshly verified outcomes.

## Screen first, then read the actual chart

Lector material separates relative strength, trend stage, extension, volatility, breadth and rotation. These answer different questions. The time-series percentile of a stock/SPY ratio is not its cross-sectional return rank. Raw distance from SMA50 in ATR units differs from the normalized-percent extension variant. A score can help order a reading list without being a calibrated probability or an entry trigger.

The feature code makes an additional ranking distinction: universe percentile uses the share of eligible names strictly below the value, while list percentile uses pandas ranking with its tie convention. Universe composition and ties can therefore change ranks even without a new price pattern. Preserve the observation date, data universe and missing-data treatment.

Two necessary source corrections: (1) the deep-analysis R1/V2 proposal incorrectly suggests replacing prior intraday-high thresholds with prior closing-high thresholds will demote existing breakouts. Since prior closing highs cannot exceed corresponding intraday highs, this is generally an easier test; only separately specified strict/tolerance details could alter boundary cases. (2) early source notes call composite weights unknown, whereas later feature code labels coefficients exact-by-fit. Fitting screenshots is not author disclosure. Dashboard agreement measures reproduction, not forecast accuracy.

Practice by selecting a strong relative name, inspecting its actual stage and extension, comparing market participation, then defining a chart-specific trigger. Keep rank, context, entry location and invalidation as separate statements.
