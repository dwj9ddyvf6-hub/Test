# Raschke: reading the next swing

Two archived teaching syntheses were read in full and hash-verified. Their prior PDF/slide inspections are not new inspections in this study. Two author-bylined web articles were independently opened and read as text; their embedded charts were not visually inspected.

## Practical lessons

**Choose the market mode first.** A compression breakout, established-trend pullback and failed breakout are different opportunities. They can use similar indicators while needing different triggers and management. Do not average their instructions into one generic strategy.

**Momentum can confirm expansion rather than signal a fade.** Raschke's breakout lesson begins with higher-timeframe contraction. A lower chart then provides a simultaneous price/momentum high. Her oscillator is SMA3 minus SMA10, not default exponential MACD. The example stages entry and uses the price associated with the preceding oscillator swing low for protection. This is a conditional recipe, not a reason to buy every high oscillator reading. [Author's article](https://www.traderslog.com/buying-new-momentum-highs)

**Read responses at visible reference points.** Mark prior-session high, low and close plus today's open. Observe direction, speed, distance and response: acceleration through, rejection, acceptance, or failure to follow through. A range edge may be an objective in congestion but a waypoint in a trend. A failed downside excursion that re-enters and breaks upward is information, not merely an imperfect original pattern. This is price-response reading, not a disclosed order-book imbalance formula. [Author's tape-reading lesson](https://www.traderslog.com/tape-reading)

**Preserve sequence and version.** The archive describes Grail as strong/rising ADX first, then the initial EMA20 retracement; the cited 1997 trigger uses the previous bar's high, not automatically the touch bar's high. First Cross is not silently interchangeable with Anti. Two-period price difference is not percentage ROC. A failed pullback does not automatically mandate reversing. These details remain archival source findings until the original publications receive a new audit.

Practice three separate chart exercises: identify contraction before expansion; distinguish initial qualified pullbacks from late repeated touches; and document the expected response at a level before revealing subsequent bars. Record what would change the reading. None requires inventing exact probabilities from a selected example.
