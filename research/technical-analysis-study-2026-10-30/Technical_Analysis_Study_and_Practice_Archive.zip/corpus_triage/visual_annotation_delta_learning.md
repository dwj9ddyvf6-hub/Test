# Visual acuity and annotation: the genuine additions

Two final-index reports were fully read, totaling 67,327 source bytes. Their research dates are October 8 and 15, 2026. This is a read of retained syntheses, not a new audit of every paper, pattern sample or image cited inside them. Comparison here uses the team's earlier thesis/V5 teaching syntheses rather than claiming another complete reread of those originals.

## What is reinforcement rather than a new method

Overview before detail, seeing before interpretation, completed-bar/pivot timestamps, exact data for fine measurements, masked future bars and separate perception/outcome grading already appear in the thesis/V5 work. Their repetition strengthens the practice design but does not represent six additional trading methods. Likewise, reading about fine-tuning does not train or change this assistant's model weights.

## Useful additions to the reading protocol

**Audit encodings before judging shapes.** Explicitly check axis direction, log/linear scaling, breaks, dual axes and cropped context. Make a short legend-to-series registry where overlays are ambiguous; identify a series by its label and line style, not color alone. A slope or crossing claim is meaningless if the compared lines use different scales.

**Verify the observation that carries the conclusion.** If the reading hinges on one wick, close, label or line interaction, inspect that exact region at adequate resolution while keeping the overview available. A fluent description is not verification. Cropping can remove the prior impulse or relevant support, so preserve crop coordinates and context. Prefer source OHLCV for precise values; do not transcribe hundreds of unreadable candles merely to satisfy a generic chart-QA procedure.

**Count explicitly when the count matters.** Mark candidate swings or bars with identifiers, separate regions carefully, and avoid counting boundary objects twice. If the image cannot support the required count, say so. More verbal reasoning does not recover missing pixels.

## Annotation is part of analytical accuracy

Separate level coordinates from explanatory prose: exact price labels can sit at the axis; explanations use offset callouts linked to their anchors. Reserve a stable distinction for observed history versus provisional/projected structure. Preserve level provenance even when several near-coincident levels share a displayed zone.

Run a collision pass against both labels **and candles/data marks**. Place high-priority labels first, then move, merge or omit lower-priority ones rather than obscure the evidence. Occupancy-bitmap layout is a concrete researched implementation, not just an aesthetic preference. The report misattributes this paper: its author is Chanwut Kittivorawong. [Primary paper record](https://arxiv.org/abs/2405.10953)

Inspect at the actual delivery size. A mobile view should preserve the decisive evidence with fewer simultaneous annotations, not shrink a dense desktop chart until the labels disappear. Numerical caps such as five mobile labels or fifteen desktop labels are adjustable house choices. Use redundant shape/text/style cues for meaning, and sufficient text contrast: WCAG's normal-text threshold is 4.5:1, with 3:1 for qualifying large text. These are accessibility thresholds, not a universal minimum chart font size. [W3C contrast guidance](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html)

## Corrections before adopting the archived rules

- A pattern's geometric measured move, a conservative objective and the probability of reaching either are different quantities. Multiplying height by an old target-hit percentage is not automatically an expected price or a universal target rule. It is legitimate to display the full geometric projection as conditional while also identifying nearer obstacles and staged objectives.
- Old pattern rankings and fixed 3% penetration, two-source confluence or 0.5 ATR merge rules are source-specific or house choices. They do not justify banning triangles, Fibonacci, early pattern hypotheses or alternate confirmation methods. Identify a forming pattern as forming rather than pretending it is confirmed.
- Regular divergence can occur during a pullback within a larger uptrend; hidden divergence is not the only possible support for a with-trend idea. State the timeframe and competing interpretations.
- High effort with little price progress can motivate an absorption/distribution hypothesis; candles alone do not prove institutional identity or intent.
- General chart-QA benchmark gains are not measured gains in this reader's stock-chart skill. The retained report mixes primary papers, secondary summaries and a small repository experiment. No percentages are imported as current capability claims. A fresh Bulkowski page retrieval returned 403, so its archived numerical table remains unverified in this pass.

The practical gain is a chart that lets another reader locate, check and challenge every important observation—not a more ornate forecast.
