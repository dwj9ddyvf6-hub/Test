# Wyckoff: read the sequence, not a lone wick

## Practical teaching, checked against the method's publisher

Start with the trend before the range. In a prospective accumulation, look for the decline slowing, a selling climax and automatic rally defining the range, then a secondary test with reduced spread and volume. A spring briefly breaches support and returns inside, but it is optional: supply can be tested higher in the range. Afterward, look for strength on wider bars and increased volume, followed by a quieter pullback or last point of support. The transition matters more than matching a perfect diagram. [Wyckoff Analytics tutorial](https://www.wyckoffanalytics.com/wyckoff-method/)

For distribution, watch what follows an upthrust: weakness toward support, then a feeble rally that struggles to progress. This makes the post-test response an essential part of the interpretation rather than shorting every apparent false breakout. [Wyckoff Analytics: reaccumulation versus distribution](https://www.wyckoffanalytics.com/wyckoff-reaccumulation-vs-distribution-how-to-tell-which-one-youre-in/)

## What the archived engines actually implement

Full static reads: Femto-lean `desk/terminal/read/wyckoff.py` and `wyckoff_phase.py`, commit`ac989b5e51c8cc6ec96147f7974d2e41c19bdbae`; plus the archived Wyckoff method note. No code executed. The note itself used indexed/mirrored text; the web check above improves provenance for the teaching claims.

The event detector looks for a bounded, approximately flat range with separated contacts on both sides, then a recent spring/upthrust whose recovery remains intact through the current observation. It separately detects candidate climaxes from range, relative volume, prior advance/decline and close location. Its phase companion traces climax → confirmed opposite swing → quieter secondary test → optional spring/upthrust → strength/weakness → departure from the range. It permits a no-spring path to phase D. Phase facts are context rather than a second vote for the same underlying events.

These are explicit operational choices:20-session minimum range, six-ATR maximum width,1.5ATR fitted-line drift limit,2.5× relative-volume climax and other numerical thresholds come from this implementation, not the published method. The phase parser requires a qualifying climax and a particular secondary test, so its silence does not establish that all legitimate Wyckoff interpretations are absent. It does not implement an explicit LPS/LPSY detector or point-and-figure cause count; therefore it is not the entire method.

Three details matter when learning from its outputs:

1. The standalone SOS predicate requires a close above the range midpoint and the prior day's high—not necessarily above the range ceiling—while its prose says price rose out of the range. Describe the actual condition, not a stronger breakout claim.
2. 'Buyers absorbing selling' and 'sellers trapped' are interpretations attached to OHLCV behavior, not directly observed participant identities. Keep observation and explanation separate.
3. `EFFORT_VOTE=False` explicitly converts effort-versus-result outputs to nonvoting context. A printed observation is not necessarily an active decision rule.

Practice by drawing the range boundaries and dating each event before assigning a phase. State the event still missing, the next confirmation you would watch, and the price behavior that would invalidate the sequence. Compare several legitimate variants rather than force every range to contain a spring.
