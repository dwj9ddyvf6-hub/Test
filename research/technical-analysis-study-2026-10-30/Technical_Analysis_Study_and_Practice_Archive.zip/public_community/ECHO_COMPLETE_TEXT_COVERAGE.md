# Echo archive: completed available-text review

## Scope and receipts

This closes review of the finite recovered archive, not all of Echo's historical internet output. Source: `dwj9ddyvf6-hub/ClaudeDesk`, commit `5fad5264d9b56dee7ec9c7d13164d55f5072d06f`, `wt_sec/docs/research/2026-10-18-terminal/echo-harvest/posts_all.json.gz`, blob `b51bf1c8b7995dcb097440b24264d454f2210b86`. Retrieved 2026-10-30 approximately 19:12:43 UTC; the archive's pass-three build is 2026-10-19 11:30:28 UTC. Original-post dates and their derivation remain separate fields.

- 16,659 unique archive records; 3,213 have nonempty main text; 13,446 do not. Empty records were inventoried, not magically reconstructed.
- All 3,213 nonempty main texts received content review. 1,474 technical/long-text candidates were read in full retained-field form: initial410 plus1,064 in twelve batches. The remaining1,064 records were reviewed across twelve batches. The broad candidate selection includes some promotional or contextual material; **1,474 is not a count of independent teaching lessons**.
- The other1,739 short records were reviewed through887 distinct cleaned-text groups (mentions and URLs removed only for grouping). These include acknowledgments, promotions, context-dependent price replies, logistics and brief method statements. They are not all “irrelevant”:24 particularly clear method/market replies were explicitly rescued, including the SMA specification. The other1,715 remain brief-content reviewed, not falsely labeled substantive full lessons or uniformly social.
- Additionally138 unique nested texts absent from the main nonempty-text set were read fully:115 quoted texts attributed to Echo,23 reposted texts explicitly by other authors. These are nested-text units, not automatically138 additional unique archive records.
- `archive/complete_text_reading_ledger.json` records every main nonempty ID, retained provenance, original-date basis, attribution limits, reader and text hash. `archive/complete_coverage_counts.json` gives exact reconciliation. `archive/parent_batch04_07_read_receipt.json` contains the additional360 reviewed IDs and batch hashes. `archive/nested_additional.json` preserves nested author/parent associations.

**Full retained text is not necessarily the full original post.** Some records visibly trail off; snippets and seven id-less paraphrases exist. Original completeness is unknown unless independently established. Collection membership attributes material to Echo but often lacks an independent top-level author field. Nested quotes/reposts must not be silently assigned to Echo. Archive classA/B/C indicates acquisition provenance, not trading validity. No live-X verification, trading performance verification, or fresh image inspection is implied by this text ledger. The separate visual study inspected15 original images with its own ledger.

## What the broader reading added

### 1. Record indicator identity, not just a color

A concise reply specifies simple moving averages50 and200 on day/week/month horizons ([2097790579111313874](https://x.com/EchoAnalysis/status/2097790579111313874)). Replies identify lightblue weekly averages and explicitly correct a previous label ([2097933571717533770](https://x.com/EchoAnalysis/status/2097933571717533770), [2102864033770844483](https://x.com/EchoAnalysis/status/2102864033770844483)). This is better evidence than guessing from pixels. It is not a universal claim that every chart uses only those indicators: archived posts also discuss9EMA,21EMA and9-weekEMA. Practical rule: retain period, type, timeframe and source of identification separately; an unlabelled color is unknown.

### 2. The KRMN loss was preceded by a conditional plan

The newly read nested [2091254580738679065](https://x.com/EchoAnalysis/status/2091254580738679065) outlines three branches: deeper retracement toward0.786 near48; bottom and higher-high/MA confirmation; or a lower low beyond invalidation followed by selling. Its claimed16% downside versus60% upside is the author's historical estimate, not a verified realized ratio. It provides valuable pre-update context for the later stopped-out KRMN sequence. Teach the sequence as a conditional plan, observable branch and subsequent response—not an inevitable wave forecast.

### 3. Separate investment mandate from tactical trade

After invalidating an earlier RR interpretation, [2075958793070919835](https://x.com/EchoAnalysis/status/2075958793070919835) describes a complex correction and shifts interest toward a tactical breakout rather than the previous longer-term investment. Conversely, some NKE posts explicitly retain a long-term holding rationale despite local weakness. Neither implies permission to change a trade's mandate silently. Every chart worksheet needs a declared horizon, position purpose and failure rule, with any revision timestamped.

### 4. A technically attractive idea may not be bought

[2091941015359770841](https://x.com/EchoAnalysis/status/2091941015359770841) ties smaller VELO size to existing space-sector exposure; short replies say the author has enough exposure or is happy with position size. Posts explain that the green marker denotes a reported personal buy, whereas bullish charts need not be holdings. Thus keep separate fields for analysis, conditional plan, reported execution and allocation constraint. A chart collection is not a transaction ledger.

### 5. Missing a preferred entry need not mean chasing

[CMG2108513303211221231](https://x.com/EchoAnalysis/status/2108513303211221231) allows the desired support entry to be missed and waits for a later corrective leg. [RDW2053966379162677502](https://x.com/EchoAnalysis/status/2053966379162677502) prefers paying more after a confirming retest to buying the cheapest print. The additional readings add two-route entries: deeper support or a new initial advance followed by its first correction. These are distinct ways to obtain evidence, not inconsistent targets.

### 6. Overbought, oversold and divergence are different observations

[ZM2051256020060471709](https://x.com/EchoAnalysis/status/2051256020060471709) distinguishes elevated RSI from divergence; [PNG2105070618026946604](https://x.com/EchoAnalysis/status/2105070618026946604) describes oversold conditions without divergence and a small initial position. A worksheet should record the actual oscillator comparison and corresponding price pivots, not collapse all oscillator states into a buy/sell label.

### 7. Confirmation has temporal granularity

A HIMS example waits for regular-session testing rather than treating after-hours trading as equivalent. AMPX [2104681302473482288](https://x.com/EchoAnalysis/status/2104681302473482288) describes an intraday rally that closes back below a trendline/50-day average as a fakeout. The additional readings show a buy zone reached before corrective structure completes and a favorable first bounce that still does not trigger entry. Record whether a condition requires a touch, close, retest, higher low or higher high; do not swap these after the fact.

### 8. A wave label depends on its containing structure

[2109437642966286754](https://x.com/EchoAnalysis/status/2109437642966286754) warns that an apparent five-wave move may be inside an extended third wave. [2105636849377046944](https://x.com/EchoAnalysis/status/2105636849377046944) warns against superficial ABC labeling without internal structure and B-depth. The useful craft is hierarchical labeling plus explicit alternate conditions. The additional readings adds that identical Fib ratios can measure opposite-direction swings; anchor identity is essential.

### 9. Profit-taking need not be all-or-nothing

[NVAX2107441239020757323](https://x.com/EchoAnalysis/status/2107441239020757323) describes partial exits at successive targets while retaining a runner. Nested SNOW [2085385094001205525](https://x.com/EchoAnalysis/status/2085385094001205525) reports trimming to release capital and considering re-entry after a later correction. These are author-reported management choices, not independently verified fills. In practice distinguish initial position size, each reduction, remaining stop and any later re-entry condition.

## Reusable learning drill

For a single archived sequence, hide all later posts and images. On the earliest available chart, identify the visible timeframe and confirmed pivots; write one primary scenario, one alternate, the evidence needed before entry, the structural failure boundary and the allocation constraint. Reveal the next dated update, record which observation changed, and keep the old plan visible. Grade whether the declared process was followed separately from whether the price rose. Use original pixels for visual observations and retained text for author assertions; never turn a future arrow or percentage target into observed market data.

See `ECHO_PARENT_BATCH_LESSONS.md` for nine additional distinctions from batches04–07 and `ARCHIVED_ECHO_METHOD_STUDY.md` for the original410-record foundation. All examples here are historical practice material, not current recommendations.
