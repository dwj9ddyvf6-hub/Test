# Chart Reading as a Practical Craft
## A procedural handbook for visual technical analysis

Research pass: October 30, 2026. This chapter teaches chart interpretation and its practical use. It is not a study designed to dismiss technical analysis. The source explanations below are concise, attributed summaries; the procedures, numerical cases, decision templates and exercises are original synthesis. Examples are hypothetical unless explicitly identified otherwise. They are not backtests or live trade recommendations.

Source IDs resolve in [the companion source ledger](chart_reading_sources.md), including exact access limits and selected-excerpt status.

## 1. The central skill: read the sequence, not just the silhouette

A chart is a compressed history of transactions. A capable reader reconstructs a sequence: where price came from, what it tried to do, what progress it achieved, how participation changed, and what happened at the next test. Pattern names are useful compression. The real skill is distinguishing two superficially similar pictures that have different context and different next decisions.

Use three separate statements:

1. **Observation:** “Three daily closes are above the previously marked 80–81 resistance zone.”
2. **Interpretation:** “The old ceiling is beginning to behave like an accepted trading area.”
3. **Decision condition:** “A controlled retest that holds that zone and turns upward on the timing chart would provide a different entry from buying today's extended close.”

This keeps the analysis specific without making it timid. It also makes learning possible: an inaccurate observation, weak interpretation and poor execution are different mistakes.

**The recurring questions**

- Is price trending, balancing, transitioning, or accelerating?
- Where is it within that state: early expansion, middle, mature extension, range edge, or range center?
- Which side has achieved progress during the last several swings?
- Is the counter-move becoming easier or harder?
- Has price merely crossed a level, or established itself beyond it?
- Where is the next obstacle, and what would constitute an actual change in character?

Do not begin by asking which indicator can make the answer green. Begin with the price map.

## 2. Set up a chart that can be read correctly

Before drawing, record symbol, instrument, venue/feed, adjustment convention, session, timezone, interval, visible dates and last completed bar. A split, dividend adjustment, missing session, stale quote or incomplete candle can create a visually persuasive but different picture. Keep these checks brief and systematic so they support analysis rather than replace it.

Use an uncluttered price pane first, then add volume and only the overlays needed for the question. Keep the vertical scale explicit. Linear axes compare absolute changes; logarithmic axes compare proportional changes. A line spanning a multiyear doubling can look quite different after changing scales. The ChartSchool trendline guide explicitly discusses this distinction and recommends not forcing lines through incompatible pivots. [S02]

For this workflow, assign one job to each established timeframe:

- **Weekly:** larger trend, major base or distribution, major overhead supply, room to move.
- **Daily:** swing structure, setup location, important gaps and levels, principal invalidation.
- **Hourly:** current approach to the level, acceptance/rejection, turn or continuation.
- **10-minute:** refine the route and immediate execution geometry after the larger setup exists.

This mapping is an original workflow for the user's four views, not a claim that Shannon prescribes these exact intervals. Shannon's own FAQ separates context, intermediate risk/reward and fine entry timing, and treats moving averages as places to inspect price behavior rather than automatic trades. [S27]

**Do not let a smaller chart silently change the trade.** A 10-minute higher low inside a daily breakdown may describe a bounce, not a repaired daily trend. Conversely, a small intraday pullback does not by itself cancel a sound weekly advance. Write the intended holding horizon before resolving the apparent conflict.

## 3. Build the structural map with dated pivots

An uptrend consists of advancing swing highs and lows; a downtrend consists of declining ones. A sideways sequence has repeated overlap rather than sustained directional progress. Fidelity also distinguishes primary, secondary and minor trends: the smaller movement sits inside a larger one. [S03]

For a reproducible reading, choose a pivot convention and retain it throughout the review. Here is an original training convention:

- A **candidate high** is the highest high so far in the local upswing.
- A **confirmed five-bar pivot high** has two completed bars with lower highs on each side. A low is the converse.
- Record both **pivot date** and **confirmation date**. A Monday high confirmed after Wednesday's close was not known to be that pivot on Monday.
- Use a separate **structural swing** label when a move is important to the trade horizon. Not every five-bar pivot deserves a horizontal level.

This is a training convention, not a universal definition. If equal highs or outside bars occur, state how ties are handled. Changing pivot rules to rescue a pattern defeats the purpose.

Mark the last two meaningful highs and lows. Then ask what broke first. In an uptrend, a lower high is a warning; a break of the important higher low adds different evidence. A very steep trendline can break while the sequence of higher lows survives. A horizontal range may form before any reversal. Do not collapse all three into “trend is dead.”

Dow Theory supplies the larger idea of trend persistence and confirmation across market averages. Its historical confirmation framework concerns the Industrial and Transportation averages; applying an analogous check to an index, sector and individual stock is a modern adaptation, not the original rule. [S04]

### A useful swing-comparison worksheet

For each impulse and correction, record:

| Field | What to inspect | Why it helps |
|---|---|---|
| Distance | Points, percentage and optionally ATR units | Separates economic size from screen appearance |
| Duration | Completed bars | Distinguishes a fast repricing from a slow drift |
| Overlap | How much each bar re-enters prior bars | Identifies smooth movement versus negotiation |
| Close location | Near high, low or center | Describes how much of the excursion remained |
| Participation | Relative volume on comparable intervals | Puts price progress in activity context |
| Boundary result | New extreme, rejection, hold or failure | Connects local action to the structural map |

Compare like with like. An eight-bar correction cannot be judged only by total volume against a two-bar impulse; inspect average activity and the distribution of activity as well.

## 4. Draw zones and trendlines that answer a question

Support and resistance are areas of repeated interaction, not magical pixel-perfect prices. Prior turning points and accepted ranges are useful anchors; a broken level may later change role. ChartSchool explicitly allows zones when volatility makes a single price too precise. [S01]

An original three-layer zone method:

1. **Core:** the cluster of closes or repeated bodies around the level.
2. **Excursion band:** nearby wicks showing how far price repeatedly probed.
3. **Failure boundary:** the distinct structural extreme beyond which the current interpretation needs revision.

Do not mechanically widen all zones. A wide zone may be accurate but unsuitable for a tight-risk entry. The solution is to wait for a smaller structure or accept that this setup offers poor trade geometry, not invent a tighter structural stop.

Choose levels before examining the outcome. Prioritize the nearest relevant levels plus major higher-timeframe boundaries; a chart covered with twenty lines can explain anything after the fact. Keep a level record: origin, dates tested, type of reaction, timeframe and current role. Fresh tests that produce strong displacement matter differently from repetitive weak bounces that make less progress.

For trendlines, connect meaningful lows in an advance or highs in a decline. Two points establish a candidate; a third separate interaction strengthens the interpretation. Keep the anchors and scale fixed. Record a revised line separately instead of erasing the old one. A break is an event to investigate: did the move merely decelerate, enter a range, or reverse its swing structure? [S02]

**Confluence should mean different information.** A former range top, a rising daily average and an event-anchored cost reference can describe different aspects of the same area. Three similar moving averages derived from the same closes do not supply three independent confirmations. Count the reasons, but also describe them. The practical benefit is a clearer decision area, not a fictional probability produced by counting lines.

## 5. Read candles as local events

The body connects open and close; the wicks mark excursions to the high and low. Compare body, range and wick size with recent bars, not only with the other parts of the same candle. A large candle after prolonged quiet carries different information from an equally large candle during already violent trading. [S05]

Use these original numerical descriptors when useful:

- Range = high − low.
- Body fraction = |close − open| / range.
- Close location = (close − low) / range.
- Upper rejection fraction = (high − max(open, close)) / range.
- Lower rejection fraction = (min(open, close) − low) / range.

For a zero-range candle, mark these ratios undefined rather than dividing by zero. These descriptors standardize observations; they are not themselves a complete signal model.

A bullish engulfing body covers the previous body; it need not cover the full previous high–low range. A hammer after a decline highlights a lower-price rejection; a morning star organizes a decline, hesitation and recovery across three candles. Context and follow-through are part of interpreting a bullish reversal, not optional decoration. [S06]

The bearish counterparts ask whether an advance is losing control. A shooting star emphasizes an upper excursion that was not retained; bearish engulfing and dark-cloud cover show stronger selling after an advance; an evening star organizes advance, hesitation and decline. A small body alone is not bearish: its meaning depends on the preceding move and subsequent resolution. [S07]

**What OHLC cannot tell you:** one candle does not reveal the order in which its high and low occurred, the actual path between them, participant identity, or whether a named fund bought. If that distinction matters, inspect a lower timeframe or trade data. “Buyers defended this area” is an interpretation of price response; “institutions accumulated exactly here” requires evidence beyond the silhouette.

## 6. Price and volume: study the relationship

Volume helps distinguish a quiet pause from active repricing, but it must be attached to the movement it accompanies. Fidelity's educational discussion uses volume as confirmation of a price trend; it does not make a tall histogram sufficient to identify the next direction. [S08]

An original four-cell reading grid:

| Price result | Participation | First interpretation to investigate |
|---|---|---|
| Strong progress | Expanding | Active directional move; inspect location and extension |
| Little progress | Expanding | Two-sided opposition; ask which boundary survives next |
| Modest correction | Contracting | Possible pause; test whether the prior side resumes control |
| Large excursion | Thin | Vulnerability or lack of opposing liquidity; inspect tradability and next response |

The important word is **investigate**. At support, heavy activity with little further decline could precede a rebound; at resistance, heavy activity with little rise could precede a retreat. But an ongoing strong move can also pause and resume. The next test resolves part of that ambiguity.

Compare current intraday volume with historical activity at the same time of day, not with a full-day total. Distinguish consolidated shares, one-venue volume, futures contracts and tick counts. If the source is venue-limited, the reading describes that feed. This makes the interpretation precise enough to use rather than invalidating it.

## 7. The pattern family handbook

Each family below has four layers: recognizable geometry, structural meaning, completion event and a nearby alternative explanation. A pattern can be useful while still forming, but anticipation and confirmed completion are different entry styles.

### 7.1 Head and shoulders top

After an advance, identify a peak, a higher peak and a later lower peak. Connect the intervening reaction lows as the neckline. The crucial event is loss of neckline support, not merely a symmetrical drawing. A return toward the broken neckline can test its new role. The head-to-neckline height supplies a conventional projection, but intervening support remains relevant. [S09]

**Reading task:** distinguish a lower right shoulder from an ordinary pause beneath a recent high. Until support breaks, the chart may still be a range. Avoid manufacturing symmetry by ignoring inconvenient bars.

### 7.2 Inverse head and shoulders

After a decline, look for a low, a deeper low and a higher low, separated by rebounds defining the neckline. A break above that boundary completes the classical formation. The bottoming guide gives greater weight to expansion in activity on the upside completion than in the topping counterpart. [S10]

**Reading task:** notice the transition from inability to hold a new low to inability to revisit it. A higher right shoulder is promising structure, but the overhead neckline remains an obstacle until overcome.

### 7.3 Double top and double bottom

Two similar peaks after an advance create a possible double top; the intervening trough is the confirmation boundary. Two similar troughs after a decline create a possible double bottom; the intervening high is the confirmation boundary. The first test is normal trend behavior; the second establishes a comparison, not certainty. [S11, S12]

**Reading task:** ask whether the second approach is forceful or hesitant, whether it spends time beyond the first extreme, and whether the reaction breaks the intervening structure. Do not call every pair of highs a top. A sequence of rising lows beneath those highs might instead be an ascending triangle.

### 7.4 Triple tops and bottoms

Three separated similar highs followed by a support break define a completed triple-top reversal. Three separated similar lows followed by a resistance break define a completed triple-bottom reversal. Before completion, the same boundary interactions can belong to a rectangle or triangle. [S13, S14]

**Reading task:** the number of touches is less informative than the path between them. Deeper reactions away from resistance suggest a different balance than increasingly shallow reactions into the same ceiling. Three equal lows with falling rally peaks are not automatically a bullish base.

### 7.5 Ascending, descending and symmetrical triangles

An ascending triangle combines a roughly level ceiling with rising lows; a descending triangle combines a roughly level floor with falling highs. Their conventional directional biases differ. A symmetrical triangle contracts between lower highs and higher lows; its eventual escape direction deserves observation rather than assumption. Participation often contracts during compression and expands on resolution. [S15, S16, S17]

**Reading task:** mark all qualifying swings, not only the two that create the neatest lines. A breakout occurring only because converging lines have nearly reached their intersection may convey less actual displacement than an earlier decisive move. An opposite-side breakout changes the working interpretation.

### 7.6 Rising and falling wedges

Both boundaries slope in the same direction and converge. In a rising wedge, advances are becoming narrower as price climbs; in a falling wedge, declines narrow as price falls. A rising wedge has a conventional bearish bias, a falling wedge a bullish one, but the relevant boundary break supplies completion. The prior trend determines whether the setup would be a continuation or reversal. [S18, S19]

**Reading task:** distinguish a genuinely narrowing structure from a parallel channel. Rising lows do not cease to exist merely because the shape has been labeled bearish. Record the point where the actual swing sequence changes.

### 7.7 Expanding formations and broadening wedges

A megaphone alternates to higher highs and lower lows; it describes expanding rather than contracting swings. It should not be read as a quiet coil. [S20]

For an ascending broadening wedge, both boundaries rise but the upper rises faster; for a descending one, both decline while separating. Bulkowski's own indexed descriptions distinguish these from converging wedges and discuss breakouts and failed breakouts. Direct page opens were blocked, so this study uses the indexed first-party definitions only, not an independently audited performance claim. [S21, S22]

**Reading task:** expanding risk distance can turn an attractive-looking boundary into an impractical entry. Do not import a tight-coil stop into a widening structure.

### 7.8 Flags and pennants, bullish and bearish

First locate the forceful preceding move, the flagpole. The pause is smaller: a flag is commonly a compact parallel consolidation against the move; a pennant is a compact converging one. The directional continuation is completed by a break out of the pause in the prior impulse's direction. A generic sideways patch without an impulse is not automatically a flag. [S23]

**Reading task:** compare the pause's depth, duration and activity with the impulse. Is it compact and controlled, or has it retraced most of the move and acquired its own opposing trend? A bullish flag below major daily resistance has a different route from the same flag above a newly cleared base.

### 7.9 Cup and handle; inverted cup and handle

A cup with handle combines a rounded consolidation, recovery toward the prior rim and a smaller final pullback or pause. The handle breakout is the principal completion event; a very sharp V rebound is not the classic rounded cup. [S24]

The inverted form reverses the broad geometry: a rounded crest and decline followed by a smaller handle before a downside resolution. Bulkowski's first-party indexed examples show varied shapes and durations; the direct page could not be opened, so this is identified as excerpt-based coverage. [S25]

**Reading task:** measure the handle relative to the cup and examine its location. A very deep handle can be a new deterioration rather than a minor final pause. Do not use a name to conceal that difference.

### 7.10 Rectangles and channels

A rectangle repeatedly rotates between approximately horizontal boundaries; a channel does so between approximately parallel sloping boundaries. A rectangle's breakout completes the formation. In a rising channel, lower-boundary support and progress toward the upper boundary matter; failure to reach the upper side can be an early change, while an upside escape may represent acceleration rather than reversal. Reverse the reading for a falling channel. [S26, S28]

**Reading task:** separate trading a rotation inside the structure from trading escape from it. Buying the upper edge with a range-trading premise is inconsistent unless a distinct breakout premise has replaced it.

## 8. Breakouts, retests and failed patterns

Use a five-stage vocabulary:

1. **Approach:** price is near the marked boundary.
2. **Probe:** price trades beyond it but does not necessarily close there.
3. **Close-through:** the completed chosen bar finishes beyond it.
4. **Acceptance:** subsequent behavior sustains trade beyond the area rather than immediately abandoning it.
5. **Retest and response:** price returns; the next reaction tests whether the role has changed.

This is an original operational vocabulary. Choose beforehand which stage is sufficient for the specific setup. Requiring every stage can miss moves without retests; requiring only a probe accepts more unconfirmed entries. These are tradeoffs to practice, not reasons to keep changing standards afterward.

Record breakout quality in components, not a single magical score:

- Displacement beyond the boundary relative to volatility.
- Closing location and retained distance beyond the zone.
- Number of completed bars holding beyond it.
- Expansion or contraction of participation on comparable intervals.
- Distance to the next meaningful obstacle.
- Stretch from the nearest defensible structure.
- Reaction at a retest, if one occurs.

A dramatic wide-range bar can establish direction and still be a poor new entry because it is too far from the structure that would define the risk. The right reading can therefore be “bullish breakout, wait for a new structure” rather than “bad breakout.”

**Failed patterns are part of learning the craft.** Write what was expected, how soon it should appear, and what actually appeared. A return inside a range after a breakout is an alert; sustained movement through the opposite side is a more substantial reversal of evidence. Do not automatically reverse every stopped-out trade: an unsuccessful entry is not always an opposite setup.

Grimes teaches pullbacks as a core pattern family and describes a nested pullback as a smaller pause during the drive out of a larger one. This can help interpret a second entry opportunity or avoid mistaking every pause for a failure. [S29, S30]

## 9. Gaps and relative strength

Distinguish a gap between yesterday's close and today's open from a full gap between the prior range and current range. Context separates common congestion gaps, breakaway gaps, continuation/runaway gaps and possible exhaustion gaps. A gap out of a base should be inspected differently from a late gap after a long extended run. Do not assume every gap must fill immediately. [S31]

An original gap worksheet: prior range, opening price, gap size in ATR units, catalyst/time if known, first completed response, whether the old range was reclaimed, and end-of-period acceptance. A gap can remain open while the new session is weak; measure both the gap and the subsequent auction.

Relative strength is comparative performance, not RSI. The ratio of stock price to a relevant benchmark rises with outperformance, which can occur while both prices decline. Inspect both stock/index and stock/sector comparisons to separate broad exposure from individual leadership. [S32]

**Original example:** stock falls 2% while its sector falls 5%. It is relatively stronger but still losing absolute value. That can place it on a watchlist for recovery; it does not independently establish an upward entry trigger. Conversely, a stock up 3% while its sector gains 8% is rising but lagging.

## 10. Wyckoff as a sequence-reading framework

Wyckoff's practical sequence links market position, comparative stock strength, a base's potential, readiness and timing. Springs test below a range and return; upthrusts do the converse. A sign of strength followed by a controlled backup, or a sign of weakness followed by a weak rally, organizes the change in control. [S33]

The phase framework distinguishes stopping the prior move, building a range, testing, directional development and leaving the range. Springs are not mandatory in every accumulation schematic; upthrusts after distribution are not mandatory in every distribution schematic. Compare effort (activity) with result (price progress) while treating labels as hypotheses about the sequence. The Composite Man is a heuristic, not identification of an actual hidden actor. [S34]

**Original practice adaptation:** annotate events first in neutral language: “new low, immediate recovery,” “smaller retest,” “strong advance through range,” “shallow return.” Only then add Wyckoff labels. If the neutral description cannot be supported, the specialized vocabulary does not improve it.

## 11. Four original worked cases

These are intentionally numerical and hypothetical. Their purpose is to train the reasoning that a visual chart must support, not to imply observed performance.

### Case A: a promising breakout that is already extended

Daily resistance was marked at 50.0–50.5 from three earlier interactions. A base low is 45.0. The latest daily candle opens 49.8, trades down to 49.4, reaches 54.0 and closes 53.6. Recent ATR is 1.6. Activity is 1.9 times the chosen comparable baseline.

**Read:** the close is beyond the zone; the body retains much of the advance. But the close is 3.1 above the top of the old zone, about 1.94 ATR. A stop beneath a hypothetical 49.4 reaction low would create 4.2 points of risk from that close. If the nearest significant overhead area is 56, the immediate route offers only 2.4 points before an obstacle, approximately 0.57 times that risk before costs.

**Better chart conclusion:** the breakout and the entry are different judgments. Record positive directional evidence, then watch for a compact consolidation or orderly retest. Do not redraw support at 53 merely to manufacture a smaller stop. If price continues without offering acceptable geometry, the reading can remain correct without a trade.

**What to inspect next:** is the return to 50–51 slow and overlapping, or fast and forceful? Does the next advance emerge from a defined higher low? Does participation expand on the rebound? This is how chart reading turns into a conditional plan.

### Case B: triple bottom or descending triangle?

Three lows occur around 80. The rebounds peak at 94, 90 and 86. A fourth approach reaches 80.4. There is no completed close above any recent declining high.

**Read:** the equal lows alone invite a triple-bottom label. The declining rebound peaks supply a competing and more immediately important feature: each recovery has made less progress. Draw both the floor and declining highs. The current state is unresolved pressure around support, not a completed bullish reversal.

**Bullish development:** a firm recovery through the latest meaningful lower high followed by a higher low would change the local sequence. A later break above the larger intervening resistance would strengthen the larger reversal interpretation.

**Bearish development:** a close below the floor with continued trade below it, followed by a failed recovery, would confirm a different resolution. The analyst does not need to know which will happen to identify exactly what matters.

### Case C: failed breakdown and a constructive test

A range has existed between 100 and 110. Price trades to 98.8 but closes 101.2. Two bars later it returns to 100.4, with a smaller range than the 98.8 bar, then closes 102.0. The next bar reaches 104.0. These figures describe a possible failed breakdown and a higher test, not yet a range breakout.

**Read:** the first event is a rejection below the floor. The second shows that the next test did not reach the same low and the market subsequently moved away. That is a stronger sequence than either candle alone. The original 110 ceiling remains relevant. A move through 104 is a local development, not proof that 110 has vanished.

**Training decision:** label the early idea “range recovery,” with a distinct plan from a future “range breakout.” Track whether price can reach the middle and then upper boundary. If the recovery collapses and accepts below 100, retire the earlier spring interpretation rather than moving its definition downward.

### Case D: weekly uptrend, daily correction, hourly turn

The weekly chart has higher swing lows at 120, 135 and 150. The daily chart has corrected from 176 to a previously marked 156–160 area. Hourly peaks during the correction are 168, 164 and 161.5. Price then closes hourly at 162.2, retests 160.5 and moves back above 162.2.

**Read:** weekly structure is still constructive; daily price is at a meaningful area; hourly behavior has begun to repair its own descending sequence. The hourly development gives timing information. It does not guarantee the daily correction has ended, and the weekly 150 structure is not a sensible substitute for a deliberately smaller timing risk without considering position size.

**What makes the case stronger:** the daily close retains the area, the next hourly impulse makes progress, the stock's ratio to its sector stops deteriorating, and the next daily obstacle leaves useful room. **What changes it:** acceptance below the zone, renewed hourly lower lows, or a broad-market deterioration affecting the setup. The lower timeframe refines the larger plan; it does not create one from nothing.

## 12. Deliberate practice that builds usable expertise

Use unseen right edges, not only attractive historical winners. Freeze a chart at a date. Write the map and conditional interpretations before revealing the next bars. This is a learning drill: it separates visual recognition from hindsight narration.

### Exercise set with answer keys

1. **Two highs, rising intervening lows:** Name two interpretations. Answer: possible repeated resistance/ascending triangle; a completed double top requires the relevant support break.
2. **Steep trendline break but no important low broken:** Answer: deceleration or consolidation is possible; do not equate line break with confirmed structural reversal.
3. **Green candle closing below yesterday's close after a down gap:** Answer: intrabar recovery and negative close-to-close change can coexist. Candle color is not the full session result.
4. **Price rises while stock/sector ratio falls:** Answer: absolute gain, relative lag. Do not call it leadership solely because the chart is green.
5. **A bullish daily setup with an incomplete weekly candle:** Answer: separate the completed weekly background from the current week's developing information.
6. **Very high volume, small range at resistance:** Answer: active opposition; inspect the next boundary test. Neither accumulation nor distribution is proven by the single bar.
7. **Flag without a preceding impulse:** Answer: call it a small range or channel until the defining context exists.
8. **Falling wedge breaks upward, immediately returns and loses its low:** Answer: original bullish completion failed; map the actual new structure before considering an opposite idea.
9. **A 52 breakout target and 51 major resistance:** Answer: the target is a projection; the nearer obstacle remains part of route planning.
10. **A pivot drawn on Monday confirmed Wednesday:** Answer: date the turning point Monday and the information availability Wednesday.
11. **Breakout hold for three hourly bars but no daily close yet:** Answer: hourly acceptance has evidence; daily completion remains developing.
12. **A hammer at the center of a broad range:** Answer: local rejection is observable, but its location provides less structural specificity than a test of a premarked boundary.

Score a review on observation accuracy, level selection, timeframe consistency, pattern differentiation, useful conditional forecasts and adaptation to new bars. Score the economic outcome separately. A clear, disciplined reading can lose; a vague reading can get lucky. The purpose of review is to improve the craft, not to declare it invalid.

### The one-page reading card

- Instrument / feed / timestamp / completed-bar status:
- Weekly state and principal boundaries:
- Daily swing highs/lows with confirmation dates:
- Current setup location and pattern alternatives:
- Hourly sequence and 10-minute refinement:
- Candle and volume evidence:
- Benchmark and sector comparison:
- Setup state: forming / triggered / retesting / extended / failed:
- What should happen next if this reading is useful:
- What changes the reading:
- Entry alternatives and nearest obstacle:
- Management observations and time horizon:
- Outcome later, without rewriting the original reading:

Mastery is the ability to make these observations quickly, accurately and consistently across unfamiliar charts, then improve through feedback. The deliverable establishes an explicit reading method and study base. Demonstrated skill comes from applying it to many dated charts with preserved before-and-after reasoning.

## 15. Advanced practitioner perspectives: translate different vocabularies into observable decisions

These are selected lawful excerpts and firsthand teaching, not a claim to have read every author's books or watched entire paid courses. They complement the original handbook rather than establish universal success rates.

### Adam Grimes: structure, action and the quality of the pause

The publisher's authorized *The Art and Science of Technical Analysis* excerpt distinguishes the arrangement of pivots and levels from the evolving behavior that produces them. Selected passages also discuss consistent chart conventions, swing relationships and lower-timeframe detail. This suggests a useful two-column practice: record the stable map separately from the latest evidence that confirms or challenges it. [S35]

Grimes's author-hosted flag article treats the preceding directional impulse and subsequent pause as a linked sequence. It distinguishes anticipatory entry during consolidation from confirmation entry as the pause breaks. The nearest prior extreme can matter before more ambitious projected targets. A flag's quality is therefore not established by drawing two parallel lines alone. [S36]

In his firsthand interview, Grimes explains failure tests around readily recognizable levels, the importance of prompt movement after the failed probe, and the danger of forcing countertrend interpretations everywhere. He gives a nested example: a failure test at the bottom of a bullish complex pullback. His timeframe discussion ties the relevance of a level to the timeframe actually being traded. These are interview statements and practitioner teaching, not performance evidence. [S37]

### Al Brooks: a vocabulary for evolving bars

Brooks's glossary makes context central and distinguishes breakout, breakout pullback, breakout test and follow-through. His double-bottom terminology can describe a brief continuation structure inside a bull flag; it need not mean a major classical reversal. His “failed failure” describes an apparent breakout failure that reverses again into continuation. These distinctions are useful, but his terminology and numerical assertions should not be silently treated as interchangeable with ChartSchool's definitions or as verified probabilities. [S38]

### Original synthesis: three layers of a discretionary reading

**Layer 1 — the map.** Mark the prevailing swing sequence and meaningful price zones before interpreting the newest candle. Example: the prior impulse is 200 to 220, the latest higher low is 210, and resistance above is 228–230.

**Layer 2 — the contest.** Describe how the two sides interact inside that map. Price declines 220 to 214 in three bars, rebounds to 218 in two, then declines to 213.5 in five smaller overlapping bars. This is not automatically bearish because it contains a lower low. Compared with the first decline, the second travels less distance despite more time. That is a measurable observation, not proof of exhausted supply.

**Layer 3 — resolution.** Require behavior that distinguishes the alternatives. A move through 218 with sustained closes above the internal pivot supports resumption. A fast decline through 210 with weak rebound changes the higher-low map. Repeated oscillation between 213.5 and 218 without progress leaves a balance, not a compulsory entry.

The same sequence can be called a complex pullback, a small trading range, or an unfinished double bottom. The useful agreement is the set of pivots and what their break would mean. Do not force the labels to agree before making a factual description.

### Original exercise: the failed failure without hindsight

A marked range is 40–44. Price closes 44.6, next closes 43.7, then 44.8. At each close write only what is known:

1. **44.6:** initial breakout; no multi-bar acceptance yet.
2. **43.7:** return into the range; bullish continuation now needs renewed evidence. This is not permission to assert an inevitable collapse.
3. **44.8:** re-expansion above the boundary; the first rejection has itself failed so far. The next test is whether price can stay outside and progress, not whether the prior bearish label was embarrassing.

Compare two continuations: (a) 45.2 then a controlled test of 44.3, versus (b) 44.0 then 42.8. Update the state table without redrawing historical levels. Record the transaction costs of acting on every reversal versus waiting for the preselected confirmation rule. This is an exercise in state transitions, not an instruction to reverse positions at every close.

### Original exercise: anticipation and confirmation are different trades

Use the 200–220 impulse and 213.5–218 pause above. A hypothetical anticipatory long at 214.5 with structural invalidation below 210 offers a different risk distribution than a confirmation entry at 218.5 using the same invalidation. The first may never receive a valid trigger; the second pays more for evidence and may be too close to the 220 obstacle. A tighter stop below a timing-chart pivot is not equivalent to the original structural stop: it can exit while the larger setup remains intact. Record which hypothesis each stop actually tests. Distinguish an invalidated entry from an invalidated market thesis.

### Original practice: make intuition inspectable

For every discretionary adjective, supply a measurement or comparison:

- “Strong” → distance per bar, proportion of closes near extremes, limited overlap, or progress beyond a prior pivot.
- “Orderly” → narrower ranges, modest retracement, limited adverse gaps and no destruction of the controlling swing.
- “Absorbing” → repeated tests with less adverse progress; treat absorption as an inference, since candles do not reveal all resting liquidity.
- “Exhausted” → extended movement followed by failed continuation and reversal evidence; extension alone is not exhaustion.
- “Clean” → few competing pivots between entry and obstacle, not simply an attractive screenshot.

Build an atlas with twenty accepted examples and twenty near-misses of one setup. Preserve both the before chart and later outcome. Have a second reader label it without knowing the result. Resolve disagreements by tightening observable definitions rather than making the chart more persuasive. This converts visual familiarity into a reproducible skill while retaining room for expert contextual judgment.
