# Actual corpus charts: five visual readings

Inspected October 30, 2026. These are archived market-chart renderings from the user's GitHub corpus, not newly acquired market data. The actual image pixels were inspected. The analysis below is my own visual reading, distinguished from the chart's saved engine markers and metadata. Approximate levels are read from axes, not reconstructed exact OHLC values. Source-provider, engine-parity and signal claims in companion JSON files are reported as repository metadata, not independently reverified facts.

The four Agentic-Trading-Desk images explicitly include future bars after an interior event line. They are labeled RETROSPECTIVE_VISUAL_RESEARCH_ONLY in their JSON. Thus this is **exposed retrospective practice**, not a blind prediction test. Event-era observations below describe what the left portion supports, but the analyst has seen the full image. A later blind drill must hide future bars *before* inspection. Source image links are supplied rather than reproducing these archived images in the written handout.

## 1. MELI weekly: trend resumption within a larger advance

[Open the exact archived chart](https://github.com/dwj9ddyvf6-hub/Agentic-Trading-Desk/blob/4c8c179c5988d6e603c1f3c5f28f93e2344ca225/research_archive/tensor_full_chart_golden/MELI-1wk-2023-08-28-6049537b3cb401ad66f3.png) · [Companion metadata](https://github.com/dwj9ddyvf6-hub/Agentic-Trading-Desk/blob/4c8c179c5988d6e603c1f3c5f28f93e2344ca225/research_archive/tensor_full_chart_golden/MELI-1wk-2023-08-28-6049537b3cb401ad66f3.json)

**Identity and canvas.** MELI, weekly, visible approximately August 2022–February 2024. The event is August 28, 2023, index 54 of 81 bars; 26 subsequent bars are deliberately visible. The green 1,420 label is aligned with the event crosshair, not the final bar. The price axis appears linear. Ribbon, envelope, volume and squeeze panels are visible; adjustment/session/feed coverage details are not specified in the image.

**What I actually see.** The left portion progresses from a broad low area around 800–950 into an early-2023 rise, followed by a prolonged shallower consolidation generally above the old low area. The ribbon rises, then flattens as price moves sideways. Around the event line, price is pushing above the local consolidation with a positive squeeze histogram. The event is not the original low of the whole move. The displayed volume label is only modestly above its stated average, not an extraordinary participation burst.

**Interpretation at the event region.** This is more naturally read as potential resumption of an established larger advance than as bottom fishing. A useful question is whether the market can retain the upper part of the consolidation and establish a higher low after the push. The strongest competing reading is another excursion within a still-unresolved weekly range.

**Decision criteria.** Look for completed weekly trade retained above the local shelf or a constructive retest; failure back into the body of the range and loss of the prior swing low weaken the continuation interpretation. Exact execution levels need the underlying bars rather than these approximate pixels. The saved metadata lists buy-cyan, consensus-buy and extension-warning together: positive direction and extension risk can coexist.

**Visible later development, not foreknowledge.** A pullback toward roughly 1,200 occurs before the later advance toward 1,750–1,850. The late-chart pullback toward the rising ribbon demonstrates why “event followed by an eventual rally” does not settle the best entry, intervening risk or holding policy.

**Learning takeaway.** Read trend phase, entry distance and pullback behavior separately. A favorable weekly structure does not erase the need to time the location within it.

## 2. SQM daily: expansion, exhaustion of progress, then structural deterioration

[Exact chart](https://github.com/dwj9ddyvf6-hub/Agentic-Trading-Desk/blob/4c8c179c5988d6e603c1f3c5f28f93e2344ca225/research_archive/tensor_full_chart_golden/SQM-1d-2021-11-01-6e19b731780219e0f07a.png) · [Metadata](https://github.com/dwj9ddyvf6-hub/Agentic-Trading-Desk/blob/4c8c179c5988d6e603c1f3c5f28f93e2344ca225/research_archive/tensor_full_chart_golden/SQM-1d-2021-11-01-6e19b731780219e0f07a.json)

**Identity and canvas.** SQM daily; visible July–December 2021. Event November 1, 2021, index 78 of 121; 42 later bars visible. Green 49.18 is the event reference, not the right-edge price, which is around 44. Linear-looking price axis, ribbon, envelope, volume and squeeze. The underlying data and event timestamps were not independently recomputed.

**Event-region observation.** The chart has recovered from its earlier lows and spent time trading around the mid-to-upper 40s. The event appears near a fresh push from that area with the fast lines curling upward. A large subsequent advance to the upper 50s is already visible to the right, but is not information available to an actual November 1 decision.

**Event-region inference and alternative.** A continuation attempt from a local base is plausible. The alternative is another failed move through nearby prior highs. Useful confirmation would be retention of the breakout zone and follow-through rather than immediate return below the base. The metadata again combines a buy marker with an extension warning; marker semantics should not be collapsed into a single unqualified green light.

**Read the transition on the right.** Following the expansion, candles overlap near the upper range, then a later upward excursion fails to produce sustained new progress. Price loses the fast ribbon, the ribbon begins bending down, and later bars move toward the slower references in the mid-40s. The squeeze panel changes from a large positive pulse to negative values. This is a sequence of evidence, not one oscillator suddenly commanding an exit.

**Competing explanation during the first pullback.** The first decline can still be a normal correction. The interpretation becomes materially less constructive when lower highs develop and prior support fails to hold or reclaim. A fresh reclaim would be a new observable event, not something to assume because an old buy marker remains on the screen.

**Learning takeaway.** Practice the management read as carefully as the entry read. Distinguish waning upside momentum, actual loss of support and completed downtrend structure. The image illustrates all three stages without providing trade fills or a tested exit rule.

## 3. TGT weekly: a repair process rather than instant trend reversal

[Exact chart](https://github.com/dwj9ddyvf6-hub/Agentic-Trading-Desk/blob/4c8c179c5988d6e603c1f3c5f28f93e2344ca225/research_archive/tensor_full_chart_golden/TGT-1wk-2023-12-04-a0c41f275aaef0003506.png) · [Metadata](https://github.com/dwj9ddyvf6-hub/Agentic-Trading-Desk/blob/4c8c179c5988d6e603c1f3c5f28f93e2344ca225/research_archive/tensor_full_chart_golden/TGT-1wk-2023-12-04-a0c41f275aaef0003506.json)

**Identity and canvas.** TGT weekly, roughly November 2022–June 2024. Event December 4, 2023, index 54/81, with 26 future bars. Green 122.37 is the interior event level. Ribbon, AVWAP-style references, envelope, volume and squeeze are shown. Linear-looking price axis; exact settings not all recoverable from the pixels.

**Observed structure.** A sustained decline from the 150s reaches a broad low area in the 90s. A large upward weekly bar interrupts that decline. Around the event, price continues improving while faster ribbon lines turn upward, but several slower lines above remain flat or downward. The event-region displayed relative volume is 78%, which is not the same as the conspicuous participation on a different, later bar.

**Interpretation.** The key event is a transition from persistent downside progression into repair. It is too coarse to label the entire scene “bullish” without saying what has improved: price has displaced upward from the lows, momentum has turned positive and fast trend references are changing. The larger downtrend's overhead structure still matters.

**Competing explanation.** This could initially be a strong bear-market rally into prior supply. To favor a more durable reversal, observe the next pullback: does it form a higher low, and can price subsequently overcome another meaningful lower high? Those are sequential structure tests. A moving-average cross alone cannot tell the whole story.

**Visible later evidence.** The chart shows a multiweek pause around the upper 120s, another advance into the 150s/160s and then a pullback toward the 140 area. This later development is useful for studying repair → consolidation → expansion → retest. It does not retroactively make the first weekly surge a riskless entry.

**Learning takeaway.** Separate “the decline has been interrupted,” “a base is forming” and “an uptrend is established.” A skilled reader can act at an earlier stage if the permitted strategy supports it, but should name the actual stage and its competing interpretation.

## 4. VRNS daily: rounding repair, local balance and delayed expansion

[Exact chart](https://github.com/dwj9ddyvf6-hub/Agentic-Trading-Desk/blob/4c8c179c5988d6e603c1f3c5f28f93e2344ca225/research_archive/tensor_full_chart_golden/VRNS-1d-2023-06-29-b740ce72ea8f7e8a0025.png) · [Metadata](https://github.com/dwj9ddyvf6-hub/Agentic-Trading-Desk/blob/4c8c179c5988d6e603c1f3c5f28f93e2344ca225/research_archive/tensor_full_chart_golden/VRNS-1d-2023-06-29-b740ce72ea8f7e8a0025.json)

**Identity and canvas.** VRNS daily, approximately March–August 2023. Event June 29, 2023, index 78/121; 42 future bars. Green 26.53 is the interior event level, not the final price in the low 30s. Ribbon, envelope, volume and squeeze shown. Displayed units and source metadata do not establish consolidated exchange volume.

**Observed event context.** The earlier decline bottoms in the low 20s and then rounds upward. Price later stalls near 26–27, retraces toward the clustered ribbon around 25 and recovers toward the upper portion of that local balance. Around the event line the ribbon is comparatively compact. The very large later volume spike and sharp advance are still to the right.

**Working interpretation.** The chart presents an improving base with a local recovery, rather than an already completed major breakout. This distinction matters: a buy marker inside a base may be an early-location signal whose path includes further waiting and overlap. The competing interpretation is continued range trading with another rejection near the ceiling.

**Decision criteria.** For a breakout-style reading, require price actually to leave and retain the upper boundary. For a pullback-style reading, the recovered local floor and the character of the next test matter more than a future breakout not yet observed. The exact trigger should follow the selected strategy rather than being reverse-engineered from the eventual high.

**Visible later evidence.** The chart continues balancing, then accelerates upward near late July with a pronounced volume expansion. It consolidates around 30–31, retraces toward the rising ribbon and advances again near the right edge. The constructive lesson is that a tight, improving base and a later expansion are different stages worth learning separately.

**Learning takeaway.** Do not demand that every technically sensible early setup move immediately. Equally, do not use a later successful breakout as proof that every earlier bar was an ideal entry. Define the setup's allowed time and structural persistence.

## 5. AMD Tensor daily: distinguish background, transition and trend-following cluster

[Exact archived chart](https://github.com/dwj9ddyvf6-hub/ClaudeDesk/blob/85b3bb0ca88c6f5a8a2529825a770bc29992743e/eyes/canon/amd_TD.png)

**Identity and canvas.** File identifies AMD; title reads TENSOR 1D, FolioTend v698 canonical, last 160 bars, **rebased last close = 100**. The horizontal axis is relative bar index, not calendar dates. No calendar endpoint or absolute dollar scale can be established from the image alone. The archive's canonical label is a provenance assertion, not a current deployed-version verification.

**Observed price structure.** Most of the left and center is a relatively broad, overlapping region near rebased 40–50 with several swings that fail to become sustained trends. Near relative bar −40, the chart changes character: higher lows lead into a sustained advance, the fast averages rise and separate, candles increasingly occupy the upper portion of the envelope, and the final segment approaches rebased 100. Several bullish markers appear *during* the advance, not only at its origin.

**Indicator-panel inspection.** The WaveTrend-style momentum lines rise into a high region; the squeeze bars become predominantly positive on the right; the OBV-like lower panel trends upward. Stoch RSI cycles within the rising phase, so its local declines do not automatically equal breakdown of the price trend. Numerous colored signals and symbols are visible, but one should use the actual legend/source mapping before assigning meaning to every glyph.

**Interpretation.** The useful visual distinction is the shift from overlapping balance into persistent directional progression. Later bullish marker clusters may be describing trend continuation, not independent new opportunities with equal risk. The primary observation remains the changing path of price.

**Competing reading near the right edge.** A strong trend can also be extended from its slower support references. Constructive trend evidence and unattractive immediate entry distance can coexist. A pullback might provide a new location, while a sharp loss of a recent higher low would require reassessment. The image alone does not specify an executable stop or current quote.

**Learning takeaway.** Start with price behavior, then ask which panels add distinct information. Do not let a crowded indicator dashboard hide the simple transition from overlap to higher highs/higher lows. Also, never report rebased 100 as AMD's dollar price.

## What this practice adds to the operating method

1. Always distinguish an interior event/cursor reference from the last visible bar.
2. Treat chart metadata as useful provenance, but do not confuse a saved assertion with a newly reproduced calculation.
3. Read the pre-event structure and subsequent path as separate learning objects.
4. Do not evaluate an early setup solely by the final high; inspect the intervening pullbacks, delay and changes of structure.
5. Separate direction, phase, location and timing. They are related questions, not synonyms.
6. Indicators are most useful when their role is explicit: trend background, momentum character, participation or timing.
7. Label visual approximations and missing settings instead of manufacturing numerical precision.

**Completion and limits.** Five actual corpus images inspected. Four companion JSON files read in full. All five local PNGs independently matched the Git blob hashes in the pinned repository inventory. No source image was edited, no trade/performance result was calculated, and no claim of blind predictive accuracy is made.
