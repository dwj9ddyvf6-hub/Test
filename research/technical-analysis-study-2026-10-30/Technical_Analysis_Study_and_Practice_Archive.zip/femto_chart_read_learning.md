# What the Femto chart reader teaches

## Source and reading scope

Source: [Femto-lean/core/chart_read.py](https://github.com/dwj9ddyvf6-hub/Femto-lean/blob/f714cc78f50b871e8346e3e725c7a92ebd95521b/core/chart_read.py), commit f714cc78f50b871e8346e3e725c7a92ebd95521b, blob 74a51c27de13657548aabb0ca34f026a2bec2a95. The complete source was retrieved and statically read in contiguous sections on October 30, 2026. No repository code was installed or executed. This is a reading of the implementation and its documented reasoning, not a verification of its historical calibration or current deployment.

The module is substantial prior work: a deterministic daily-chart reader operating on OHLCV bars. It reconstructs many relationships that a visual reader looks for, then emits dated facts and a drawing contract. This makes it useful as a measuring partner for discretionary visual inspection. Its numerical thresholds are house definitions, not universal definitions of technical analysis.

## 1. Its chart-reading sequence

The entry point cleans the supplied bars, requires at least 60 usable observations, applies a series-integrity review, and requires a positive ATR. It then computes confirmed pivots, Wilder RSI, ATR and MACD. Price spans of at least twofold switch its line-fitting space to logarithms. The pattern window attempts to follow the dominant completed swing rather than indiscriminately connecting remote extremes.

Next, it selects upper and lower boundaries, classifies geometry, clusters swing levels, describes averages and volume, enriches divergences, scans an accumulation sequence, and selects a relevant shelf. Specialized pattern detectors compete with the line-based reading. The final output includes pattern state, dated swing sequence, levels, divergences, indicator context, volume, a zone, invalidation and numerical geometry for rendering.

**Learning application:** read the naked chart first, then use this kind of numerical output to check measurements. If the visual description and measured geometry disagree, inspect the same dates, prices, scale and window before adding interpretation. A deterministic detector and a visual reading can be complementary rather than rivals.

## 2. Pivots have two dates

The implementation uses five bars on each side and strict extreme comparisons. A high at index i is available only after the right-side bars exist. Its pivot record stores the extreme's date; an analyst using it in replay must also preserve when that pivot became knowable.

For a learning exercise, stop a chart immediately after a new high, label it a candidate, then reveal five bars. Record whether it becomes a confirmed swing under this convention. A faster discretionary swing definition can be studied too, but should be named explicitly rather than silently borrowing the slower definition's certainty.

## 3. Trendlines are relationships with a lifecycle

The fitter compares lines through pivot extremes with internal lines through pivot-bar closes. It labels the latter, so wick omission is visible. Candidates need separation between anchors; the score weighs touch count, span, recentness, dominant-swing anchoring and violations. Distant or already-spent lines are filtered.

The operative implementation distinguishes holding, warning and broken/lost states. It examines consecutive closes beyond a tolerance and whether the earlier swing is also exceeded. This is more nuanced than the module's older introductory shorthand about a single decisive close. Learn the current logic from the body, not just the header.

**Practical translation:** when drawing manually, record the two anchors, scale, whether the line uses extremes or bodies, and the event that changes its status. Do not repeatedly redraw a broken line to keep a preferred story alive. But also distinguish losing a diagonal rate of advance from losing the horizontal swing structure.

## 4. Pattern recognition is more than outline resemblance

The line classifier checks narrowing or approximate parallelism, slope direction and whether the boundaries actually contain the closes. Triangles require touches on both sides and interior crossings. Wedges additionally require duration and a preceding directional move. The flag/pennant path looks for a strong pole and a restrained consolidation. These gates are a useful lesson in **context plus geometry**, even when another technician chooses different thresholds.

Specialized detectors inspect:

- Double tops/bottoms: comparable extremes, separation, a substantial intervening swing, prior trend, an actual second turn, and a close through the intervening extreme. A third comparable test disqualifies this implementation's double-pattern label rather than being silently included.
- Head-and-shoulders: alternating pivots, a distinct head, shoulder comparability and timing, usable neckline geometry, and confirmation. Excessively separated armpits use a stated alternate confirmation reference.
- Cup with handle: comparable rims, adequate duration and depth, a bottom occupied by several observations rather than a single V, then a shallow handle and confirmation.
- Rounding bottom: a sustained bowl with positive fitted curvature, sufficient depth, time near the low and recovery toward the rim.
- Climax-and-base: a measured sequence derived from the Wyckoff-style scan.

**Practical translation:** ask what distinguishes the candidate from a nearby alternative. Why is this a double bottom rather than three tests of a range floor? Why is this a handle rather than a collapse back into the lower cup? Why is this a wedge rather than two lines drawn through a drift? State those differences before accepting the label.

## 5. Formation, confirmation, age and completion are separate

The code treats forming and confirmed patterns differently. It also rejects some ancient or subsequently broken patterns as the current headline. Divergence annotations can remain in the record after becoming too old or too extended to dominate the current drawing.

A good manual chart read should do the same: retain the historical event, but say whether it is still actionable context. “A breakout occurred two months ago” and “price is triggering now” are not interchangeable. Likewise, a pattern can explain an existing trend without offering an attractive new entry.

## 6. Divergence deserves an explicit comparison

The implementation compares successive confirmed highs or lows and also retains a major-pivot comparison. It separates regular and hidden bullish/bearish divergence, calculates the oscillator difference, and records both dated price pivots. RSI and MACD are evaluated using their own numerical scales.

It then searches for confirmation through price structure, an oscillator failure-swing interpretation or an oscillator trendline break, with a finite attribution window. Location near tested levels affects prominence. The full ledger is retained, while only the salient subset is drawn.

**Practical translation:** draw the exact two price pivots and corresponding indicator values. Say whether the claim concerns fading momentum against the current price move or a reset within a continuing price structure. Identify what has happened since the second pivot. Several price-derived indicators agreeing should be described as related observations, not automatically independent evidence.

## 7. Shelves, not arbitrary line counts

Pivot prices are grouped into zones and separated tests are counted as episodes. The zone chooser gives preference to structural shelves, adds averages, retracement measurements and round numbers, and ranks proximity. This captures an important trading distinction: the most heavily annotated distant area is not necessarily the next useful location.

The exact implementation permits fallback groups when a structurally anchored group is absent. Therefore its output name should not replace inspection of the actual basis list. “Three references near 50” is a description; whether those references add independent information is a further judgment.

The Fibonacci helper selects a largest-distance confirmed-pivot pair and emits its dates, endpoints, direction and 38.2%, 50%, 61.8% measurements. The transferable lesson is **name the swing before naming the ratio**. The selected swing is this engine's convention, not a requirement that every reader must choose the same anchors.

## 8. Volume and Wyckoff as sequences

The volume module describes recent versus prior average participation, contraction between halves of the pattern and expansion events. The Wyckoff-style scan looks for a wide, high-volume decline, recovery, automatic rally and a lower-volume test. Spring candidates are separated from tested springs; sign-of-strength and later support behavior precede stronger markup language.

Use this as a sequence-reading exercise. For each stage, identify the bar and measured relationship that makes the label plausible. Then ask what the next stage would look like. Do not infer the identity of traders from the bar geometry; the learning target is the observable sequence and response.

## 9. Know which parts are measurements and which are design choices

The source contains historical pattern tables, a small desk calibration claim, tier labels and a rule that scales a measured objective by a historical target-hit fraction. Those are retained research/design choices, not newly verified forecasts. In particular, multiplying height by a hit fraction is not by itself a derivation of expected price. This does not diminish the usefulness of learning measured moves; it means describing the chosen projection honestly as a planning convention.

Other useful distinctions from the source: “three touches” is the program's line-validation label, not proof that future support will hold; its RSI regime classification comes from its own average-based rule; its average names and seeds matter; its historical integrity gate uses later bars relative to an earlier discontinuity, so an as-of replay must pass only the information available at that replay edge.

These implementation details make the study more useful. The point is not to invalidate chart reading, but to learn exactly what an existing tool is saying and how to combine it with informed visual judgment.

## 10. An original exercise using this engine as a tutor

Choose a historical chart and hide its later segment. Write a visual read containing trend, key swings, candidate pattern, most important zone, momentum comparison and next observable trigger. Separately calculate the engine's numerical facts from the same truncated history. Compare disagreements in four categories: different definitions; different window/scale; a missed observation; or an unsupported inference. Reveal later bars and update both records without rewriting the original.

Keep the most educational disagreements as reusable cases. The aim is a reader who understands the chart and the tool, rather than a reader who merely repeats an engine's label.
