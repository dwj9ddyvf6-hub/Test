# Visual chart reading: a practical training laboratory

Prepared October 30, 2026. This module teaches the visual craft: seeing the market's structure, translating what is seen into explicit hypotheses, and recognizing what additional behavior would justify action. It is not a test designed to reject technical analysis. Its standard is useful, repeatable chart interpretation rather than memorizing pattern names.

## 1. Learn to see in layers

A chart reader should be able to describe the picture before naming a trade. The following sequence is an original training protocol, not a claim that one published teacher mandates these exact steps.

**Pass 1: identify the canvas.** Read the symbol, exchange/feed, timeframe, price scale, visible date range, last completed bar, session definition, adjustment settings and volume units. Do not begin with the brightest arrow or indicator. A useful screenshot includes the axes and instrument identity. A cropped image with neither dates nor scale cannot establish exact levels or timing.

**Pass 2: see the large structure.** Temporarily ignore indicators. Locate the left-to-right progression of major highs and lows. Ask whether price is trending, balancing, accelerating, decelerating or transitioning. Mark the largest recent directional leg and the current position within it. A rally at the lower edge of a year-long range and a rally above all visible highs can look identical when tightly cropped but present different problems.

**Pass 3: locate the market.** Identify nearby prior swing zones, range edges, large gaps, breakout shelves and event-origin levels. Describe the distance from price to each in price units and normal volatility units. The nearest obstacle often matters more to a new entry than a distant attractive target.

**Pass 4: inspect the approach.** How did price arrive? Compare the speed, overlap, range and participation of the approach with the previous move away. A fast decline into support and a slow low-volume drift into it need different confirmation. The location tells you where to pay attention; the approach tells you what question to ask.

**Pass 5: inspect the response.** Read bodies, wicks, closes, failed excursions and the next completed bars. Separate a temporary touch from continued trade above/below the level. Record observations such as “three closes above the former range ceiling” rather than attributing unobservable intent to institutions.

**Pass 6: add selected measurements.** Use averages for trend context, momentum for character, and volume tools for participation/location. Each tool should answer a specific question not already answered by another panel.

**Pass 7: connect timeframes.** Begin with the weekly background, use the daily for structural location, the hourly for timing, and the 10-minute for refinement. These roles fit the established workflow; they do not make every timeframe an equal vote. A 10-minute reversal can be an hourly bounce inside a daily downtrend.

**Pass 8: write the decision boundary.** State the working interpretation, the strongest competing interpretation, the next confirming behavior, the behavior that invalidates it, and whether price now offers room relative to the required risk. This is the conversion from chart appreciation into trading judgment.

## 2. Geometry is information, but the display can change geometry

CME explains that candlesticks and OHLC bars encode open, high, low and close; line charts suppress much of that intraperiod range information. Candle bodies and wicks make that range readable, while timeframe selection changes what each bar summarizes. The training implication is to use a closing-price line when visual clutter hides structure, then return to candles to inspect the particular decision zone. Neither display adds data missing from the feed. [CME chart types](https://www.cmegroup.com/education/courses/technical-analysis/chart-types-candlestick-line-bar)

Linear axes allocate equal vertical distance to equal absolute price changes. Log axes allocate equal distance to equal proportional changes. This can alter trendline geometry over a large price range. Session, timezone and corporate-action settings are also configurable and should accompany a chart record. [TradingView chart configuration](https://www.tradingview.com/support/solutions/43000748166-how-to-configure-your-supercharts/)

![Identical synthetic growth on linear and logarithmic axes](visuals/02_scale_geometry.png)

**Worked visual case: apparent acceleration.** Both panels contain exactly the synthetic series 10 × 1.06^t, for bars 0–30. On the linear panel the slope steepens; on the logarithmic panel it is straight. Observation: each bar increases by 6%. Inference: the growth rate is constant in percentage terms, despite increasing dollar increments. Competing explanation: a reader looking only at the left panel might label it accelerating momentum. Decision criterion: specify whether acceleration means dollar change, percentage change or a volatility-adjusted change before assigning the label. A line drawn on the linear panel is not transferable unchanged to the log panel.

Dividend-adjusted charts incorporate distributions and differ from unadjusted quoted-price histories. Record the choice when comparing old levels or screenshots from different platforms. [TradingView dividend adjustments](https://www.tradingview.com/support/solutions/43000590597-how-to-adjust-data-for-dividends/)

**Practical comparison drill:** open two screenshots said to show the same stock. Before judging which analysis is better, reconcile symbol, exchange, timezone, regular/extended hours, bar interval, endpoint, split/dividend treatment and scale. If their bars are different, resolve the data/display question first. Do not invent a technical explanation for a settings mismatch.

## 3. Read candle anatomy precisely

For an ordinary OHLC candle define range R = H − L; body B = |C − O|; upper wick U = H − max(O,C); lower wick D = min(O,C) − L; close-location fraction CL = (C − L)/R when R > 0. These are transparent descriptive measurements, not automatic trading signals. R = 0 needs explicit handling rather than division. Compare the current bar with its recent neighbors, not with the entire screen's changing vertical zoom.

![Synthetic candle geometry exercise](visuals/04_candle_measurement.png)

**Exercise and answer key:**

- A: range 6, body 4, upper wick 1, lower wick 1, close location 5/6. The close is near the upper end and the net advance is substantial relative to the range.
- B: range 6, body 0.5, upper wick 4.5, lower wick 1, close location 1.5/6. It is green but closes in the lower quarter. Green does not mean the whole bar was strong.
- C: range 6, body 4, upper wick 1, lower wick 1, close location 1/6. The net decline is substantial and the close is near the low.
- D: range 6, body 0.5, upper wick 0.5, lower wick 5, close location 5.5/6. It ends well above the low. The chart alone does not reveal the exact intrabar sequence, who traded, or whether the next bar will confirm a reversal.

**The important distinction:** a small body says little net movement between open and close. It does not mean nothing happened. B and D both have small green bodies, but their excursions and closing positions differ. Read the whole candle.

**Context before vocabulary.** A lower wick near an established floor invites a question about rejection of lower prices. A similar wick in the middle of a wide balance may be ordinary two-way activity. A long positive body breaking a multiweek shelf is different from the same body arriving at a nearby weekly ceiling after an already extended advance. Naming a hammer or engulfing candle is the start of description, not the end of analysis.

![Synthetic candle context comparisons](visuals/03_candle_context.png)

**Plate 3 reading:** A depicts a declining sequence, a probe beneath the shaded floor and a subsequent advance. B depicts an advancing sequence, an excursion above the shaded ceiling and subsequent decline. C depicts overlapping two-way activity without an obvious boundary test. D depicts persistent lower closes. The shaded zones in A and B are *assumed prior context for this teaching example*, not levels discovered from older bars shown in this crop. The curves are synthetic and deliberately simplified. When practicing, cover the final bar: the inference at the rejection bar is only “candidate rejection,” not the later confirmation you can now see.

## 4. Breakout reading is a sequence, not a single candle

The original synthetic plate below creates two paths with identical OHLC and volume history through bar 19. Neither path can be identified in advance from the shared prefix. It teaches the value of updating the interpretation as new behavior arrives.

![Synthetic breakout acceptance versus failure](visuals/01_breakout_branches.png)

**At bar 17:** price has approached the shaded 99.7–100.3 zone repeatedly. There is a visible boundary and compressed trading underneath it. Working interpretation: a potential upside resolution. Competing interpretation: continued range trading. Criterion: meaningful completed trade above the zone rather than another small excursion inside it.

**At bar 18:** the close is 102 with increased synthetic volume. Observation: the close is outside the prior ceiling. Inference: an upside break has occurred in this constructed example. Competing interpretation: a temporary extension that could return to the range. Criterion: continuation or subsequent ability to retain/reclaim the shelf. The bar is already farther from the floor than the pre-break price, so a breakout can improve confirmation while worsening entry distance. Those are separate facts.

**At bar 19:** the close is 102.6. Both scenarios remain identical. A statement that the breakout will succeed is not available from the image. One can now plan an allowed entry model, wait for a retest, or pass if distance to invalidation exceeds the chosen budget. The plate is a reading exercise, not a recommendation for any of those choices.

**Path A, bars 20–22:** price pulls back toward the shelf while synthetic volume diminishes. Bar 22 closes 100.4. Observation: closes remain above the upper boundary, while lows approach it. Inference: a retest is developing. Competing interpretation: the first stage of a deeper failure. Criterion: a new upward response without sustained loss of the shelf. Bars 23–25 illustrate that response, but they were not knowable at bar 22.

**Path B, bars 20–22:** price returns into the zone and then closes below it, with increasing synthetic volume. Observation: the breakout shelf has been lost. Inference: the original immediate-continuation thesis has deteriorated. Competing interpretation: a shakeout followed by reclaim. Criterion: require the reclaim actually to occur; do not silently rename every failed breakout a shakeout. Bars 23–25 illustrate further decline, not a universal outcome of all failures.

**A useful distinction:** rejection describes an excursion and return; acceptance describes persistence and continued trading in the new area. Operational definitions can use completed closes, elapsed time, retests and range overlap. Choose the definition in advance for the timeframe being studied. “It held” should be traceable to observed behavior, not merely a favorable final screenshot.

## 5. Make indicators answer different questions

### EMA: orientation and distance

EMA weights recent observations more heavily than older ones. Fidelity describes trend direction and pullbacks toward a rising EMA as common uses, while stressing that the average responds with delay rather than identifying exact turning points. [Fidelity EMA guide](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/ema)

Original reading drill: first describe the swings without averages. Add the 21- and 50-period averages used in the existing workflow. Record (1) slope, (2) ordering, (3) price location, (4) separation, and (5) how price behaved during earlier approaches. Ask whether the average is summarizing an orderly trend or cutting through repeated overlap. “Price above the EMA” and “the EMA rising” are different observations. A reclaim from underneath differs from a first pullback after a strong advance. Do not change periods until one hugs the current price; keep the chosen lens consistent across examples.

### RSI: momentum character, not a blanket sell label

RSI uses smoothed gains and losses and is typically shown on a 0–100 scale. StockCharts documents both conventional 70/30 reference levels and the possibility of sustained extremes during strong trends; it also discusses bull/bear range behavior. Parameter length and initialization affect the reading. [StockCharts RSI](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/relative-strength-index-rsi)

Original reading drill: compare three successive price pushes and pullbacks with their RSI excursions. Identify whether RSI is recovering quickly, failing repeatedly near a similar region, or establishing a different range. Annotate the price swing dates used in any divergence. A divergence is a comparison of specified swings, not a vague downward line across convenient peaks. Use the price structure to define what would turn the warning into an actionable change. RSI and relative performance against an index are different measurements.

### MACD histogram: read level and change separately

The usual MACD is EMA12 minus EMA26; its signal is an EMA9 of MACD; the histogram is MACD minus that signal. A histogram approaching zero from below can still be negative, indicating convergence rather than an already positive relationship. [StockCharts MACD histogram](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/macd-histogram)

Original reading drill: write two clauses, “histogram negative” and “histogram rising.” Then ask whether price has stopped making lower lows or merely slowed its decline. Similarly, a shrinking positive histogram can accompany continued rising prices. Track the difference between weakening momentum and a completed trend reversal. Do not treat EMA, MACD and a price-momentum oscillator as three wholly independent observations when all derive from the same prices.

### Fibonacci: a map of the selected swing

Common retracement references include 38.2% and 61.8%; the frequently included 50% midpoint is not a Fibonacci ratio. StockCharts presents these as zones to examine alongside price behavior, not guaranteed reversal prices. [StockCharts Fibonacci retracements](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-annotation-tools/fibonacci-retracements)

Original measurement drill: for an upswing L=80 to H=100, the downward retracement price is H − r(H−L). Thus 38.2%=92.36, 50%=90 and 61.8%=87.64. Record both anchor dates and whether extremes or closing prices define the swing. Identify which swing matters to the trade horizon before drawing the tool. If a daily swing and an hourly swing produce different zones, label them separately. Confluence is useful only when the underlying references have a reason to matter; redrawing anchors until a ratio lands on today's turn is not disciplined reading.

### Anchored VWAP: an event-specific cost reference

Anchored VWAP begins the price-volume accumulation at a selected bar rather than restarting with every session. Event anchors can include a major gap, high, low or earnings event. [StockCharts anchored VWAP](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-overlays/anchored-vwap)

Original reading drill: predeclare the anchor's rationale. Read price above/below the line, the line's slope, repeated interactions and the space to nearby structural zones. A high anchored line and a low anchored line describe different windows, not two independent votes. Specify whether the implementation uses actual transaction prices or bar-based typical-price approximations. The line does not establish the exact inventory or cost basis of all current holders. A reclaim is a price event to inspect; the instrument can cross the average many times in balance.

### Volume profile: where activity accumulated

StockCharts Volume-by-Price bins closing-price observations over the displayed period; its up/down colors are based on up/down periods, not direct buyer/seller identities. Its current profile must not be applied to earlier decisions using later observations. Other platforms' volume-profile algorithms can differ. [StockCharts Volume-by-Price](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-overlays/volume-by-price)

Original reading drill: freeze the lookback window and binning. Mark high-activity areas and lower-activity corridors, then inspect actual behavior when price reaches them. A large node can act as an area of balance rather than a precise reversal line. If the visible-range profile changes as you zoom, the underlying question has changed. Save the window with your screenshot. Never mistake a red/green profile for proof of dealer positioning, net accumulation or aggressive order flow unless the feed and classification actually measure those things.

## 6. Multi-timeframe integration without a voting machine

Build a four-row worksheet:

- **Weekly background:** major trend/range, location within it, nearest substantial opposing zone, last completed week.
- **Daily structure:** active swing, pullback or base, important shelf, distance to invalidation, next obstacle.
- **Hourly timing:** sequence of lower highs/higher lows, reclaim or failure, quality of retest, current session context.
- **10-minute refinement:** trigger formation and execution geometry; do not allow a tiny pattern to erase the daily map.

Example of original reasoning: weekly uptrend; daily pullback approaching a prior breakout shelf; hourly still lower highs; 10-minute bullish reversal. Interpretation: favorable higher-level location but timing has not yet resolved. A candidate may improve if the hourly lower high is reclaimed and retained. A bullish 10-minute candle alone does not complete that event. Conversely, an hourly breakdown through daily support changes the thesis even if the weekly uptrend has not yet reversed. This is alignment by role, not “three green panels beat one red panel.”

Label every observation with its timeframe. A stop based on a 10-minute wick and a thesis based on a weekly trend are not automatically compatible. The duration and normal noise of the chosen setup must fit the invalidation method. If a live weekly candle is incomplete, distinguish its present shape from a confirmed weekly close.

## 7. Deliberate visual practice and assessment

The following is a proposed curriculum, not a record of completed training or an already enabled schedule.

1. **Blind description:** hide ticker and future bars. Write ten observations with no bullish/bearish labels. Score factual accuracy against the data.
2. **Boundary marking:** mark only three zones. State which visible reactions justify each. Compare with another pass made without seeing the first annotations.
3. **Candle contrast:** compare small green bodies with opposite wick orientation; compare identical shapes at a boundary and in the middle of balance.
4. **Branch exercise:** use Plate 1 through bar 19. Write both continuation and failure criteria before uncovering bars 20–25.
5. **Indicator subtraction:** read price and volume first, then reveal one indicator at a time. Record precisely what changed and why.
6. **Scale challenge:** use Plate 2 and explain what is invariant and what is display-dependent. Repeat on long-lived securities with large price changes.
7. **Timeframe reconciliation:** produce the four-row worksheet without calling every local turn a reversal of the dominant trend.
8. **Replay decision journal:** save an as-of screenshot and scenario statement, advance one completed bar, then update. Keep the original annotation rather than overwriting it after the outcome.
9. **Failure library:** collect misread bases, failed breakouts, successful reclaims and ordinary noise. The purpose is to improve discrimination and timing, not to declare the entire craft invalid.
10. **Transfer drill:** apply the same description method to a different symbol/regime. Decide which principles transfer and which parameter choices need adaptation.

Score five dimensions separately, 0–2 each: data/display identification; accurate structural description; sensible level selection; explicit competing scenario and decision boundary; timeframe/risk coherence. A 10/10 describes analysis process quality, not a predicted win rate. Record outcome separately so a fortunate guess does not receive the same skill credit as a well-specified analysis.

## 8. A reusable visual inspection record

For each actual chart inspected, preserve: image identity and timestamp; symbol/feed; as-of cutoff; timeframe/session; scale and adjustments; visible range; completed-bar status; major swings with confirmation dates; significant zones and their evidence; present price location; approach/response behavior; selected indicator readings; higher/lower timeframe context; main interpretation; alternative; confirming event; invalidating event; next review point; and what cannot be read reliably from the image.

Use explicit language: **observed**, **inferred**, **conditional**. For example: observed two closes above 100; inferred improving acceptance; conditional continuation if the retest retains the shelf. Do not turn conditional phrasing into evasiveness: the goal is a clear decision with precise reasons and update rules.

## Visual provenance and completion record

Four original synthetic PNG plates were generated by `visuals/build_visual_cases.py` and actually viewed during quality review. They are teaching constructions, not historical securities, backtests or empirical evidence of strategy performance. Their bar numbers are not dates. Random wick/volume construction uses a fixed seed; the two breakout paths share the same prefix. The candle-context figure was revised to describe its declining panel accurately.

CME's source text was read. Its linked real-chart image failed to fetch through the web tool with an internal error. No claim is made to have visually inspected that image, any market chart on the cited pages, or a video. Sources establish technical definitions and platform behavior; the scenarios, exercises and inspection sequence are original instructional synthesis. No actual trading or live recommendation is made in this module.
