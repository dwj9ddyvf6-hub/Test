# Measurement and drawing: five additional recovered tools

Five complete source files were read statically, byte-verified and not executed. Exact pinned links and identities are in `parent_read_batch/next_full_reads_ledger.json`.

## Ichimoku: plotted location versus available information

Midna's `quant-research/indicators/ichimoku.py` explicitly stores computed, displayed and available indices for every point. It puts leading spans ahead and Chikou behind while retaining the actual computation index. This is a useful teaching companion: ask which values could have been known at the replay cutoff, not just where a line appears on the completed chart. Its `known_at` function selects by availability rather than visual coordinate.

## Volume profile: the input determines the meaning

The archived Quant Charts `volume_profile.py` offers two different constructions. With high/low/volume bars it distributes each bar's volume uniformly across covered bins; with price/size arrays it bins the supplied observations at their prices. POC and value-area outputs follow the selected construction and window. The latter input can represent trade prints, but supplying bar closes does not turn them into prints. This distinction helps explain why two visually similar profiles need not give identical levels.

The practical habit is to record window, bin size, data granularity and allocation convention before comparing POC/VAH/VAL. The code's nodes are thresholded local histogram peaks/troughs. They should be read as that algorithm's outputs, not proof of hidden orders.

## VWAP: a line and its bands may have different aggregation assumptions

The archived Quant Charts example obtains a VWAP series from a helper and computes a cumulative volume-weighted squared deviation from it. The helper body was not part of these five reads, so its fallback/session behavior is documented but not independently traced here. The shown band calculation itself uses cumulative arrays over the supplied frame. For chart interpretation, preserve the session or event anchor and the precise band definition; “two sigma” is not enough to reproduce a drawing.

## A concrete VWAP pullback is a house recipe

The Test repository's Griffith recipe combines a short-term average relationship, proximity to VWAP, RSI, market context and a scan score, with fixed numerical stop/target assumptions. The document labels the historical sleeve live; this study did not verify current operation. Its educational contribution is how a broad idea becomes a specific recipe. The exact fractions, universe and sizing are that recipe's parameters, not the definition of every VWAP pullback.

## Elliott chart communication

The September 6 archived charting playbook organizes candle identity, major structure, a preferred count, a subordinate alternate, explicit retracement/extension anchors, relevant averages and decision labels. Its useful rendering lesson is to make the scenario legible without using color as the only carrier of meaning. A target percentage needs visible or recorded origins; the current state, trigger and invalidation should agree between chart and text.

Later, larger analyst-observation archives qualify some of this early style prescription. Do not require every practitioner to draw one connected forecast path or always show the same momentum pane. Preserve the underlying information relationships rather than impose a template that hides the analyst's actual method.
