# Visual chart reading and Tensor: recovered tools, methods, and lessons

Read-only study, October 30, 2026. Repository pins: Agentic-Trading-Desk `4c8c179c5988d6e603c1f3c5f28f93e2344ca225`; ClaudeDesk `85b3bb0ca88c6f5a8a2529825a770bc29992743e`.

## Most useful finding

The user's repository already contains a serious **learn-to-see curriculum**, not merely indicator formulas. Its best combination is:

1. A winner-phenotype doctrine that begins with rich observation, not an attempt to disprove chart analysis.
2. A full-chart atlas with chart-specific structure, energy, participation, signal sequence, entry, invalidation, and management records.
3. A blinded multi-timeframe visual protocol that forces actual observation before synthesis.
4. A code-versus-eyes protocol to find what numerical detectors miss.
5. A model-book protocol and matched-signal twins to convert visual intuition into precise, reusable distinctions.
6. A masked-snapshot Winner Genome pipeline to study what becomes recognizable before acceleration.

These should be integrated rather than replaced with a generic technical-analysis glossary.

## Verified scope of this pass

- Enumerated the complete current default-branch file trees of these two repositories, splitting the large archive into its 132 batch subtrees. All successful final tree responses report `truncated=false`.
- Indexed **30,692 file paths**: 30,607 in Agentic-Trading-Desk and 85 in ClaudeDesk; 14,330 PNG paths. This is a file count, not unique chart count: contact sheets, individual images, and possible copies coexist.
- Materialized 23 source/document files, with 19 read in full and four read through selected sections. Three actual PNGs were opened and visually inspected in this pass. Individual status is preserved in `path_inventory.csv/json`.
- The large original recursive archive call failed internally; splitting into nonrecursive root and all child trees resolved enumeration. No imported repository program was run.
- Not completed here: all 14,330 image inspections, all review-record readings, binary ZIP/GZIP contents, other branches, or every referenced external path. These are explicitly discovery-only, not absorbed/read.

### What the archive itself reports

`research_archive/tensor_full_chart_atlas_completion.json` reports 12,950 chart-specific retrospective reviews across 132 batches: 6,516 daily Cyan, 4,937 daily Green, 896 weekly Cyan and 601 weekly Green. Its five lanes comprise 3,805 clean-retained winners, 4,294 partial-retention winners, 627 adversity winners, 622 weak-capture events and 3,602 full-reversal contrasts. It records exact identity reconciliation and a final review hash.

This is a retrieved historical completion claim, not an independent rerun of the ledger or a claim that this assistant visually inspected those 12,950 charts today. The associated progress document calls it an indexed first pass, not exhaustive cognitive mastery. An earlier correction explicitly withdrew a mistaken full-chart-inspection claim based on simple morphology plots; the later full-chart corpus is the corrective work. Retain this distinction when explaining what has already been built.

## 1. The governing learning posture

[Winner-Phenotype Doctrine](https://github.com/dwj9ddyvf6-hub/Agentic-Trading-Desk/blob/4c8c179c5988d6e603c1f3c5f28f93e2344ca225/docs/TENSOR_WINNER_PHENOTYPE_RESEARCH_DOCTRINE_2026-08-28.md) gives the best concise principle: **Observe first, name second, quantify third, encode fourth, test last.**

The meaningful unit is the entire constellation, not one marker. Ask:

- What was forming before price accelerated?
- Where was price relative to the base, old supply, ribbons, anchors, and the larger trend?
- Which marks appeared first, which reinforced them, which disappeared, and which conflicted?
- Did price accept the new area through closes and retests, or merely touch it?
- Was the breakout immediate, delayed, or conditional on a later shelf?
- How did the move pause, resume, exhaust, and possibly repair for re-entry?

The doctrine intentionally begins with exceptional winners as a positive discovery class. That is a useful way to learn anatomy. Subsequent blind examples tell us whether the recognition transfers. Neither stage needs to become a philosophical referendum on technical analysis.

### Study the relationships, not a shopping list

The doctrine specifically calls for bar separation and ATR-normalized distances among markers, ribbon, cloud, pivots and price; marker density and conflict; ribbon slope, curvature and compression; volume contraction/expansion; and weekly/daily handoffs. These are relational features a checklist of isolated bullish indicators often misses.

A practical reading sentence therefore looks like: “The weekly range has stopped making lower lows; daily price is reclaiming the slow ribbon; two tests of the same floor have held; the latest pullback is shorter and quieter; the bullish marker sequence is improving while sell marks thin out; the nearest overhead shelf remains the decision point.” This is richer than “five indicators bullish.”

## 2. Recovered visual-reading protocols

### ClaudeDesk/eyes/PROTOCOL_V3.md: the full examination

[Protocol V3](https://github.com/dwj9ddyvf6-hub/ClaudeDesk/blob/85b3bb0ca88c6f5a8a2529825a770bc29992743e/eyes/PROTOCOL_V3.md) uses four plates:

- TW: weekly Tensor, 160-bar window; last week may be partial and must be read as unfinished.
- TD: daily Tensor, 160 bars.
- TH: hourly Tensor, where available, with session boundaries.
- LV: monthly map plus a 252-session daily chart with traditional levels and indicators.

First inspect every visible panel. Then write observations. Only after that synthesize two to five material relationships and a trade thesis. Fields cover trend quality, swing sequence, stage, location, moving-average arrangement, pattern status, breakout hold/stretch, divergences, candle location, gaps, volume, bands, support/resistance, level stacking, VWAPs, volume-profile value, relative strength and market regime. It explicitly allows “none,” borderline confidence, and a novel-observation field.

This separates three abilities that should be practiced independently:

1. **Perception:** Is the line rising? Is the candle closing above the level? Is the visible mark really present?
2. **Interpretation:** Is this a pullback within an advance or a bounce within a decline?
3. **Decision:** What level would make an entry attractive, what would prove the read wrong, and where is the next obstacle?

The first protocol also requires a specific answer to what a numerical detector would miss. V3 expands that into spatial context and unusual relationships.

### Code-versus-eyes audit

[PROTOCOL_A](https://github.com/dwj9ddyvf6-hub/ClaudeDesk/blob/85b3bb0ca88c6f5a8a2529825a770bc29992743e/eyes/PROTOCOL_A.md) draws a code-generated zone, trigger, stop and targets on the chart. The visual reader judges every numbered assertion as right, partly right, wrong, or impossible to determine from the image. It then judges entry timing, stop placement, targets and the most consequential missed feature.

This is a particularly useful learning exercise for the existing engines: do not ask whether “the algorithm works” in the abstract. Ask whether its proposed stop is beneath the structural shelf or randomly inside it, whether its target collides with obvious supply, and whether its bullish pattern is already extended.

### Model book

[PROTOCOL_MB](https://github.com/dwj9ddyvf6-hub/ClaudeDesk/blob/85b3bb0ca88c6f5a8a2529825a770bc29992743e/eyes/PROTOCOL_MB.md) compares 10 strong winners and 10 strong losers per batch, with outcomes known for discovery. For every chart it records visible traits, regime and the most specific feature. The synthesis must define testable distinctions rather than “looks good.” Its example grammar combines a distance to a high, a recent range width and volume relative to a baseline.

This is a discovery exercise, not blind forecasting. It can teach what to look for before a second, unseen set is used to test recognition.

### Matched signal twins

[PROTOCOL_TWINS](https://github.com/dwj9ddyvf6-hub/ClaudeDesk/blob/85b3bb0ca88c6f5a8a2529825a770bc29992743e/eyes/PROTOCOL_TWINS.md) pairs two charts with the same Tensor signal and similar liquidity, regime, date and volatility. First choose which has better prospects using only the charts. Then reveal outcomes and write the conditions that separated them.

This is ideal deliberate practice for context. It teaches why identical signals can mean different things without dismissing the signals: different location, overhead supply, phase, cross-timeframe alignment, participation or extension.

## 3. Practical setup families recovered from the actual reviews

The sampled full-chart review files repeatedly distinguish five useful families:

### Ordered continuation with retained shelf

Price is already above rising, separated averages. Pullbacks are controlled and preserve a higher platform. Momentum can cool without price losing the shelf. Entry grammar is a new shelf clearance or measured retest; protection belongs below the platform. A second Green/Cyan in the same campaign is reinforcement, not automatically a new independent trade.

### Long-ribbon repair into retained structure

Price emerges from damage, first regains intermediate structure and then accepts the long ribbon. The early marker can be permission to watch, while the later held reclaim or higher shelf supplies the entry. Learn to distinguish a transient touch of resistance from several closes and a successful retest above it.

### Discontinuous repricing with post-gap shelf

The gap or vertical bar carries information, but frequently leaves no sensible initial risk location. The first quiet, liquid two-sided shelf after repricing offers a more usable trigger and invalidation point. Subsequent continuation and failure are read against that shelf, not against the original signal alone.

### Range compression with conditional permission

A signal appears within a base but the upper boundary remains intact. The useful work is mapping tightening, higher lows, declining pullback volume and overhead supply. Price must actually escape and hold. A compressed base is a condition of readiness, not proof of direction.

### Pre-repair permission without visible completion

Buy marks appear while the slow structure still slopes down and price remains below it. The chart can be interesting without being ready. The next observable requirement is a stable floor, reclaim and accepted higher platform. This interpretation preserves the signal as an early clue without forcing a premature entry.

## 4. Reusable quantitative companions to visual judgment

The [Winner Genome feature registry](https://github.com/dwj9ddyvf6-hub/Agentic-Trading-Desk/blob/4c8c179c5988d6e603c1f3c5f28f93e2344ca225/tensor_winner_genome_feature_registry.json) provides 28 implemented fields plus four unavailable source families. Useful visual-to-numeric bridges include:

- Price-to-EMA21/50/200 distance and EMA200 slope.
- Bollinger width and compression age.
- Up-volume share and prior-volume-relative RVOL.
- Kaufman path efficiency: net movement divided by total traveled path.
- Return-sign entropy: alternation versus directional persistence.
- Distance from VWAP anchored at the trailing low/high.
- Approximate overhead volume burden and coarse volume-profile point of control.
- Number of resistance tests, a close beyond the prior 20-bar high, and gap acceptance.
- Tensor conflict burden and ordered marker appearances over the trailing 12 bars.

The [pipeline](https://github.com/dwj9ddyvf6-hub/Agentic-Trading-Desk/blob/4c8c179c5988d6e603c1f3c5f28f93e2344ca225/tensor_winner_genome.py) samples a sequence at -12, -8, -4, -1, event-close and +1 bars, masking later bars at each snapshot. This is a strong teaching device: instead of studying only a finished winner, ask when its structure became legible and when it became actionable.

Implementation details matter when these tools are reused. The registry calls RSI “Wilder-style,” but the read implementation averages a short recent-return slice without Wilder recursion; the separate weekly feature file uses simple rolling averages. Its volume profile assigns bar volume to typical-price bins, not actual tick-by-price volume. These are useful proxies, but their labels must not be mistaken for exact canonical indicators. This observation calls for precise teaching and later verification, not dismissal of the craft.

## 5. What was actually seen in three repository images

These are fresh pixel inspections in this pass, not rephrased historical review claims. They are illustrative historical artifacts, not current trade recommendations.

### AMD daily Tensor plate (ClaudeDesk/eyes/canon/amd_TD.png)

The plate hides dates and rebases the last close to 100. The earlier half contains repeated advances that lose momentum and return to a broad floor. Roughly 40 bars from the right edge, price starts to leave that floor; short averages turn up, then fan out, while the candles establish a sequence of higher shelves. In the final third, OBV broadly rises and the momentum panes remain positive despite resets. The right edge is well above the long average and above the earlier range.

Teaching point: the recognizable change is the transition from overlapping range structure to persistent acceptance above rising averages. The final bullish trend is obvious, but its extension means “bullish” and “good new entry here” are different questions. Exact marker ages and small glyph identities should not be guessed from this resolution.

### SQM daily golden chart, event November 1, 2021

Before the marked event, price has repaired from the low-$40s into a broad mid/high-$40s shelf. The event is followed by an abrupt expansion into the upper-$50s, expanding bands and positive squeeze momentum. Later, momentum rolls over, price loses the short ribbon and then the accepted shelf; the lower pane turns negative and the right edge returns near the prior base.

Teaching point: one chart can contain a useful breakout phase and a later failed retention phase. Learn entry, holding and exit as separate reading problems. The complete future path is visible here; it is suitable for anatomy, not a blind forecast test.

### MELI weekly golden chart, event August 28, 2023

A lower basing area is followed by a reclaim and then a broad multi-month shelf above the earlier lows. The marked event occurs during that repaired upper structure. The later advance develops after another pause, with a widening bullish ribbon, higher shelves and positive momentum. The right edge shows a pullback from a higher zone rather than a return to the original floor.

Teaching point: weekly permission can precede the cleanest daily/weekly ignition by a meaningful delay. Do not require every useful signal to be the exact breakout bar; observe whether the repaired platform continues to hold while momentum renews.

## 6. How to build the next practical lesson from this material

1. Choose a coherent family, such as long-ribbon repair, rather than mixing every chart type.
2. Inspect a full-resolution example at six masked cutoffs. Record what can be seen at each cutoff.
3. Mark the structural floor, first reclaim, accepted shelf, trigger and nearest resistance.
4. Describe the phase in ordinary language before naming the pattern.
5. Write two to five material relationships, not twenty redundant indicator votes.
6. Compare the same signal in a second chart whose structure differs.
7. Reveal the next segment; classify what changed in structure, participation and momentum.
8. Preserve the original observation, then add the lesson. Do not rewrite the original read to fit the outcome.
9. Return to the full-resolution chart when a contact sheet hides wick detail, glyph identity or a level.

This is a teachable progression from seeing, to explaining, to anticipating, to managing.

## 7. Files worth reusing first

| Tool / artifact | Exact repository path | Best role |
|---|---|---|
| Full visual protocol | ClaudeDesk/eyes/PROTOCOL_V3.md | Comprehensive multi-timeframe examination |
| Numerical-reader audit | ClaudeDesk/eyes/PROTOCOL_A.md | Find context and level-placement mistakes |
| Model-book protocol | ClaudeDesk/eyes/PROTOCOL_MB.md | Discover exceptional-move anatomy |
| Twins protocol | ClaudeDesk/eyes/PROTOCOL_TWINS.md | Learn discriminating context around identical signals |
| Winner doctrine | Agentic-Trading-Desk/docs/TENSOR_WINNER_PHENOTYPE_RESEARCH_DOCTRINE_2026-08-28.md | Observation-first learning framework |
| Full-chart renderer | Agentic-Trading-Desk/tensor_full_chart_export.mjs | Preserve canonical visual layers and provenance |
| Contact sheet | Agentic-Trading-Desk/tensor_full_chart_contact_sheet.mjs | Triage and comparison, not detail replacement |
| Chart-specific reviews | Agentic-Trading-Desk/tensor_full_chart_batch_*_reviews.py and research_archive/tensor_full_chart_batches/ | Worked readings with lifecycle fields |
| Genome snapshots | Agentic-Trading-Desk/tensor_winner_genome.py | Study earliest recognizable structure |
| Feature vocabulary | Agentic-Trading-Desk/tensor_winner_genome_feature_registry.json | Convert visual concepts to measurable companions |
| Complete atlas receipt | Agentic-Trading-Desk/research_archive/tensor_full_chart_atlas_completion.json | Exact historical coverage claim |

### Practical rendering caveat

The exporter computes the full history before slicing, preserving indicator warmup, and stores tape/core/enrichment/renderer hashes. It explicitly records future bars visible. The contact-sheet utility resizes images to a fixed 480×325 cell with `fit: fill`; this can distort geometry and make small glyphs hard to read. Use the original PNG for judgments about angles, wick details, marker identity and level distance.

### Referenced but not present in this default-branch snapshot

ClaudeDesk's handoff refers to V3 answers, metadata, model-book batches, twin registries, and other pattern studies that are not in the 85-file default-tree snapshot. Their absence here is a location gap, not proof the work does not exist. The inventory coordinator should search the related Femto-lean research branches and archived copies. The handoff also documents adjustment mismatches across hourly/daily plates; matching chart price conventions is part of skilled chart reading.
