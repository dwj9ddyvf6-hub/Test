# ClaudeDesk archive branches: recovery and additional learning

## Coverage established

All 221 current branches were paginated (100 + 100 + 21) and their trees recursively enumerated on 2026-10-30. These are 220 archive partitions plus main, **not** 221 independent strategies. The oversized p097 recursive response was recovered by nine root subtrees. No final tree is truncated and no subtree error remains.

The inventory contains 105,064 branch/file occurrences, 103,543 distinct path/blob pairs, and 64,213 unique blob hashes. Of the occurrences, 21,240 are in eyes/. There are 13,754 image occurrences but only 12,784 unique image hashes. Counts do not mean the contents or images were all read. The default main is a duplicate of the initial partition. Full tree evidence and exact commit/path/blob tuples are in ClaudeDesk.branch_inventory.json/csv and claude_branches/.

This resolves the earlier report's location gap. The important additional surfaces are:

- p009 (20261020): eyes/meta definitions, codebook, V3 and twins registrations, samplers, renderers and scoring code.
- p011: eyes/v3answers/c01–c70.jsonl and metadata/results. Answer corpus located, not all absorbed.
- p003–p025: original/model-book/V3 chart plates, plus associated data.
- p053: patterns/lab/ta_shapes.md, tensor.md and implementation families.
- p147/p149/p151: eyes/DEEP/vfl/read.md, ta.md, pat.md, str.md, tsh.md: replay/feature dictionaries.
- p095: midna-corpus/best-setups research and progress documents.
- p180 (20261025): V5 exam results and later analytical tables.
- p207 (20261026): DEEP/FINDINGS2.md, FROZEN.md, NOTES.md, PROGRAM2.md and later outputs. Located, not read in this pass; do not attribute their findings to this synthesis.

## Newly read practical material

Full reads: CODEBOOK.md, REGISTERED_V3.md, REGISTERED_TWINS.md at commit `24a1256ea0181c0d1332169e6ab04e57f45da283`. Full sources saved locally. c01.jsonl at `34b8b951583c864b5dd7488c15e3e8357aa01b02` was fetched completely; the first record was read fully and all ten records' confluence/specific/novel/key/plan fields read. The remaining structured fields were not all individually studied. Three additional large dictionaries were materialized and introductory/definition sections studied, not claimed full-read.

### A richer vocabulary for what skilled eyes notice

The codebook turns free-form chart observations into 19 themes: failed breakouts, undercut/reclaim traps, level confluence, timeframe conflict, pullback quality, breakout quality, one-bar distortions, lagging averages, OBV leadership, fading momentum, long patterns, blow-off unwind, volatility shifts, extension, base-building, capitulation, data artifacts, Tensor agreement and Tensor disagreement. This is useful as a second-pass checklist **after** describing the chart in ordinary language, not a requirement to find every theme.

### Lessons from the ten V3 worked narratives

These are prior readers' interpretations, not independently re-inspected plates or verified forecasts in this pass.

1. **Separate intact trend from currently actionable entry.** w0001 describes a weekly staircase still intact but a daily failed breakout and fresh sells. The practical plan waits for an overhead cluster to be reclaimed; a bullish long-horizon picture is not sufficient by itself.
2. **Understand disagreement between volume gauges.** w0008's OBV rises while A/D falls at upper wicks: up-close days can coexist with closes low in each day's range. Compare the actual definitions before declaring the indicators contradictory.
3. **Ask whether a level is independent evidence.** w0002 describes one giant-volume day pinning several volume-weighted levels at the same overhead price. Several lines can be multiple expressions of one event, not several independent confirmations. Observe what happens when that day exits a rolling window.
4. **Distinguish absorption candidate from reversal confirmation.** w0003 has hourly OBV improvement at support while daily structure remains weak. Its narrative demands a daily reversal bar rather than treating bullish divergence as an automatic turn.
5. **Read the event sequence.** w0005 first undercuts a base floor, reclaims it, and then faces a converging moving-average/price cluster. The order and location explain more than a standalone spring label.
6. **Read the quality of the bounce.** w0007 rises into a dense overhead level cluster while hourly OBV falls. A rebound can still be supply-limited until it accepts above the ceiling.
7. **Distinguish fresh trend repair from late extension.** w0009 reclaims a cluster with rising relative strength and weekly higher-low structure, but approaches prior highs without a retest. Its plan studies a first pullback instead of assuming the previous reclaim remains an optimal current entry.
8. **Use levels to make scenarios conditional.** w0010 describes a double-top neckline coinciding with value-area low and VWAP: reversal at that area and acceptance below it imply different paths.
9. **Treat anchor changes as chart events.** w0011 shows calendar VWAP jumping at reset. The line's sudden movement is mechanical; it is not sudden new buying pressure.
10. **Mark unreadable and pathological data.** w0004 describes inconsistent-looking plate highs and opposing oscillator extremes. Understanding adjustments, volume concentration and chart scaling is part of learning to read accurately.

The transferable chart-reading process is: describe structure → locate current price → identify the meaningful event sequence → inspect participation → resolve higher/lower-timeframe agreement or conflict → state the required confirming behavior → identify what would contradict the reading. This is a method for learning TA, not an attempt to negate it.

## Useful exact operational definitions recovered

The ta_shapes dictionary gives an explicit bridge from visual concepts to reproducible detectors:

- Regular bullish divergence: price lower low with gauge higher low; hidden bullish: price higher low with gauge lower low. Bearish definitions mirror these at swing highs.
- The implementation pairs confirmed swings 5–60 bars apart, rejects a pair when price went beyond both in between, samples the gauge around the swing, and dates the event when the second swing becomes knowable—not retrospectively at the extreme.
- A 2-ATR zigzag and a 3-bar fractal do not identify identical swings. A detector disagreement may therefore be a definition/timing difference rather than an eye-reading mistake.
- The live weekly candle is unfinished. A weekly divergence visible midweek can disappear before Friday; record whether the reading uses an incomplete week.
- Harmonics require explicit X-A-B-C-D ratios and a potential reversal zone where constraints overlap. A completed D and an open D leg in the zone are separate states. Ratio tolerance and overshoot invalidation are declared rather than silently improvised.

The VFL ta dictionary documents 104 TA feature columns and 31 event types, including Ichimoku, squeeze momentum/release, SAR, Supertrend and further families. Its point-in-time assertions are historical author claims, not rerun here. The read dictionary connects structured facts to chart-read outputs: breakout, immediate, pullback, turn or wait; it separates evidence, entry zone, trigger, invalidation, targets and time stop. It documents 8,718 successful historical code-generated reads; these are **not** 8,718 fresh visual inspections by this agent.

## Reuse and remaining study

Use the archived chart corpus for blind multi-timeframe drills, the codebook for consistent narration, model-book/twins protocols for comparative learning, and dictionaries to make observations measurable. Do not execute imported engines or mistake old outputs for validated current signals. Next substantive reading priorities are the latest V5 examination and DEEP summaries, representative V3 plates paired with their answers, and the implementations behind the precise shape definitions. Their paths are now fully located; content study remains explicitly separate from discovery.
