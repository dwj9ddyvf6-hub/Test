# Full structured observation corpus: learning synthesis

## What was actually completed

All 132 batch review JSON files and the golden review JSON were retrieved at Agentic-Trading-Desk commit `4c8c179c5988d6e603c1f3c5f28f93e2344ca225`, parsed as data (no repository code executed), and reconciled by `(symbol, timeframe, color, eventAt)`. All 12,950 records have unique identities. There are 418 symbols; event dates span 2020-09-23 through 2026-06-02. Counts independently match the historical completion receipt: 6,516 daily cyan, 4,937 daily green, 896 weekly cyan, 601 weekly green.

Every record has setup family, structural location, energy, participation, signal grammar, entry, invalidation, management and uncertainty. 4,274 also carry distinctive-feature and unanticipated-observation fields. The machine-readable aggregate is corpus_analysis.json; all raw inputs are in review_corpus/; review_records_deduplicated.json preserves provenance.

**This is complete corpus parsing and aggregate analysis of existing observations, not a claim to have freshly viewed 12,950 images or carefully read every sentence.** Representative full records and narrative fields were read to interpret the summaries. Repeated tickers, dates, sectors and timeframes remain dependent even though identity duplicates are zero.

## Recovered framework: structure → permission → execution → retention

The corpus repeatedly distinguishes four jobs which should not be collapsed:

1. **Structure:** Is this an ordered advance, damaged trend, long repair, range or discontinuous repricing?
2. **Permission:** Does a marker invite attention in that context? A marker is not necessarily a bounded entry.
3. **Execution condition:** What observable shelf reclaim, break-and-hold or controlled retest must occur before the interpretation becomes actionable?
4. **Retention and realization:** Which successive shelves remain intact, where does extension mature, and what structural loss ends the campaign?

This provides a positive way to learn chart reading: one becomes more precise about the event sequence and the chart's changing state, not merely better at attaching pattern names.

## Taxonomy visible across all records

Non-exclusive lexical counts over setup/structure/energy/participation/grammar/management text:

| Theme | Records mentioning theme |
|---|---:|
| Participation/volume/sponsorship | 12,480 |
| Shelf/platform | 10,546 |
| Repair/reclaim | 7,530 |
| Ribbon/slow stack | 7,102 |
| Range/base | 6,444 |
| Continuation/staircase/higher low | 6,152 |
| Failure/reversal/giveback | 5,464 |
| Extension/stretch/verticality | 5,335 |
| Retention/holding | 5,208 |
| Gap/repricing | 2,796 |
| Compression/squeeze/tightness | 1,822 |
| Weekly/higher-timeframe/handoff language | 1,327 |

These are transparent text-pattern counts, not manually adjudicated setups, independent evidence, prediction accuracy or prevalence in all markets. Definitions are preserved in analyze_corpus.py. Exact setup labels are highly fragmented (7,826 distinct strings), so claiming a precise universal taxonomy from literal labels would be misleading.

A practical normalized learning map is:

- **Ordered continuation:** established higher shelves with supportive long structure; distinguish clean retention, partial retention and later reversal.
- **Repair:** damaged price regains fast then slow structure; distinguish a repair invitation from completed repair with a retained shelf.
- **Repricing/gap:** discontinuity changes the chart's level map; identify the first post-gap shelf instead of assuming the vertical bar is executable.
- **Compression/range:** stored contraction is not directional permission until escape is accepted and the range boundary holds.
- **Premature repair/volatile rebound:** an encouraging glyph inside unresolved damage remains conditional on structural completion.

## Relationships and worked readings

**NOC daily 2021-02-04:** the narrative describes a winter base under slow resistance. Its cyan/green-style permission gains execution meaning only after slow-ribbon clearance and a held higher shelf. Study transition completion rather than buying the name of a repair.

**GE daily 2021-02-03:** already ordered industrial continuation is a different problem: the February shelf above medium structure supplies a trailing framework. A GE continuation and NOC repair may share bullish markers while demanding different confirmation.

**INOD weekly 2024-07-08:** a long base is followed by late-year repricing. The reading asks for a first stable shelf after the November gap, illustrating why event date, later ignition and usable protection surface must be recorded separately.

**MNST daily 2023-03-17:** a second green inside the same platform records persistence; the common breakout is still one structural event. Repeated marks are not automatically multiple independent confirmations.

**MXL weekly 2021-06-07 and CDNS weekly 2021-06-21:** management follows completed weekly platforms rather than every daily candle. Daily and weekly cases in the same company are related views of one move, not separate independent examples.

**IONQ daily 2022-11-30 and HUBS daily 2022-10-31:** a bullish-looking glyph can coexist with falling ribbons and overhead supply. These are useful conflict drills: name what must improve before calling the chart repaired.

## Management lessons

- Anchor invalidation to the structure that makes the setup intelligible, not to an arbitrary aesthetic distance from a marker.
- Trail successive retained shelves when the chart actually supplies them; a smooth trend and an event-driven gap need different management descriptions.
- Separate favorable excursion from retained outcome. A chart can offer a strong initial leg and later give it all back.
- Distinguish realizing an extension from predicting that every extension must reverse.
- After a complete break, study whether a **new** repaired shelf forms before re-entry. The old thesis does not automatically revive because a fresh marker appears.
- Annotate uncertainty at the same time as the thesis: future-visible retrospective plates, sector/date clustering, liquidity discontinuity, corporate actions and unfinished weekly bars.

## Disagreements and precision limits

There were no duplicate identities with contradictory review fields in the parsed corpus. That does **not** establish inter-reader reliability: these are mostly one stored reading per identity. The meaningful conflicts found are internal to chart interpretation—marker versus ribbon, daily versus weekly, early permission versus later execution, initial gain versus subsequent retention.

The corpus contains both highly individualized descriptions and reusable template language: 9,329 exact entry strings, 8,457 invalidation strings and 8,806 management strings across 12,950 observations. Unique strings can include ticker/date prefixes; they are not proof of unique insight. To improve mastery, compare original plates where two templated descriptions imply materially different structure, and practice blinded right-edge readings.

## Latest archive reports: what they add to learning

Full-read `eyes/V5/exam/EXAM_RESULTS.md` at ClaudeDesk commit `f8a3175538bb4aafd64fad6b2f324c10ac4fad80` and `eyes/DEEP/FINDINGS2.md` at `4c542207b2d97ecbc09298ae5c1f48d9290ebe45`.

The exam reports all 180 renders graded, with V5 much better than V4 on several perception tasks. For R1–R8 when margin >1, V5 reports 100% against V4 97.4%; S1 remains only 61.1% exact but 100% within one. This is a concrete instructional result: legibility and explicit uncertainty improve chart-reading accuracy, and near-boundary exact judgments still need care. Question codes are preserved as codes here because the grading rubric was not separately read; do not invent their semantic meanings.

FINDINGS2 is an evolving historical research summary with many corrections and restrictive statistical verdicts. Its numbers were read, not rerun or independently validated. It must not be recast as this user's requested lesson being a project to disprove TA. The useful learning distinctions are: describing a chart, recognizing a state, forecasting direction, anticipating volatility, selecting an entry and realizing a return are different skills. A named pattern can be useful descriptive language without being a standalone buy rule; a warning can inform an otherwise constructive setup; and several correlated overlays are not independent evidence. The report also distinguishes machine-image models from LLM chart readers and corrects earlier unqualified claims about overlays.

A faithful continuation of the user's objective is to use the recovered definitions, full observations and actual charts to improve those distinct skills—not to promise divine forecasting or dismiss chart reading wholesale.
