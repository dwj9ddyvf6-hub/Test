# Elliott and Grand Gestalt: final additive craft lessons

Research date: October 30, 2026. Three additional whole documents read: 124,637 bytes, 17,724 whitespace-delimited words, 837 lines. All three exact Git blob hashes verified. This is static learning, not execution of repository code, new performance measurement, or alteration of a trading desk. Exact source pins and contiguous full-read ranges are in `wave_gestalt_full_read_ledger.json`.

## Source map and relationship to earlier study

All three sources are from `dwj9ddyvf6-hub/Midna`, commit `96e36e379cbe9330441221554d848f270d288800`:

- [Elliott PhD report](https://github.com/dwj9ddyvf6-hub/Midna/blob/96e36e379cbe9330441221554d848f270d288800/workspace/research_notes/elliott-wave-phd-deep-dive-20261016-1907/report.md), blob `2c075fcca66216462b7b4a2d549d8b2151e7f917`.
- [Grand Gestalt Algorithm](https://github.com/dwj9ddyvf6-hub/Midna/blob/96e36e379cbe9330441221554d848f270d288800/workspace/research/grand-gestalt/GRAND_GESTALT_ALGORITHM.md), blob `b68fe0fad4f9ff840cf45623c9d7d72884a11c32`.
- [Grand Gestalt Synthesis](https://github.com/dwj9ddyvf6-hub/Midna/blob/96e36e379cbe9330441221554d848f270d288800/workspace/research/grand-gestalt/SYNTHESIS.md), blob `b1f964b9c9dd10211345b82692003fb44ef48940`.

Comparison basis: the earlier `corpus_triage/learning_synthesis.md`, its Galath/Femto Elliott comparison, and `femto_chart_read_learning.md`. The PhD report is recognizably the design ancestry of the already-read Femto counting approach, not a third independently demonstrated wave engine. Grand Gestalt is a cross-sleeve allocation/alert proposal with archived research summaries; it is not the earlier visual chart-reading Grand Synthesis under a different title. Its mechanics add lessons, but most quoted statistical results remain inherited claims in this pass.

The archived report's skeptical framing is not adopted as the mission for this study. The goal here is to learn correct construction, meaningful alternatives, and practical execution distinctions. Nor are its sweeping research-absence statements independently established by reading its bibliography. We do not turn an archive's historical prohibitions into current instructions.

## 1. Add momentum sequencing to the wave-counting practice

The useful new distinction is between **counting price structure** and **using momentum to help locate a stage within that structure**. The report describes Tom Joseph/Advanced GET-style 5-versus-35 moving-average oscillators and Bill Williams' 5-versus-34 midpoint-price Awesome Oscillator. Those are related but not interchangeable formulas. State the actual inputs, smoothing, periods and units before comparing charts.

A practical study sequence is:

1. Mark the candidate motive move's origin and its meaningful price swings without oscillator labels.
2. Find the oscillator's strongest directional expansion within that move, using a fixed visible window. Treat it as a candidate recognition/acceleration segment, not proof of wave 3.
3. Inspect the subsequent momentum reset. Does the oscillator return toward or through zero while the relevant price structure survives? This distinguishes a momentum reset from a price-structure failure.
4. Inspect the next directional price push. If price exceeds the earlier high but momentum does not, describe that specific paired comparison. Then check whether the wave subdivision and higher-degree context make a fifth-wave hypothesis plausible.
5. Write what would confirm a turn in price. Momentum divergence alone does not complete the reversal.

The report's roughly 100–150-bar search windows and GET PTI thresholds belong to described implementations; their vendor success percentages are not newly verified facts. Williams-style fractals also arrive with confirmation lag. An oscillator maximum can change while the move is still developing, so freeze the window and observation time in practice.

**Original drill:** draw a strong initial expansion, a momentum reset above intact price support, and a marginal higher price high with weaker oscillator expansion. Produce two readings: continuation with a temporary momentum pause, and terminal advance. Identify the price event that separates them. Repeat with the oscillator hidden, then explain precisely what the panel added. This teaches use of the tool rather than dependence on its label.

## 2. A single-scale morphology is not a fully inspected Elliott subdivision

The PhD specification explicitly omits recursive lower-degree subdivision checks in its first version. Its six-pivot impulse and four-pivot correction candidates are therefore **single-scale shape candidates**. Passing three outer price rules does not establish that each internal leg has the required form.

This clarifies the prior Galath/Femto comparison. A pivot parameter set is an operational swing scale; it is not automatically a classical named degree. Conversely, a human can study subdivisions on a genuine lower-timeframe chart, provided the data are actually available. Neither approach should borrow the other's certainty silently.

Practical worksheet additions:

- Outer shape: which pivot endpoints satisfy the proposed pattern?
- Interior: which legs have actually been inspected for subdivisions?
- Unknown: which interior structures are unresolved or unavailable?
- Operational scale: what pivot rule or discretionary swing criterion was used?
- Candidate state: forming, confirmed under the chosen rule, ambiguous, invalidated, or superseded?

A genuinely useful alternate differs in what the next observable movement means. A wave-4-to-wave-5 interpretation and a corrective-B-to-C interpretation can share much of their existing geometry but imply different consequences at the next level. Do not redraw the original history when the alternate becomes preferred; retain the old reading and the observation that changed it.

## 3. Corrections needed before teaching from this archive

Several report sentences are too loose or incorrect. Fresh primary-source checks prevent reproducing them:

- An ending diagonal's fifth-wave throw-over crosses the boundary through **waves 1 and 3**, not the 2–4 boundary stated in the archive.
- EWI's own leading-diagonal discussion admits uncertainty between 3-3-3-3-3 and 5-3-5-3-5 and describes expanding leading diagonals. The archive's declaration that only the latter subdivision is canonical, and leading diagonals must contract, is too categorical. A particular engine may choose a narrower grammar, but must call it a design choice. [EWI: Diagonals](https://www.elliottwave.com/waveopedia/elliott-wave-pattern-diagonals/).
- Within an impulse, subwave 3 is itself an impulse. The archive's broad wording that waves 1, 3 and 5 may all be diagonals needs qualification. Ordinary wave-4 non-overlap is not merely an end-of-bar-close rule. EWI describes a limited futures-market caveat, not general permission to ignore overlap. [EWI: Impulse](https://www.elliottwave.com/waveopedia/impulse/).

These are method corrections, not arguments against wave analysis. Accurate construction is exactly what the learning objective requires. The report's close-breach state transition can be a chosen execution convention; it must not silently redefine the structural rule. Its broad ratio table also mixes customary and later-practitioner values, so do not transmit every listed ratio as an inviolable requirement.

## 4. Selection, timing, excursion, and holding return are four different jobs

Grand Gestalt makes this distinction especially visible. It combines ranked universes, intraday engine signals, event-conditioned setups, and weekly theses. Those are not four ways of doing the same thing.

A chart-reading process should identify:

- **Selection:** why this instrument deserves attention relative to alternatives.
- **Location and timing:** where in its structure a new position would be considered, and what activates it.
- **Path capture:** whether the anticipated opportunity is a temporary excursion or sustained follow-through.
- **Holding/management:** how long the thesis remains operative and what event ends it.

An archived strategy may produce favorable maximum excursions yet poor fixed-horizon terminal returns. That does not imply every favorable excursion was executable, and it does not prescribe an exit from hindsight. It tells the learner to study the path: when did the advance begin, when did the trigger become knowable, how much was already gone, did price retest, and what observable exit rule would have captured part of it?

**Original drill:** compare three otherwise identical setup cards: a weekly selection thesis, a one-hour entry tactic, and a short-lived event excursion. Annotate the same chart with a separate clock and boundary for each. A correct short-term read cannot retroactively supply a thirteen-week holding rule. A strong longer-term thesis does not make every intraday entry well located.

## 5. Volatility, extension, and room are different measurements

The Gestalt archive distinguishes high confirmation-bar ATR percentage from an entry already far from its trigger. This is worth preserving: large typical movement is not identical to poor entry location.

For each candidate chart, measure three separate distances:

1. Current price from the intended trigger or reference entry.
2. Current price from the structural boundary that would negate the setup.
3. Current price to the next meaningful opposing shelf or objective.

Normalize by a named volatility measure where useful, but retain the absolute prices and actual structure. A fast-moving instrument can still offer a nearby structural entry. A quiet instrument can still be overextended relative to its own range. Bollinger room is one model's proxy, not a replacement for inspecting the actual supply/resistance map.

The archived 0.5 ATR and 1.5 ATR suppression thresholds and 0.985 upper-band multiplier are house definitions. Its claim that every setup needs the same extension veto is broader than the measured evidence described. Teach the question—how much opportunity remains after activation?—rather than a universal numerical ban.

## 6. Confluence must preserve distinct mechanisms and clocks

The report correctly notices shared ancestry among nominally different breakout tools. It proposes avoiding duplicate position sizing when two labels describe the same underlying event. This extends the earlier lesson about redundant indicators: **two engines can agree without providing two independent reasons**.

Create a confluence table with columns for input, mechanism, timeframe, activation, invalidation and management clock. An earnings event, a weekly relative-strength ranking, a one-hour price breakout, and an RSI rise play different roles. Two price breakouts from similar windows may be near duplicates. Independence is not established merely by naming two families, however; the archive's assertion that weekly selection and intraday signals are independent is a working design assumption, not a measured interaction result.

A higher-timeframe thesis can organize a lower-timeframe entry, but the trade plan must specify this **before** the trigger. The Gestalt proposal's rule that the thirteen-week clock overrides a one-hour signal when both occur is a new combined strategy, not an automatic consequence of either ingredient's prior results.

## 7. Specification tensions that must not become learned trading rules

Static reading exposes several exact issues. No code or desk was changed:

- **Penalty sign:** the formula subtracts `conflict_penalty`, while prose assigns that field −0.50. Literal subtraction would increase the score. Define either a positive penalty to subtract or a negative adjustment to add before implementing anything.
- **Noncomparable confidence scales:** the formula mixes an engine's 0–10 score, rank-percentile transformations, a capped 0–1 depth measure and an unspecified box-quality score. Raw products do not establish comparable cross-setup conviction.
- **Competing stop doctrine:** this archive argues against tested stop floors, while the earlier chart-method archive prescribed a 1.5 ATR minimum from a small loss sample. Different versions and systems cannot be merged into one universal stop rule. Start with the actual structure and named execution convention; assess each method in its own scope.
- **Approval chronology:** one S-5 paragraph says approved October 6, while later scoring and alert passages still say approval is pending. Historical status is inconsistent internally. It does not authorize a present action.
- **Earnings role:** the synthesis says earnings context should not become a systematic skip gate; the algorithm retains a three-day blackout for new entries and separately promotes an earnings-conditioned setup. Precise event windows and precedence are needed to know whether those can coexist.
- **Source/version precedence:** the algorithm contains an October 17 correction to the older Casey bull-flag status; the companion synthesis retains the prior wording. Preserve both dates, and do not treat the correction as a verdict on every bull flag or on visual pattern reading generally.
- **Regime proposals versus measured knowledge:** reduced risk and shortened clocks in a bear regime are guardrail proposals in a source that says it has not tested that regime. They are not demonstrated adaptations.

These points matter because apparent precision can conceal unresolved choices. Learning to read an engine includes learning its specification limits, not merely memorizing its score or status labels.

## 8. What this final delta adds to the practical curriculum

Retain the already-learned geometry-first, nested-structure, anchored-ratio and primary/alternate workflow. Add four focused practice sessions:

1. **Momentum-stage comparison:** price-only count versus price-plus-oscillator sequencing, with exact settings and observation time.
2. **Subdivision inspection:** distinguish an outer-shape candidate from one whose internal legs have been examined; explicitly mark unresolved detail.
3. **Four-job setup card:** selection, timing, excursion and holding plan, each with its own evidence and clock.
4. **Confluence audit:** identify shared inputs, duplicate mechanisms, contradictory rules and untested combined management before calling agreement stronger evidence.

The completion claim is three additional full text reads and an original synthesis. No additional historical chart images were inspected in this subtask; no model was trained; no predictive accuracy or execution result was demonstrated. The freshly checked EWI pages corrected construction details, while the archive's performance tables remained archive evidence. No access blocker remains for the three assigned documents. An initially guessed singular EWI diagonal URL was inaccessible; following the official Impulse page's Diagonals link resolved it without bypassing access controls.
