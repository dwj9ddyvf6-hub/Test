# Indicator semantics: what the chart actually asks you to read

## Scope and evidence
This module closes a finite vendor-method frontier, not every product or file on the internet. Nineteen archived source files were retrieved from Silicon at commit `3815c4b223be493704850519656fa7e7b3e3750b`; each matches its Git blob SHA exactly. Fifteen text/spec files were read in full; four HTML files were converted to visible text and that complete text read (HTML source code was not audited). Sources, SHA-256, byte counts and dispositions are in `read_ledger.json`. No embedded chart image or video was viewed in this pass. Existing ChartPrime Prime Oscillator, structure, order-block, profile and pattern studies are not duplicated. Public Market Cipher tutorial-page descriptions were additionally read, not the linked videos.

## 1. ChartPrime: state, direction, and exhaustion are separate readings

### MVP oscillator
MVP runs between -100 and +100. Its zero line describes bullish/bearish state; blue/purple ribbon describes upward/downward movement. Agreement (purple below zero, blue above) differs from disagreement (blue below zero, purple above). The latter can be a counter-move or transition rather than a completed reversal. Divergence on this mode is identified manually. The guide treats extreme readings, green extension bars and arrow signals as reversal warnings and recommends confirmation back through an extreme boundary before acting. Construction formulas are not disclosed in this page. [MVP manual](https://docs.chartprime.com/prime-oscillators/mvp-oscillator.md)

### Trend Fusion oscillator
This combines a price-volume wave and adaptive comparison plot; their intersection changes the trend band. Separate features mark regular divergences, reversal dots and an MFI background histogram. Reversal-dot inputs are described as trend duration, ATR, deviation, volatility and gaps, but exact weights and thresholds are not supplied. A dot and the trend band answer different questions: possible exhaustion versus current directional state. Green money flow plus a positive wave is the manual’s example of agreement. [Trend Fusion manual](https://docs.chartprime.com/prime-oscillators/trend-fusion-oscillator.md)

**Original practice drill:** Cover price after the signal. Write four independent observations: location relative to the centerline; ribbon slope/color; agreement with money flow; distance from actual price support/resistance. Then state what price must do to confirm. This prevents treating every colored mark as the same kind of evidence. Count correlated price-derived readings as related observations, not four independent votes.

## 2. AlgoAlpha: separate structural map from timing pane

ILPAC’s documented layers are swing structure (HH/HL/LH/LL and BOS/CHoCH), multi-timeframe liquidity heatmaps, trendline breaks, and volume-surge FOMO bubbles. The archive describes feature roles, not the heatmap’s numerical construction. Therefore call the displayed areas *potential* liquidity/reaction zones, not observed stop inventories. Its sensible reading order is structure first, nearby zone second, breakout/rejection behavior third; volume-surge bubbles warn against entering after extension. [Archived ILPAC documentation](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/rea-teardowns/algoalpha/docs/premium-indicators_institutional-liquidity-and-price-action-concepts.txt)

Momentum Concepts describes six components and four algorithm choices, regular versus hidden divergence, volatility-adaptive reversal areas, a fast scalping component, and an 18-asset screener. This is a feature overview, not an exact formula manual. Regular divergence asks whether an existing push is weakening; hidden divergence asks whether a pullback fits continuation. Screening identifies charts to inspect; it does not replace drawing the relevant swings on the selected chart. [Archived Momentum Concepts overview](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/rea-teardowns/algoalpha/pages/momentum-concepts.txt)

## 3. Zeiierman: the sweep is an event; its aftermath chooses the setup

The liquidity manual explicitly separates sweep direction from trade direction. An Up label means movement above highs, not “buy”; Down means movement below lows, not “sell.” Its workflow contrasts a break that holds outside a range with a sweep that returns and is reaccepted inside. Trend continuation needs directional structure; late-trend reversal needs failed follow-through, rejection, or a lower-timeframe structural change. One terminology caution matters: the page swaps conventional buy-side/sell-side stop names in its opening bullets. Use unambiguous descriptions—short-covering buy stops above highs, long-stop sell orders below lows—rather than copying that wording. [Liquidity signals](https://docs.zeiierman.com/signals/liquidity-signals.md)

The Trend Analysis strategy separates midline trend state, retracement histogram, early impulse triangles, actual entries, trailing stops and partial exits. Its entry description combines directional bias, fractal-zone alignment and a retracement impulse. Lower sensitivity lengths react faster; a larger stop multiplier allows more movement. Two retracement paragraphs contradict their own stated trend direction, so their color-only continuation instructions remain unresolved. Later examples offer the coherent chart lesson: when the expected bounce fails and price respects a structural break, stop calling the movement an ordinary pullback. Exact fractal/smoothing formulas are not disclosed. [Trend Analysis manual](https://docs.zeiierman.com/script/bot/trend-analysis-strategy.md)

**Original paired exercise:** Take two upward sweeps of the same resistance. In one, subsequent closes hold above and a pullback preserves the level; in the other, the next closes return inside and a retest fails. Label the first acceptance/continuation candidate and the second failed-break/reversal candidate. The initial sweep alone cannot distinguish them. Record the observation that changed the classification.

## 4. TrendSpider: read where participation migrated within the bar

The archived Raindrop reconstruction splits each bar into equal time halves, computes each half’s VWAP, and displays volume-at-price width. Comparing second-half with first-half VWAP asks whether volume-weighted participation moved upward or downward during that bar. This is different from comparing open with close. A wide section indicates concentrated traded volume, not the passage of more time. Complete both halves before making a final bar comparison. The archive’s ATR-normalized drift and proposed next-bar entry are local research additions, not original vendor rules. [Pinned reconstruction SPEC](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/rea-teardowns/trendspider/SPEC.md)

**Original exercise:** Compare two identical OHLC bars with different intrabar volume distributions. Ask whether late participation accepted the high or merely left a thin excursion there. This teaches why candlesticks and volume profiles can describe different aspects of the same interval.

## 5. Options-context displays: horizon and regime before direction

### Trade Echo (a distinct product, not an established identity match to the user's Echo)
Its setup library defines a 1–5 GEX rating as volatility regime, not bullish/bearish conviction. Anchor Approach applies in positive-gamma ratings 4–5; At Gamma Flip describes transitional rating 3; Flip Reclaim concerns negative-gamma ratings 1–2 near the boundary. Flip Cross is an event between snapshots, not persistent proximity. Clear Path to Anchor is about intervening obstacles, while Charm Stack combines anchor proximity with charm overhead. Agent playbooks are explicitly distinguished from price setups. Read regime → level → approach/cross/acceptance; do not translate the rating directly into long/short. [Pinned setup library](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/rea-teardowns/tradeecho/pages/setups.html)

### SqueezeMetrics
The primary archived DIX page calls DIX a dollar-weighted dark-pool short-sale ratio, a proxy for otherwise less-visible buying—not an actual customer-buy count. GEX estimates potential dealer hedge response: positive can damp movement, negative can amplify it; neither determines direction. Its local reconstruction SPEC additionally describes daily trend/volatility/convexity/short-volume measurements and a historical-analogue forecast. The practical chart lesson is to separate volatility environment from price direction and match daily context to the intended horizon. No vendor entry rule is extracted. [DIX/GEX source](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/rea-teardowns/squeezemetrics/pages/monitor_dix.html)

### Prospero and MenthorQ
Prospero’s Upside/Downside Breakout scores concern potential gains/losses over the next year, despite updating every few minutes. They combine options-market information, coverage and momentum; they are not chart-pattern breakout detections, and low downside is not equivalent to high upside. [Upside description](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/rea-teardowns/prospero/pages/learn-upside-breakout.txt)

MenthorQ’s swing overview describes upper/lower projected levels and a risk trigger for 5- and 20-day horizons. It names implied-volatility/options inputs but does not disclose the model or a numerical trade rule. These are projected context levels, not observed historical support. The archived momentum-model page contains only a verification loader, so no momentum lesson was recovered. [Swing model source](https://github.com/dwj9ddyvf6-hub/Silicon/blob/3815c4b223be493704850519656fa7e7b3e3750b/research/rea-teardowns/menthorq/pages/quantitative-model_swing-trading-model.txt)

## 6. Market Cipher: use the right layer and timeframe

The archived FAQ is mostly access/billing material, but it directs readers to public tutorials and emphasizes matching the chart’s exchange feed to the traded venue. The current official tutorial-page descriptions teach higher-timeframe context with lower-timeframe timing; separate EMA ribbon, momentum waves, money-flow and support/VWAP layers; and explain that extreme momentum can persist. The uptrend example combines higher-chart trend, lower-chart pullback, weakening adverse money flow and support-based invalidation. The descriptions alone do not provide a complete executable Blue Wave rule; linked videos and guide were not consumed. [Official tutorial descriptions](https://marketciphertrading.com/tutorial-videos/)

## 7. Explicit scope dispositions, not imaginary lessons

- **GainzAlgo setup tutorial:** activation/access instructions only; no signal-construction or chart-reading lesson recovered.
- **TJR setup-guide listing:** says the indicator marks stages, but does not disclose the stages. Reviews and pricing are not a method manual. A source gap remains, not a negative judgment of the method.
- **GammaEdge comparison:** affiliate sales comparison, pricing and performance claims; no operational chart method. No rule inferred from advertised win rates.
- **OTT in this corpus means Options Trading Toolbox**, not an Optimized Trend Tracker indicator. The profit visualizer concerns options payoff by strike/date, outside this chart-reading lane.
- Installation, checkout, subscription, privacy, testimonials, compiled UI bundles and trade-execution plumbing are not counted as additional chart-method lessons. Unread matching files remain metadata-dispositioned rather than falsely “absorbed.”

## Integrated reading routine

1. Name the instrument, venue, session and analysis horizon.
2. Draw price structure without the vendor labels.
3. Assign each display a role: location, state, momentum, exhaustion, participation, or volatility context.
4. Identify the actual event: touch, sweep, cross, hold, failure, or reclaim.
5. State the confirmation and the observation that would invalidate the interpretation.
6. Preserve a screenshot before revealing subsequent bars; later compare the prediction with the actual sequence.

Learning these tools means knowing exactly which question each display answers—not collecting more colored confirmations.
